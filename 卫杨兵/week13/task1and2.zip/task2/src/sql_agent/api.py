"""FastAPI 后端：把 LangGraph SQL Agent 暴露成 HTTP 接口。

启动方式（在 task2 目录下）：

    PYTHONPATH=src uvicorn sql_agent.api:app --host 127.0.0.1 --port 8000

接口：

- ``GET  /health``     健康检查
- ``POST /api/query``  接收 {"question": "..."}，返回 WorkflowOutput JSON
"""

from __future__ import annotations

import logging
import os
from functools import lru_cache

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .models import WorkflowOutput
from .workflow import SQLAgentWorkflow

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Chinook SQL Agent API",
    version="0.1.0",
    description="用自然语言查询 Chinook SQLite 数据库的 LangGraph Agent。",
)


class QueryRequest(BaseModel):
    """一次查询请求。"""

    question: str = Field(
        min_length=1,
        max_length=2000,
        description="自然语言查询问题，例如：总共有多少张专辑？",
    )


@lru_cache(maxsize=1)
def get_workflow() -> SQLAgentWorkflow:
    """进程内复用 catalog、校验器、执行器和编译好的 LangGraph。

    首次调用会加载并缓存数据库目录（约 1 秒），之后所有请求共享同一实例。
    """

    return SQLAgentWorkflow()


@app.get("/")
async def root() -> dict[str, str]:
    return {
        "service": "Chinook SQL Agent API",
        "docs": "/docs",
        "query": "POST /api/query",
    }


@app.get("/health")
async def health() -> dict[str, str]:
    """供前端或容器探针检查服务是否存活。"""

    return {"status": "ok"}


@app.post("/api/query", response_model=WorkflowOutput)
async def query(request: QueryRequest) -> WorkflowOutput:
    """执行一次完整的选表 -> 生成 SQL -> 执行 -> 汇总流程。"""

    question = request.question.strip()
    if not question:
        raise HTTPException(status_code=422, detail="question 不能为空")

    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(
            status_code=503,
            detail="缺少 OPENAI_API_KEY，请先在服务端环境变量中配置。",
        )

    logger.info("api query question=%s", question[:200])
    try:
        return await get_workflow().run(question)
    except Exception as exc:  # noqa: BLE001 - API 边界统一转成 HTTP 错误
        logger.exception("api query failed")
        raise HTTPException(status_code=500, detail=f"查询失败：{exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
