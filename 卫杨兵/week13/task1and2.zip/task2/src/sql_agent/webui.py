"""Streamlit 聊天前端：通过 HTTP 调用 FastAPI 后端。

启动方式（在 task2 目录下）：

    streamlit run src/sql_agent/webui.py

后端地址默认读取 ``SQL_AGENT_API_URL``，也可以在侧边栏直接修改。
本文件不导入 ``sql_agent`` 包，因此无需设置 PYTHONPATH。
"""

from __future__ import annotations

import os

import requests
import streamlit as st

DEFAULT_API_URL = os.getenv("SQL_AGENT_API_URL", "http://127.0.0.1:8000")

EXAMPLES = [
    "总共有多少张专辑？",
    "销售额最高的 5 位客户是谁？",
    "每个音乐类型的歌曲数量是多少？",
    "哪位员工的销售额最高？",
]


def call_backend(api_url: str, question: str) -> tuple[dict | None, str | None]:
    """调用后端查询接口，返回 (结果, 错误信息)。"""

    try:
        response = requests.post(
            f"{api_url.rstrip('/')}/api/query",
            json={"question": question},
            # LLM 可能经历选表、生成、修复、汇总多次调用，给足超时。
            timeout=300,
        )
    except requests.RequestException as exc:
        return None, f"无法连接后端：{exc}"

    if response.status_code != 200:
        try:
            payload = response.json()
        except ValueError:
            payload = response.text
        detail = payload.get("detail") if isinstance(payload, dict) else payload
        return None, f"后端返回 HTTP {response.status_code}：{detail}"

    try:
        payload = response.json()
    except ValueError:
        return None, "后端返回的不是合法 JSON。"
    if not isinstance(payload, dict):
        return None, "后端返回格式不正确。"
    return payload, None


def render_details(data: dict) -> None:
    """展示 SQL、执行统计、证据与注意事项。"""

    with st.expander("查看 SQL 与执行详情"):
        sql = data.get("sql")
        if sql:
            st.markdown("**最终 SQL**")
            st.code(sql, language="sql")
        else:
            st.caption("本次没有生成可执行的 SQL。")

        tables = data.get("tables") or []
        st.markdown(
            f"**查询表：** {'、'.join(tables) if tables else '—'}　"
            f"**返回行数：** {data.get('row_count', 0)}　"
            f"**修复次数：** {data.get('repair_attempts', 0)}　"
            f"**是否截断：** {'是' if data.get('truncated') else '否'}"
        )

        evidence = data.get("evidence") or []
        if evidence:
            st.markdown("**支撑数据**")
            for item in evidence:
                st.markdown(f"- {item}")

        caveats = data.get("caveats") or []
        if caveats:
            st.markdown("**注意事项**")
            for item in caveats:
                st.markdown(f"- {item}")

        if data.get("error"):
            st.error(f"执行错误：{data['error']}")


def handle_question(question: str, api_url: str) -> None:
    """把问题发给后端，并把结果写入对话历史。"""

    question = question.strip()
    if not question:
        return

    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Agent 正在选表、生成 SQL 并执行，请稍候…"):
            data, error = call_backend(api_url, question)

        if error:
            st.error(error)
            st.session_state.messages.append({"role": "assistant", "content": error})
            return

        answer = str(data.get("answer") or "（后端没有返回答案）")
        st.markdown(answer)
        render_details(data)
        if data.get("error"):
            st.warning("本次查询存在错误，详情见上方执行详情。")
        st.session_state.messages.append(
            {"role": "assistant", "content": answer, "data": data}
        )


def main() -> None:
    st.set_page_config(
        page_title="Chinook SQL Agent",
        page_icon="🗄️",
        layout="centered",
    )
    st.title("🗄️ Chinook 数据查询助手")
    st.caption("输入自然语言问题，Agent 会自动选表、生成 SQL、执行并汇总答案。")

    api_url = st.sidebar.text_input(
        "后端地址",
        value=DEFAULT_API_URL,
        help="FastAPI 服务地址，例如 http://127.0.0.1:8000",
    ).strip()
    api_url = api_url.rstrip("/")

    if st.sidebar.button("检查后端连接", use_container_width=True):
        try:
            response = requests.get(f"{api_url}/health", timeout=5)
            response.raise_for_status()
            st.sidebar.success("后端已连接")
        except requests.RequestException as exc:
            st.sidebar.error(f"连接失败：{exc}")

    st.sidebar.divider()
    st.sidebar.markdown("**示例问题**")
    for example in EXAMPLES:
        if st.sidebar.button(example, use_container_width=True):
            st.session_state.pending_question = example

    if st.sidebar.button("清空对话", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.sidebar.divider()
    st.sidebar.caption(
        "后端启动：`PYTHONPATH=src uvicorn sql_agent.api:app --port 8000`"
    )

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("data"):
                render_details(message["data"])

    prompt = st.chat_input(
        "例如：总共有多少张专辑？",
        disabled=not api_url,
    )
    if prompt is None:
        prompt = st.session_state.pop("pending_question", None)

    if prompt:
        if not api_url:
            st.error("请先在侧边栏填写后端地址。")
        else:
            handle_question(prompt, api_url)


if __name__ == "__main__":
    main()
