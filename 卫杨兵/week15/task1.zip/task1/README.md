# 双 Agent 情感支持系统

固定两步 Agent 流水线：

```text
用户输入 → 情感识别 Agent → positive / negative / neutral
                                  │
                positive ─────────┤
                                  ▼
                            鼓励 Agent
                negative / neutral → 排解 Agent
                                  │
                                  ▼
                          SSE 流式返回给前端
```

同一业务逻辑用两套框架实现，**两个后端彼此独立、可分别启动**：

| 后端 | 目录 | 端口 | 编排方式 |
|---|---|---|---|
| LangGraph | `backend_langgraph/` | 8001 | `StateGraph` + 条件边 + `InMemorySaver` |
| OpenAI Agents SDK | `backend_agents/` | 8002 | `Agent` + `Runner.run` / `Runner.run_streamed` + 手写会话历史 |

前端提供两套并列实现（Vue 与 Streamlit），二者只依赖统一的 SSE 协议；
切换后端只需改各自的地址配置（`VITE_API_BASE` / `CHAT_API_BASE`），UI 代码不变。

---

## 目录结构

```text
.
├── backend_langgraph/
│   ├── app/
│   │   ├── main.py            # 与 backend_agents 逐字相同
│   │   ├── sse.py             # 与 backend_agents 逐字相同
│   │   ├── contracts.py       # 与 backend_agents 逐字相同
│   │   ├── graph.py           # 图、节点、条件路由
│   │   └── orchestrator.py    # 图 → chat_stream() async generator
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── backend_agents/
│   ├── app/
│   │   ├── main.py            # ↑ 三件套逐字相同
│   │   ├── sse.py
│   │   ├── contracts.py
│   │   ├── agents.py          # 三个 Agent + DeepSeek 模型接入
│   │   ├── conversation_store.py
│   │   └── orchestrator.py    # Runner → chat_stream() async generator
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/App.vue            # 聊天界面
│   ├── src/api/chat.js        # fetch + ReadableStream 解析 SSE
│   ├── vite.config.js
│   ├── Dockerfile
│   └── nginx.conf
├── frontend_streamlit/        # 并列的第二套前端（Python，无 Node 依赖）
│   ├── app.py                 # Streamlit 聊天界面
│   ├── api/chat.py            # httpx + SSE 解析
│   ├── Dockerfile
│   └── requirements.txt
├── scripts/
│   └── mock_deepseek.py       # 无 API Key 时的本地 OpenAI 兼容 Mock
├── docker-compose.yml
└── .env.example
```

两个 `orchestrator.py` 的 diff 就是全部编排层差异：

```bash
diff backend_langgraph/app/orchestrator.py backend_agents/app/orchestrator.py
```

---

## 快速开始（本地）

要求：Python 3.11+、Node 18+。

### 1. 安装依赖

```bash
cd backend_langgraph && pip install -r requirements.txt
cd ../backend_agents  && pip install -r requirements.txt
cd ../frontend        && npm install
```

### 2. 配置 DeepSeek

复制并填写两个后端的环境变量（`python-dotenv` 从各自目录下的 `.env` 读取）：

```bash
cp backend_langgraph/.env.example backend_langgraph/.env
cp backend_agents/.env.example    backend_agents/.env
# 编辑两个 .env，填入 DEEPSEEK_API_KEY
```

也可用环境变量直接注入，不写 `.env`。

### 3. 启动后端（必须单 worker）

```bash
cd backend_langgraph && uvicorn app.main:app --port 8001 --workers 1 --reload
```

```bash
cd backend_agents && uvicorn app.main:app --port 8002 --workers 1 --reload
```

会话状态保存在进程内存里（LangGraph 的 `InMemorySaver` / Agents 侧的 `ConversationStore`），
**多 worker 之间不共享**，因此第一版强制 `--workers 1`。

### 4. 启动前端

```bash
cd frontend && npm run dev
```

打开 `http://localhost:5173`。

`frontend/.env.development` 默认：

```text
VITE_API_BASE=http://localhost:8001   # LangGraph
```

对比 Agents 后端时改成 `http://localhost:8002` 并重启 dev server；UI 代码不变。

也可以使用与 `frontend/` 并列的 Streamlit 前端（只依赖 Python，无需 Node）：

```bash
cd frontend_streamlit
pip install -r requirements.txt
streamlit run app.py
```

打开 `http://localhost:8501`；默认同样连 `:8001`，左侧边栏可直接切换后端地址。
详见 [`frontend_streamlit/README.md`](frontend_streamlit/README.md)。

---

## 没有 API Key？用内置 Mock

`scripts/mock_deepseek.py` 实现了 OpenAI 兼容的 `/v1/chat/completions`（流式 + 非流式），
能模拟 DeepSeek 的普通回复、JSON mode 与 tool calling，用于完整跑通两个 SDK 的流式链路：

```bash
# 终端 1：Mock（依赖 FastAPI / uvicorn，装过后端依赖即可）
python scripts/mock_deepseek.py                 # 127.0.0.1:8010

# 终端 2：LangGraph 后端
cd backend_langgraph
DEEPSEEK_API_KEY=mock DEEPSEEK_BASE_URL=http://127.0.0.1:8010/v1 \
  uvicorn app.main:app --port 8001 --workers 1

# 终端 3：Agents 后端
cd backend_agents
DEEPSEEK_API_KEY=mock DEEPSEEK_BASE_URL=http://127.0.0.1:8010/v1 \
  uvicorn app.main:app --port 8002 --workers 1
```

Mock 的可调环境变量：

| 变量 | 作用 |
|---|---|
| `MOCK_PORT` | 监听端口，默认 `8010` |
| `MOCK_DELAY` | 流式分片间隔秒数，默认 `0.01` |
| `MOCK_REJECT_JSON_SCHEMA=1` | 对 `response_format=json_schema` 返回 400，验证 Agents 兜底 |
| `MOCK_REJECT_JSON_OBJECT=1` | 对 `response_format=json_object` 返回 400，验证 LangGraph 兜底 |
| `MOCK_REJECT_TOOLS=1` | 对 tool calling 返回 400 |

> Mock 仅用于本地联调，不会发给 DeepSeek，也不替代真实 Key 下的验证。

---

## 统一契约

### 请求

```http
POST /chat
Content-Type: application/json

{"thread_id": "uuid-xxx", "message": "今天被领导批评了，好难过"}
```

`thread_id` 由前端生成并持久化在 `localStorage`，首次对话创建，点击“新对话”时更换。

### SSE 响应

```text
event: sentiment
data: {"label":"negative","confidence":0.95}

event: token
data: {"delta":"我听见你"}

...

event: done
data: {"framework":"langgraph"}
```

| 事件 | 时机 | data |
|---|---|---|
| `sentiment` | 情感识别完成 | `{label, confidence}` |
| `token` | 回应生成中逐 token | `{delta}` |
| `done` | 全部完成 | `{framework}` |
| `error` | 任一阶段失败 | `{message}` |

情感识别阶段**不流式**（路由依赖最终标签），回应阶段逐 token 流式；前端先展示情感标签，再渲染回复。

手动验证：

```bash
curl -N -X POST http://localhost:8001/chat \
  -H "Content-Type: application/json" \
  -d '{"thread_id":"t1","message":"今天被领导批评了，好难过"}'
```

> Windows Git Bash 直接把中文放进 `-d` 可能因控制台编码导致 422；可把 JSON 写入 UTF-8 文件后用 `--data-binary @req.json`。

健康检查：`GET /health`。

---

## Docker

```bash
cp .env.example .env        # 填 DEEPSEEK_API_KEY
docker compose up --build
```

- 前端：`http://localhost:3000`（默认连 LangGraph `:8001`）
- Streamlit 前端：`http://localhost:8501`（容器内通过 `CHAT_API_BASE` 连后端）
- LangGraph 后端：`http://localhost:8001`
- Agents 后端：`http://localhost:8002`

切换 Vue 前端默认后端：在根目录 `.env` 设 `VITE_API_BASE=http://localhost:8002` 后重新构建前端镜像。
切换 Streamlit 前端默认后端：设 `CHAT_API_BASE=http://backend-agents:8002` 后重新创建该容器
（注意容器内要用 compose 服务名，不是 localhost）。

SSE 经 Nginx 反代时**必须关闭缓冲**（`proxy_buffering off`、`X-Accel-Buffering: no`），
否则 token 被攒批、打字机效果消失。`frontend/nginx.conf` 中给出了同源反代的注释示例。

---

## 两套后端对照

| 维度 | `backend_langgraph` | `backend_agents` |
|---|---|---|
| 多轮状态 | `InMemorySaver` + `thread_id`，框架自动恢复 | `ConversationStore`，手动读写 |
| 情感识别 | 图节点 + `with_structured_output(..., method="json_mode")` | `Runner.run(sentiment_agent)`，`output_type=SentimentResult` |
| 路由 | 条件边 `route_by_sentiment` | Python `if/else` |
| 回应流式 | `graph.astream_events` 过滤节点 token | `Runner.run_streamed()` → `stream_events()` |
| DeepSeek 接入 | `ChatOpenAI(base_url=...)` | `OpenAIChatCompletionsModel(openai_client=...)` |
| `main.py` / `sse.py` / `contracts.py` | **逐字相同** | **逐字相同** |
| 对外 SSE 协议 | **完全相同** | **完全相同** |

---

## 关键实现说明

1. **情感识别只看当前轮**：LangGraph 节点取 `state["messages"][-1]`；Agents 侧只把
   `req.message` 传给情感 Agent，避免历史情绪标签污染当前判断。回复 Agent 使用完整历史。
2. **助手回复也写入历史**：LangGraph 回复节点同时返回 `messages: [AIMessage(...)]`，
   否则 checkpointer 只保存用户消息，多轮上下文会缺一半。情感结果以原生 dict 存入
   state，避免 LangGraph checkpoint 对自定义 Pydantic 类的反序列化告警。
3. **结构化输出与兜底**：
   - LangGraph 显式使用 JSON mode（`response_format={"type":"json_object"}`），因为
     当前 `langchain-openai` 的默认 `json_schema` 在 DeepSeek 上不一定可用；
   - Agents SDK 的 `output_type` 在 Chat Completions 下只能发 `json_schema`，若 400 则自动
     退化为“纯文本 JSON + Python 解析”；
   - 两种兜底都由 `coerce_sentiment()` 统一收敛为 `SentimentResult`，进程内记忆失败结果，
     后续请求不再重复尝试注定失败的路径。
4. **异常只在 SSE generator 内捕获**：`StreamingResponse` 一旦开始发送，HTTP 状态码已固定，
   业务异常统一转成 `event: error`。
5. **断开即停**：`main.py` 在推流循环检查 `request.is_disconnected()`；Agents 侧在
   `finally` 中 `streamed.cancel()`，避免继续消耗 DeepSeek 请求。
6. **async 路径不阻塞**：两个后端全程 `await` SDK 的异步接口，无同步阻塞调用。
7. **前端 SSE 解析**：按 `\n\n` 切分并保留残余 buffer；逐 token 只修改最后一条消息对象的
   `content`，不整体替换数组；支持停止生成（`AbortController`）与新对话。
8. **会话持久化的边界**：两端都是进程内存储，重启即丢失；第一版按要求不做外部持久化，
   部署时必须 `--workers 1`。

### 已验证（Mock 环境）

- 两个后端均能输出 `sentiment → token × N → done`，中文正常、逐 token 到达；
- positive 路由到鼓励 Agent，negative / neutral 路由到排解 Agent；
- 同一 `thread_id` 第二轮请求：回复模型收到完整历史（system + user + assistant + user），
  情感识别仍只收到当前消息；
- 两种结构化输出被拒绝时，均能自动退化为文本 JSON 解析，且后续请求不再重试失败路径；
- 前端 `npm run build` 通过（Vue 编译无错误）。

真实 DeepSeek 端点下的效果需配置 `DEEPSEEK_API_KEY` 后自行验证；如结构化输出行为变化，
兜底逻辑会接管，但建议按设计文档 §12 再次确认字段与稳定性。
