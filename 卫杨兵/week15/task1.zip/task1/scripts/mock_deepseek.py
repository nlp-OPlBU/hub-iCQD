"""本地 Mock DeepSeek（OpenAI 兼容），用于没有 API Key 时联调两个后端。

它实现了 POST /v1/chat/completions 的流式与非流式响应，并模拟：
- DeepSeek 的 tool calling（LangGraph 的 with_structured_output 走这里）
- DeepSeek 的 response_format=json_schema（Agents SDK 的 output_type 走这里）
- 普通文本流式回复

用法：
    python scripts/mock_deepseek.py                 # 监听 127.0.0.1:8010
    MOCK_REJECT_JSON_SCHEMA=1 ...                   # 模拟不支持 json_schema，验证兜底
    MOCK_REJECT_TOOLS=1 ...                         # 模拟不支持 tool calling，验证兜底
    MOCK_DELAY=0.02 ...                             # 调整流式输出间隔

两个后端联调时设置：
    DEEPSEEK_API_KEY=mock
    DEEPSEEK_BASE_URL=http://127.0.0.1:8010/v1
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from typing import Any

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

app = FastAPI(title="Mock DeepSeek")

DELAY = float(os.getenv("MOCK_DELAY", "0.01"))
REJECT_JSON_SCHEMA = os.getenv("MOCK_REJECT_JSON_SCHEMA", "0") == "1"
REJECT_JSON_OBJECT = os.getenv("MOCK_REJECT_JSON_OBJECT", "0") == "1"
REJECT_TOOLS = os.getenv("MOCK_REJECT_TOOLS", "0") == "1"

POSITIVE_WORDS = (
    "开心", "高兴", "升职", "加薪", "终于", "太好了", "喜欢",
    "顺利", "成功", "骄傲", "幸福", "哈哈", "棒", "惊喜",
)
NEGATIVE_WORDS = (
    "难过", "批评", "累", "焦虑", "伤心", "委屈", "压力", "烦",
    "失望", "孤独", "害怕", "生气", "哭", "崩溃", "糟糕", "内耗",
)

ENCOURAGE_REPLY = (
    "听起来这是一件值得开心的事，真的为你高兴。"
    "你的努力被看见、被认可，这种踏实又雀跃的感觉很珍贵。"
    "愿你把这份好心情延续下去，也别忘了好好犒劳一下自己。"
)
SOOTHE_REPLY = (
    "我听见你的难受了，被这样对待确实会委屈和失落，这些感受都很正常。"
    "先允许自己难过一会儿，不必急着把情绪压下去。"
    "等心情缓一缓，我们再一起看看这件事里有没有可以安放和调整的部分——你已经做得很好了。"
)


def detect_label(text: str) -> str:
    if any(word in text for word in POSITIVE_WORDS):
        return "positive"
    if any(word in text for word in NEGATIVE_WORDS):
        return "negative"
    return "neutral"


def sentiment_payload(text: str) -> dict[str, Any]:
    label = detect_label(text)
    return {"label": label, "confidence": 0.95 if label != "neutral" else 0.6}


def reply_for(text: str) -> str:
    return ENCOURAGE_REPLY if detect_label(text) == "positive" else SOOTHE_REPLY


def last_user_text(messages: list[dict[str, Any]]) -> str:
    for message in reversed(messages):
        if message.get("role") != "user":
            continue
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = [
                part.get("text", "")
                for part in content
                if isinstance(part, dict) and isinstance(part.get("text"), str)
            ]
            return "".join(parts)
    return ""


def is_sentiment_prompt(messages: list[dict[str, Any]]) -> bool:
    """识别“纯文本兜底”的情感分析请求（没有 tools / response_format）。"""
    for message in messages:
        if message.get("role") not in ("system", "developer"):
            continue
        content = message.get("content")
        if isinstance(content, str) and "情感分析器" in content:
            return True
    return False


def first_tool_name(body: dict[str, Any]) -> str | None:
    for tool in body.get("tools") or []:
        function = (tool or {}).get("function") or {}
        name = function.get("name")
        if isinstance(name, str) and name:
            return name
    return None


def json_mode(body: dict[str, Any]) -> str | None:
    """返回 response_format 类型：json_schema / json_object / None。"""
    response_format = body.get("response_format") or {}
    kind = response_format.get("type")
    return kind if kind in ("json_schema", "json_object") else None


def error_body(message: str) -> dict[str, Any]:
    return {
        "error": {
            "message": message,
            "type": "invalid_request_error",
            "code": "mock_rejected",
        }
    }


def base_chunk(body: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": f"chatcmpl-mock-{uuid.uuid4().hex[:16]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": body.get("model", "deepseek-chat"),
    }


def chunk_body(body: dict[str, Any], delta: dict[str, Any], finish_reason: str | None = None):
    payload = base_chunk(body)
    payload["choices"] = [
        {"index": 0, "delta": delta, "finish_reason": finish_reason}
    ]
    return payload


def text_chunks(text: str, size: int = 4) -> list[str]:
    return [text[i : i + size] for i in range(0, len(text), size)]


def sse_chunks_for_tool_call(
    body: dict[str, Any], tool_name: str, arguments: str
):
    call_id = f"call_mock_{uuid.uuid4().hex[:12]}"
    yield chunk_body(
        body,
        {
            "role": "assistant",
            "content": "",
            "tool_calls": [
                {
                    "index": 0,
                    "id": call_id,
                    "type": "function",
                    "function": {"name": tool_name, "arguments": ""},
                }
            ],
        },
    )
    # 参数分片下发，模拟真实 OpenAI 兼容流的 tool_call 增量。
    for fragment in text_chunks(arguments, size=8):
        yield chunk_body(
            body,
            {
                "tool_calls": [
                    {"index": 0, "function": {"arguments": fragment}}
                ]
            },
        )
    yield chunk_body(body, {}, finish_reason="tool_calls")


def sse_chunks_for_text(body: dict[str, Any], text: str):
    yield chunk_body(body, {"role": "assistant", "content": ""})
    for piece in text_chunks(text):
        yield chunk_body(body, {"content": piece})
    yield chunk_body(body, {}, finish_reason="stop")


async def stream_sse(chunks) -> Any:
    for chunk in chunks:
        await asyncio.sleep(DELAY)
        yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
    yield "data: [DONE]\n\n"


def completion_response(
    body: dict[str, Any], message: dict[str, Any], finish_reason: str
) -> JSONResponse:
    return JSONResponse(
        {
            "id": f"chatcmpl-mock-{uuid.uuid4().hex[:16]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": body.get("model", "deepseek-chat"),
            "choices": [
                {"index": 0, "message": message, "finish_reason": finish_reason}
            ],
            "usage": {"prompt_tokens": 20, "completion_tokens": 30, "total_tokens": 50},
        }
    )


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "reject_json_schema": REJECT_JSON_SCHEMA,
        "reject_json_object": REJECT_JSON_OBJECT,
        "reject_tools": REJECT_TOOLS,
    }


@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    messages = body.get("messages") or []
    user_text = last_user_text(messages)
    stream = bool(body.get("stream"))
    tool_name = first_tool_name(body)
    json_kind = json_mode(body)
    sentiment_prompt = is_sentiment_prompt(messages)

    print(
        f"[mock] messages={len(messages)} stream={stream} tools={tool_name!r} "
        f"json={json_kind!r} sentiment={sentiment_prompt} user={user_text[:60]!r}",
        flush=True,
    )

    if REJECT_TOOLS and tool_name:
        return JSONResponse(status_code=400, content=error_body("tools are not supported"))
    if REJECT_JSON_SCHEMA and json_kind == "json_schema":
        return JSONResponse(
            status_code=400, content=error_body("response_format json_schema is not supported")
        )
    if REJECT_JSON_OBJECT and json_kind == "json_object":
        return JSONResponse(
            status_code=400, content=error_body("response_format json_object is not supported")
        )

    args = json.dumps(sentiment_payload(user_text), ensure_ascii=False)

    if stream:
        if tool_name:
            return StreamingResponse(
                stream_sse(sse_chunks_for_tool_call(body, tool_name, args)),
                media_type="text/event-stream",
            )
        if json_kind or sentiment_prompt:
            return StreamingResponse(
                stream_sse(sse_chunks_for_text(body, args)),
                media_type="text/event-stream",
            )
        return StreamingResponse(
            stream_sse(sse_chunks_for_text(body, reply_for(user_text))),
            media_type="text/event-stream",
        )

    if tool_name:
        return completion_response(
            body,
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": f"call_mock_{uuid.uuid4().hex[:12]}",
                        "type": "function",
                        "function": {"name": tool_name, "arguments": args},
                    }
                ],
            },
            "tool_calls",
        )
    if json_kind or sentiment_prompt:
        return completion_response(
            body, {"role": "assistant", "content": args}, "stop"
        )
    return completion_response(
        body, {"role": "assistant", "content": reply_for(user_text)}, "stop"
    )


if __name__ == "__main__":
    uvicorn.run(
        app,
        host=os.getenv("MOCK_HOST", "127.0.0.1"),
        port=int(os.getenv("MOCK_PORT", "8010")),
        log_level="warning",
    )
