"""情感支持系统的 Streamlit 前端。

与 ``frontend/``（Vite + Vue）并列，只依赖同一套 SSE 协议：

    sentiment → token × N → done（失败时 error）

启动::

    cd frontend_streamlit
    pip install -r requirements.txt
    streamlit run app.py

后端地址通过环境变量 ``CHAT_API_BASE``（可写在同目录 ``.env``）或侧边栏设置，
默认 ``http://localhost:8001``（LangGraph），对比时切到 ``http://localhost:8002``（Agents）。
"""

from __future__ import annotations

import html
import os
import sys
import uuid
from pathlib import Path
from urllib.parse import urlparse

import streamlit as st

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

try:
    from dotenv import load_dotenv
except ImportError:  # 可选依赖：没有 python-dotenv 时只认环境变量
    pass
else:
    load_dotenv(APP_DIR / ".env")

from api.chat import ChatError, check_health, stream_chat

try:
    # Streamlit 的“停止”按钮通过 StopException（BaseException 子类）打断脚本。
    from streamlit.runtime.scriptrunner_utils.exceptions import StopException
except ImportError:  # pragma: no cover - 兼容旧版 Streamlit
    from streamlit.runtime.scriptrunner.exceptions import StopException

DEFAULT_API_BASE = os.environ.get("CHAT_API_BASE", "http://localhost:8001").rstrip("/")
THREAD_QUERY_KEY = "thread"
CHAT_HEIGHT = 520

SUGGESTIONS = (
    "今天被领导批评了，好难过",
    "终于拿到了心仪的 offer，太开心了！",
    "最近有点迷茫，说不上好也说不上坏",
)

SENTIMENT_STYLE = {
    "positive": ("积极", "#1f6b49", "#e3f3e9"),
    "negative": ("消极", "#a4462f", "#fbe8e1"),
    "neutral": ("中性", "#5d6a72", "#edf0f2"),
}

FRAMEWORK_LABELS = {
    "langgraph": "LangGraph",
    "openai-agents": "OpenAI Agents",
}

PLACEHOLDER_TEXT = {
    "analyzing": "先让我感受一下你的情绪…",
    "streaming": "正在组织回应…",
    "stopped": "已停止生成。",
    "error": "抱歉，这次没能完成回应。",
    "done": "已收到。",
}

PAGE_CSS = """
<style>
  .block-container {
    max-width: 960px;
    padding-top: 2.1rem;
    padding-bottom: 0.6rem;
  }
  @keyframes es-pulse {
    0%, 100% { transform: scale(0.8); opacity: 0.45; }
    50% { transform: scale(1.15); opacity: 1; }
  }
  .es-pulse-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #2f7d6c;
    display: inline-block;
    animation: es-pulse 1.15s ease-in-out infinite;
  }
  @media (prefers-reduced-motion: reduce) {
    .es-pulse-dot { animation: none; }
  }
</style>
"""

BRAND_HTML = """
<div style="display:flex;align-items:center;gap:12px;min-width:0;">
  <div style="width:42px;height:42px;border-radius:14px;
              background:linear-gradient(140deg,#2f7d6c,#256254);
              color:#f6fffb;display:grid;place-items:center;
              font-size:19px;font-weight:600;
              box-shadow:0 10px 22px rgba(47,125,108,.28);">心</div>
  <div style="min-width:0;">
    <div style="font-size:17px;font-weight:650;color:#24332f;line-height:1.3;">
      情感支持助手
    </div>
    <div style="font-size:12.5px;color:#6d7b76;margin-top:3px;">
      先识别情绪，再决定如何回应
    </div>
  </div>
</div>
"""

WELCOME_HTML = """
<div style="display:flex;flex-direction:column;align-items:center;
            text-align:center;gap:10px;padding:52px 12px 18px;">
  <div style="width:66px;height:66px;border-radius:22px;
              background:linear-gradient(140deg,#2f7d6c,#256254);
              color:#f6fffb;display:grid;place-items:center;
              font-size:27px;font-weight:600;
              box-shadow:0 18px 38px rgba(47,125,108,.30);">心</div>
  <div style="font-size:24px;font-weight:650;color:#24332f;margin-top:8px;">
    今天感觉怎么样？
  </div>
  <div style="max-width:440px;color:#6d7b76;font-size:14px;line-height:1.8;">
    说说此刻的心情吧。系统会先判断你的情绪，<br/>
    再由鼓励或排解 Agent 回应。
  </div>
</div>
"""


def new_thread_id() -> str:
    return str(uuid.uuid4())


def normalize_api_base(raw: str) -> str:
    """归一化后端地址；空值或明显无效时回退到环境变量里的默认值。"""
    value = (raw or "").strip()
    if not value:
        return DEFAULT_API_BASE
    if "://" not in value:
        value = f"http://{value}"
    value = value.rstrip("/")

    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return DEFAULT_API_BASE
    return value


def framework_label(name: str) -> str:
    return FRAMEWORK_LABELS.get(name, name)


def _first_query_value(key: str) -> str | None:
    try:
        value = st.query_params.get(key)
    except Exception:  # pragma: no cover - 嵌入环境或测试环境可能不支持
        return None
    if isinstance(value, list):
        value = value[0] if value else None
    return value if isinstance(value, str) and value else None


def _remember_thread(thread_id: str) -> None:
    """把 thread_id 写进 URL，刷新页面后仍能沿用后端内存里的会话。"""
    try:
        st.query_params[THREAD_QUERY_KEY] = thread_id
    except Exception:  # pragma: no cover - query params 不可用时静默降级
        pass


def init_state() -> None:
    ss = st.session_state
    ss.setdefault("messages", [])
    ss.setdefault("framework", "")
    ss.setdefault("pending_prompt", None)

    if "api_base" not in ss:
        ss.api_base = DEFAULT_API_BASE
    ss.setdefault("api_base_active", ss.api_base)

    if "thread_id" not in ss:
        restored = _first_query_value(THREAD_QUERY_KEY)
        ss.thread_id = restored or new_thread_id()
        if not restored:
            _remember_thread(ss.thread_id)


def reset_conversation(*, new_thread: bool = True) -> None:
    ss = st.session_state
    ss.messages = []
    ss.framework = ""
    ss.pending_prompt = None
    if new_thread:
        ss.thread_id = new_thread_id()
        _remember_thread(ss.thread_id)


def inject_css() -> None:
    st.markdown(PAGE_CSS, unsafe_allow_html=True)


def sentiment_pill_html(label: str, confidence: float | None) -> str:
    text, fg, bg = SENTIMENT_STYLE.get(label, (label, "#5d6a72", "#edf0f2"))
    confidence_html = ""
    if isinstance(confidence, (int, float)) and not isinstance(confidence, bool):
        confidence_html = (
            '<span style="font-weight:500;opacity:.65;margin-left:6px;">'
            f"{round(float(confidence) * 100)}%</span>"
        )

    return (
        '<span style="display:inline-flex;align-items:center;gap:6px;'
        "padding:4px 10px;border-radius:999px;"
        f"background:{bg};color:{fg};font-size:0.78rem;font-weight:600;"
        'letter-spacing:0.02em;line-height:1.4;">'
        '<span style="width:6px;height:6px;border-radius:50%;'
        'background:currentColor;opacity:.75;"></span>'
        f"{html.escape(text)}{confidence_html}</span>"
    )


def analyzing_html() -> str:
    return (
        '<span style="display:inline-flex;align-items:center;gap:7px;'
        'color:#6d7b76;font-size:0.82rem;line-height:1.4;">'
        '<span class="es-pulse-dot"></span>正在识别情绪…</span>'
    )


def framework_chip_html(framework: str) -> str:
    label = html.escape(framework_label(framework))
    return (
        '<div style="text-align:right;">'
        '<span style="display:inline-block;padding:6px 10px;border-radius:999px;'
        'background:#e6f1ed;color:#256254;font-size:10.5px;font-weight:600;'
        'letter-spacing:0.06em;text-transform:uppercase;white-space:nowrap;">'
        f"SSE · {label}</span></div>"
    )


def assistant_meta_html(message: dict) -> str:
    sentiment = message.get("sentiment")
    if isinstance(sentiment, str) and sentiment:
        confidence = message.get("confidence")
        if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
            confidence = None
        return sentiment_pill_html(sentiment, confidence)
    if message.get("status") == "analyzing":
        return analyzing_html()
    return ""


def render_sidebar() -> None:
    ss = st.session_state

    with st.sidebar:
        st.markdown("### 连接设置")
        raw_api_base = st.text_input(
            "后端地址",
            value=ss.api_base,
            key="api_base_input",
            help="LangGraph: http://localhost:8001 · OpenAI Agents: http://localhost:8002",
        )
        api_base = normalize_api_base(raw_api_base)

        if api_base != ss.api_base_active:
            ss.api_base = api_base
            ss.api_base_active = api_base
            reset_conversation()
            st.toast("已切换后端，并开始新对话")
        else:
            ss.api_base = api_base

        if st.button("检查连接", width="stretch"):
            try:
                payload = check_health(api_base)
                st.success(f"连接正常（{payload.get('status', 'ok')}）")
            except ChatError as exc:
                st.error(str(exc))

        st.caption(f"当前使用：`{api_base}`")
        st.caption("LangGraph `:8001` · Agents `:8002`")
        st.divider()

        st.markdown("### 当前会话")
        st.caption(f"thread_id：`{ss.thread_id[:8]}…`")
        current = framework_label(ss.framework) if ss.framework else "等待首次回复"
        st.caption(f"框架：{current}")
        st.divider()
        st.caption("SSE 事件流：sentiment → token × N → done")


def render_header():
    """渲染品牌区与“新对话”按钮，返回可实时更新的框架标签占位符。"""
    ss = st.session_state
    brand_col, chip_col, action_col = st.columns(
        [5, 2, 1], vertical_alignment="center"
    )

    with brand_col:
        st.markdown(BRAND_HTML, unsafe_allow_html=True)

    with chip_col:
        chip_slot = st.empty()
        if ss.framework:
            chip_slot.markdown(
                framework_chip_html(ss.framework), unsafe_allow_html=True
            )

    with action_col:
        if st.button("新对话", width="stretch"):
            reset_conversation()
            st.rerun()

    return chip_slot


def render_welcome() -> None:
    st.markdown(WELCOME_HTML, unsafe_allow_html=True)

    _, middle, _ = st.columns([1, 2.4, 1])
    with middle:
        for index, suggestion in enumerate(SUGGESTIONS):
            if st.button(suggestion, key=f"suggestion-{index}", width="stretch"):
                st.session_state.pending_prompt = suggestion
                st.rerun()


def render_message(message: dict) -> None:
    if message["role"] == "user":
        with st.chat_message("user", avatar="🧑"):
            st.markdown(message["content"])
        return

    with st.chat_message("assistant", avatar="🌿"):
        meta = assistant_meta_html(message)
        if meta:
            st.markdown(meta, unsafe_allow_html=True)

        content = message.get("content") or ""
        if content:
            st.markdown(content)
        else:
            placeholder = PLACEHOLDER_TEXT.get(message.get("status", ""))
            if placeholder:
                st.caption(placeholder)

        if message.get("error"):
            st.error(message["error"])


def render_history() -> None:
    for message in st.session_state.messages:
        render_message(message)


def run_turn(prompt: str, chip_slot) -> None:
    """处理一轮对话：先渲染用户消息，再消费 SSE 并逐 token 更新占位符。"""
    ss = st.session_state
    ss.framework = ""
    chip_slot.empty()

    ss.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user", avatar="🧑"):
        st.markdown(prompt)

    assistant: dict = {
        "role": "assistant",
        "content": "",
        "sentiment": None,
        "confidence": None,
        # analyzing | streaming | done | error | stopped
        "status": "analyzing",
        "error": "",
    }
    ss.messages.append(assistant)

    with st.chat_message("assistant", avatar="🌿"):
        meta_placeholder = st.empty()
        meta_placeholder.markdown(analyzing_html(), unsafe_allow_html=True)

        body_placeholder = st.empty()
        body_placeholder.caption(PLACEHOLDER_TEXT["analyzing"])
        error_placeholder = st.empty()

        def refresh_meta() -> None:
            label = assistant["sentiment"]
            if isinstance(label, str) and label:
                meta_placeholder.markdown(
                    sentiment_pill_html(label, assistant["confidence"]),
                    unsafe_allow_html=True,
                )
            elif assistant["status"] == "analyzing":
                meta_placeholder.markdown(analyzing_html(), unsafe_allow_html=True)
            else:
                meta_placeholder.empty()

        def refresh_body(*, caret: bool = False) -> None:
            content = assistant["content"]
            if content:
                # 只更新本轮的占位符，不重建整段历史（对应设计文档 §9.2 的思路）。
                body_placeholder.markdown(content + (" ▍" if caret else ""))
                return

            placeholder = PLACEHOLDER_TEXT.get(assistant["status"])
            if placeholder:
                body_placeholder.caption(placeholder)
            else:
                body_placeholder.empty()

        try:
            for event in stream_chat(
                api_base=ss.api_base_active,
                thread_id=ss.thread_id,
                message=prompt,
            ):
                if event.name == "sentiment":
                    label = event.data.get("label")
                    assistant["sentiment"] = label if isinstance(label, str) else None

                    confidence = event.data.get("confidence")
                    if isinstance(confidence, (int, float)) and not isinstance(
                        confidence, bool
                    ):
                        assistant["confidence"] = float(confidence)
                    else:
                        assistant["confidence"] = None

                    if assistant["status"] == "analyzing":
                        assistant["status"] = "streaming"
                    refresh_meta()
                    refresh_body()

                elif event.name == "token":
                    delta = event.data.get("delta")
                    if isinstance(delta, str) and delta:
                        assistant["content"] += delta
                        assistant["status"] = "streaming"
                        refresh_body(caret=True)

                elif event.name == "done":
                    framework = event.data.get("framework")
                    if isinstance(framework, str) and framework:
                        assistant["framework"] = framework
                        ss.framework = framework
                        chip_slot.markdown(
                            framework_chip_html(framework), unsafe_allow_html=True
                        )
                    if assistant["status"] != "error":
                        assistant["status"] = "done"

                elif event.name == "error":
                    message = event.data.get("message")
                    assistant["error"] = (
                        message
                        if isinstance(message, str) and message
                        else "服务端发生未知错误"
                    )
                    assistant["status"] = "error"

            if assistant["status"] == "analyzing":
                assistant["error"] = "连接已结束，但没有收到任何响应。"
                assistant["status"] = "error"
            elif assistant["status"] == "streaming":
                # 流正常结束但没收到 done 事件时，按完成处理。
                assistant["status"] = "done"

        except StopException:
            assistant["status"] = "stopped"
            raise
        except ChatError as exc:
            assistant["status"] = "error"
            assistant["error"] = str(exc)
        except Exception as exc:  # noqa: BLE001 - 兜底：任何错误都要展示给用户
            assistant["status"] = "error"
            assistant["error"] = f"发生未预期错误：{exc}"
        finally:
            refresh_meta()
            refresh_body(caret=False)
            if assistant["error"]:
                error_placeholder.error(assistant["error"])


def main() -> None:
    st.set_page_config(
        page_title="情感支持助手",
        page_icon="💚",
        layout="centered",
    )

    init_state()
    inject_css()

    render_sidebar()
    chip_slot = render_header()

    submitted = st.chat_input(
        "说说此刻的心情…",
        max_chars=4000,
        submit_mode="stop",
    )

    pending = st.session_state.pop("pending_prompt", None)
    if isinstance(submitted, str) and submitted.strip():
        pending = submitted.strip()

    with st.container(height=CHAT_HEIGHT, border=False):
        if not st.session_state.messages and not pending:
            render_welcome()
        else:
            render_history()

        if pending:
            run_turn(pending, chip_slot)


if __name__ == "__main__":
    main()
