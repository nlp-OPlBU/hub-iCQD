# Streamlit 前端（与 `frontend/` 并列）

第二套前端，交互与 `frontend/`（Vite + Vue）一致，**只依赖统一 SSE 协议**
（`sentiment → token × N → done`，失败时 `error`），两个后端均无需改动。

## 目录结构

```text
frontend_streamlit/
├── app.py                  # 聊天界面（对应 frontend/src/App.vue）
├── api/chat.py             # httpx 流式请求 + SSE 解析（对应 frontend/src/api/chat.js）
├── .streamlit/config.toml  # 暖色主题
├── requirements.txt
├── Dockerfile
├── .dockerignore
├── .env.example
└── README.md
```

`api/chat.py` 与 Vue 版解析逻辑一一对应：按空行切分事件、保留跨 chunk 的残余
buffer、只认 `event` / `data` 字段；不同的是用 httpx 的流式响应替代
`fetch + ReadableStream`。

## 本地启动

先按根目录 README 启动任一后端（例如 LangGraph `:8001`），然后：

```bash
cd frontend_streamlit
pip install -r requirements.txt
streamlit run app.py
```

打开 `http://localhost:8501`。

默认后端地址是 `http://localhost:8001`（LangGraph），可在页面上：

- 左侧边栏直接修改「后端地址」（如 `http://localhost:8002` 切到 Agents），
  切换后会自动开始新对话；
- 点击「检查连接」请求 `GET /health` 验证连通性。

也可用环境变量或 `.env` 固定：

```bash
cp .env.example .env       # CHAT_API_BASE=http://localhost:8001
```

## 与 Vue 前端的对应关系

| 能力 | `frontend/` | `frontend_streamlit/` |
|---|---|---|
| 页面结构 | `src/App.vue` | `app.py` |
| SSE 解析 | `src/api/chat.js`（fetch + ReadableStream） | `api/chat.py`（httpx 流式响应） |
| 后端地址 | `.env.development` 的 `VITE_API_BASE` | `.env` 的 `CHAT_API_BASE` / 侧边栏 |
| 多轮会话 | `localStorage` 保存 `thread_id` | URL `?thread=…` + `st.session_state` |
| 先情绪标签后回复 | sentiment pill + 逐 token 渲染 | sentiment 占位符 + `st.empty()` 逐 token 更新 |
| 停止生成 | `AbortController` | `st.chat_input(submit_mode="stop")` |
| 新对话 | 换 `thread_id` 并清屏 | 换 `thread_id` 并清屏 |

说明：

- Streamlit 是**服务端**发起请求，浏览器不直连后端。Docker 中的地址应写成
  `http://backend-langgraph:8001` / `http://backend-agents:8002`，而不是 `localhost`。
- 刷新页面会恢复 URL 上的 `thread_id`（后端内存中的历史仍在），但界面消息列表会清空，
  与 Vue 版刷新后只保留 `thread_id` 的行为一致。
- 点击聊天框的「停止」后，Streamlit 停止当前脚本执行，正在消费的 SSE 生成器随之关闭，
  后端会检测到客户端断开并停止向 DeepSeek 继续请求；已生成的部分内容会保留。
  （若本轮是由建议按钮而非聊天框触发的，可点击页面右上角的运行状态 Stop 按钮。）

## Docker

根目录执行：

```bash
docker compose up --build frontend-streamlit
```

打开 `http://localhost:8501`。容器内 `CHAT_API_BASE` 默认指向
`http://backend-langgraph:8001`，可在根目录 `.env` 中覆盖。
