"""Streamlit 前端使用的 SSE 客户端。

与 ``frontend/src/api/chat.js`` 一一对应：用 httpx 的流式响应替代
fetch + ReadableStream，但解析语义完全一致：

- 不用 EventSource（它只支持 GET，无法携带 thread_id / message 这样的 POST body）；
- 严格按空行切分事件，并保留跨 chunk 的残余 buffer（一个 chunk ≠ 一条 SSE 消息）；
- 只消费两个后端完全一致的事件协议：

      event: sentiment  data: {"label": ..., "confidence": ...}
      event: token      data: {"delta": "..."}
      event: done       data: {"framework": "..."}
      event: error      data: {"message": "..."}
"""

from __future__ import annotations

import codecs
import json
from dataclasses import dataclass
from typing import Any, Iterator

import httpx

CONNECT_TIMEOUT = 10.0
READ_TIMEOUT = 180.0
WRITE_TIMEOUT = 30.0
POOL_TIMEOUT = 10.0


class ChatError(RuntimeError):
    """调用 ``/chat`` 或 ``/health`` 失败时抛出的统一异常。"""


@dataclass(frozen=True)
class SSEEvent:
    """一条解析完成的 SSE 事件。"""

    name: str
    data: dict[str, Any]


def parse_event_block(block: str) -> SSEEvent | None:
    """解析一个 SSE 事件块（不含结尾空行），语义与前端 JS 实现一致。"""
    event_name = "message"
    data_lines: list[str] = []

    for line in block.split("\n"):
        if not line or line.startswith(":"):
            continue

        colon = line.find(":")
        if colon == -1:
            field, value = line, ""
        else:
            field = line[:colon]
            value = line[colon + 1 :]
            if value.startswith(" "):
                value = value[1:]

        if field == "event":
            event_name = value
        elif field == "data":
            data_lines.append(value)

    if not data_lines:
        return None

    try:
        data = json.loads("\n".join(data_lines))
    except json.JSONDecodeError:
        return None

    if not isinstance(data, dict):
        return None

    return SSEEvent(name=event_name, data=data)


class SSEDecoder:
    """增量 UTF-8 / SSE 解码器，能处理任意切片位置上的 chunk 边界。"""

    def __init__(self) -> None:
        self._buffer = ""
        # errors="replace"：即使上游不慎发出非法 UTF-8，也不会让整个会话崩溃。
        self._decoder = codecs.getincrementaldecoder("utf-8")("replace")

    def feed(self, chunk: bytes) -> list[SSEEvent]:
        """喂入一段原始字节，返回其中已经完整的事件。"""
        self._buffer += self._decoder.decode(chunk)
        return self._drain(final=False)

    def close(self) -> list[SSEEvent]:
        """结束输入：刷新解码器，并处理没有结尾空行的最后一条事件。"""
        self._buffer += self._decoder.decode(b"", final=True)
        return self._drain(final=True)

    def _drain(self, *, final: bool) -> list[SSEEvent]:
        # 与 JS 版相同：先归一化 CRLF，再按空行切分，残余 buffer 留到下一次。
        self._buffer = self._buffer.replace("\r\n", "\n")
        events: list[SSEEvent] = []

        while True:
            boundary = self._buffer.find("\n\n")
            if boundary == -1:
                break

            block = self._buffer[:boundary]
            self._buffer = self._buffer[boundary + 2 :]
            event = parse_event_block(block)
            if event is not None:
                events.append(event)

        if final and self._buffer.strip():
            event = parse_event_block(self._buffer)
            if event is not None:
                events.append(event)
            self._buffer = ""

        return events


def _describe_http_error(status_code: int, body: str) -> str:
    """从 FastAPI / 代理返回的错误体中尽量提取可读信息。"""
    payload: Any = None
    if body:
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            payload = None

    if isinstance(payload, dict):
        detail = payload.get("detail")
        if detail is None:
            error = payload.get("error")
            if isinstance(error, dict):
                detail = error.get("message")
        if detail is None:
            detail = payload.get("message")

        if isinstance(detail, str) and detail:
            return detail
        if detail is not None:
            try:
                return json.dumps(detail, ensure_ascii=False)
            except (TypeError, ValueError):
                return str(detail)

    if body:
        return f"HTTP {status_code}：{body[:200]}"
    return f"HTTP {status_code}"


def stream_chat(
    *,
    api_base: str,
    thread_id: str,
    message: str,
    timeout: httpx.Timeout | None = None,
) -> Iterator[SSEEvent]:
    """发起一次对话，逐个产出 SSE 事件。

    该函数是生成器：调用方每消费一个事件，底层的 HTTP 流才会继续推进。
    调用方提前关闭生成器（例如点击停止）会关闭连接，后端据此停止付费请求。
    """
    url = f"{api_base.rstrip('/')}/chat"
    request_timeout = timeout or httpx.Timeout(
        connect=CONNECT_TIMEOUT,
        read=READ_TIMEOUT,
        write=WRITE_TIMEOUT,
        pool=POOL_TIMEOUT,
    )

    try:
        with httpx.Client(timeout=request_timeout) as client:
            with client.stream(
                "POST",
                url,
                json={"thread_id": thread_id, "message": message},
                headers={"Accept": "text/event-stream"},
            ) as response:
                if response.status_code >= 400:
                    body = response.read().decode("utf-8", errors="replace")
                    reason = _describe_http_error(response.status_code, body)
                    raise ChatError(f"请求失败（{reason}）")

                decoder = SSEDecoder()
                for chunk in response.iter_bytes():
                    yield from decoder.feed(chunk)
                yield from decoder.close()
    except (httpx.HTTPError, httpx.InvalidURL) as exc:
        raise ChatError(f"无法连接后端 {url}：{exc}") from exc


def check_health(api_base: str, *, timeout: float = 5.0) -> dict[str, Any]:
    """调用 ``GET /health``，用于侧边栏的连通性检查。"""
    url = f"{api_base.rstrip('/')}/health"

    try:
        response = httpx.get(url, timeout=timeout)
    except (httpx.HTTPError, httpx.InvalidURL) as exc:
        raise ChatError(f"无法连接后端 {url}：{exc}") from exc

    if response.status_code >= 400:
        reason = _describe_http_error(response.status_code, response.text)
        raise ChatError(f"健康检查失败（{reason}）")

    try:
        payload = response.json()
    except ValueError:
        return {"status": response.text.strip() or "ok"}

    return payload if isinstance(payload, dict) else {"status": str(payload)}
