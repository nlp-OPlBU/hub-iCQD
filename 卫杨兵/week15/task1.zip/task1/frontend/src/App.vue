<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref } from 'vue'

import { streamChat } from './api/chat'

const THREAD_STORAGE_KEY = 'emotion-support:thread-id'

const suggestions = [
  '今天被领导批评了，好难过',
  '终于拿到了心仪的 offer，太开心了！',
  '最近有点迷茫，说不上好也说不上坏',
]

const messages = ref([])
const input = ref('')
const streaming = ref(false)
const framework = ref('')
const threadId = ref('')
const scrollArea = ref(null)
const composerEl = ref(null)

let controller = null
let requestSeq = 0
let scrollScheduled = false
let stickToBottom = true

const canSend = computed(() => input.value.trim().length > 0 && !streaming.value)

const frameworkLabel = computed(() => {
  if (framework.value === 'langgraph') return 'LangGraph'
  if (framework.value === 'openai-agents') return 'OpenAI Agents'
  return framework.value
})

const sentimentText = (label) =>
  ({ positive: '积极', negative: '消极', neutral: '中性' })[label] || label

function newId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID()
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0
    const value = char === 'x' ? random : (random & 0x3) | 0x8
    return value.toString(16)
  })
}

function persistThreadId() {
  try {
    localStorage.setItem(THREAD_STORAGE_KEY, threadId.value)
  } catch {
    /* 隐私模式等场景下 localStorage 不可用，忽略即可 */
  }
}

onMounted(() => {
  let saved = ''
  try {
    saved = localStorage.getItem(THREAD_STORAGE_KEY) || ''
  } catch {
    saved = ''
  }
  threadId.value = saved || newId()
  persistThreadId()
  composerEl.value?.focus()
})

onBeforeUnmount(() => {
  controller?.abort()
})

function onScroll() {
  const el = scrollArea.value
  if (!el) return
  stickToBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120
}

function scheduleScroll() {
  if (!stickToBottom || scrollScheduled) return
  scrollScheduled = true
  requestAnimationFrame(() => {
    scrollScheduled = false
    const el = scrollArea.value
    if (el) el.scrollTop = el.scrollHeight
  })
}

function autoResize() {
  const el = composerEl.value
  if (!el) return
  el.style.height = 'auto'
  el.style.height = `${Math.min(el.scrollHeight, 160)}px`
}

function resetComposerHeight() {
  nextTick(() => {
    const el = composerEl.value
    if (el) el.style.height = 'auto'
  })
}

function onEnter(event) {
  if (event.isComposing || event.keyCode === 229) return
  event.preventDefault()
  send()
}

async function send() {
  const text = input.value.trim()
  if (!text || streaming.value) return

  const requestId = ++requestSeq
  input.value = ''
  resetComposerHeight()
  framework.value = ''
  stickToBottom = true

  messages.value.push({ id: newId(), role: 'user', content: text })

  const assistant = reactive({
    id: newId(),
    role: 'assistant',
    content: '',
    sentiment: null,
    confidence: null,
    // analyzing | streaming | done | error | stopped
    status: 'analyzing',
    error: '',
  })
  messages.value.push(assistant)
  streaming.value = true
  controller = new AbortController()
  scheduleScroll()

  try {
    await streamChat({
      threadId: threadId.value,
      message: text,
      signal: controller.signal,
      onEvent(type, data) {
        if (type === 'sentiment') {
          assistant.sentiment = typeof data.label === 'string' ? data.label : null
          assistant.confidence =
            typeof data.confidence === 'number' ? data.confidence : null
          if (assistant.status === 'analyzing') assistant.status = 'streaming'
        } else if (type === 'token') {
          if (typeof data.delta === 'string' && data.delta) {
            // 只改最后一条消息对象的 content，不整体替换数组（设计文档 §9.2）。
            assistant.content += data.delta
            assistant.status = 'streaming'
            scheduleScroll()
          }
        } else if (type === 'done') {
          if (typeof data.framework === 'string') framework.value = data.framework
          if (assistant.status !== 'error') assistant.status = 'done'
        } else if (type === 'error') {
          assistant.error = data.message || '服务端发生未知错误'
          assistant.status = 'error'
        }
      },
    })

    if (assistant.status === 'analyzing') {
      assistant.error = '连接已结束，但没有收到任何响应。'
      assistant.status = 'error'
    } else if (assistant.status === 'streaming') {
      // 流正常结束但没收到 done 事件时，按完成处理。
      assistant.status = 'done'
    }
  } catch (error) {
    if (error?.name === 'AbortError') {
      assistant.status = 'stopped'
    } else {
      assistant.error = error?.message || String(error)
      assistant.status = 'error'
    }
  } finally {
    if (requestId === requestSeq) {
      streaming.value = false
      controller = null
      scheduleScroll()
      composerEl.value?.focus()
    }
  }
}

function stop() {
  controller?.abort()
}

function resetConversation() {
  requestSeq += 1
  controller?.abort()
  controller = null
  streaming.value = false
  messages.value = []
  framework.value = ''
  input.value = ''
  stickToBottom = true
  threadId.value = newId()
  persistThreadId()
  resetComposerHeight()
  nextTick(() => composerEl.value?.focus())
}

function useSuggestion(suggestion) {
  if (streaming.value) return
  input.value = suggestion
  send()
}
</script>

<template>
  <div class="app-shell">
    <header class="app-header">
      <div class="brand">
        <div class="brand-mark" aria-hidden="true">心</div>
        <div>
          <h1>情感支持助手</h1>
          <p class="subtitle">先识别情绪，再决定如何回应</p>
        </div>
      </div>
      <div class="header-right">
        <span v-if="framework" class="framework-chip">SSE · {{ frameworkLabel }}</span>
        <button class="ghost-button" type="button" @click="resetConversation">新对话</button>
      </div>
    </header>

    <main ref="scrollArea" class="chat-scroll" aria-live="polite" @scroll="onScroll">
      <section v-if="messages.length === 0" class="welcome">
        <div class="welcome-mark" aria-hidden="true">心</div>
        <h2>今天感觉怎么样？</h2>
        <p>
          说说此刻的心情吧。系统会先判断你的情绪，<br />
          再由鼓励或排解 Agent 回应。
        </p>
        <div class="suggestions">
          <button
            v-for="suggestion in suggestions"
            :key="suggestion"
            class="suggestion-chip"
            type="button"
            @click="useSuggestion(suggestion)"
          >
            {{ suggestion }}
          </button>
        </div>
      </section>

      <section v-else class="message-list">
        <article
          v-for="message in messages"
          :key="message.id"
          class="message-row"
          :class="message.role"
        >
          <div v-if="message.role === 'assistant'" class="avatar" aria-hidden="true">心</div>

          <div class="bubble-wrap">
            <div v-if="message.role === 'assistant'" class="assistant-meta">
              <span
                v-if="message.sentiment"
                class="sentiment-pill"
                :class="message.sentiment"
              >
                <span class="dot" aria-hidden="true"></span>
                {{ sentimentText(message.sentiment) }}
                <span v-if="message.confidence !== null" class="confidence">
                  {{ Math.round(message.confidence * 100) }}%
                </span>
              </span>
              <span v-else-if="message.status === 'analyzing'" class="analyzing">
                <span class="pulse-dot" aria-hidden="true"></span>正在识别情绪
              </span>
            </div>

            <div class="bubble">
              <p v-if="message.content" class="content">
                {{ message.content
                }}<span v-if="message.status === 'streaming'" class="caret" aria-hidden="true"></span>
              </p>
              <p v-else-if="message.status === 'analyzing'" class="placeholder">
                先让我感受一下你的情绪…
              </p>
              <p v-else-if="message.status === 'streaming'" class="placeholder">
                正在组织回应…
              </p>
              <p v-else-if="message.status === 'stopped'" class="placeholder">
                已停止生成。
              </p>
              <p v-else-if="message.status === 'error'" class="placeholder">
                抱歉，这次没能完成回应。
              </p>
              <p v-else class="placeholder">已收到。</p>

              <p v-if="message.error" class="error-text">{{ message.error }}</p>
            </div>
          </div>
        </article>
      </section>
    </main>

    <footer class="composer">
      <div class="composer-box">
        <textarea
          ref="composerEl"
          v-model="input"
          rows="1"
          aria-label="输入消息"
          placeholder="说说此刻的心情…"
          :disabled="streaming"
          @input="autoResize"
          @keydown.enter="onEnter"
        ></textarea>

        <button
          v-if="streaming"
          class="primary-button danger"
          type="button"
          @click="stop"
        >
          停止
        </button>
        <button
          v-else
          class="primary-button"
          type="button"
          :disabled="!canSend"
          @click="send"
        >
          发送
        </button>
      </div>
      <p class="composer-hint">Enter 发送 · Shift + Enter 换行 · 回复由 SSE 流式生成</p>
    </footer>
  </div>
</template>

<style scoped>
.app-shell {
  width: min(900px, 100%);
  height: calc(100dvh - 48px);
  min-height: 520px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: 26px;
  box-shadow: var(--shadow);
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 18px 24px;
  border-bottom: 1px solid var(--border);
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.brand-mark,
.avatar,
.welcome-mark {
  display: grid;
  place-items: center;
  color: #f6fffb;
  background: linear-gradient(140deg, var(--accent), var(--accent-strong));
}

.brand-mark {
  width: 42px;
  height: 42px;
  border-radius: 14px;
  font-size: 19px;
  font-weight: 600;
  box-shadow: 0 10px 22px color-mix(in srgb, var(--accent) 28%, transparent);
}

h1 {
  margin: 0;
  font-size: 17px;
  font-weight: 650;
  letter-spacing: 0.01em;
}

.subtitle {
  margin: 3px 0 0;
  font-size: 12.5px;
  color: var(--text-muted);
}

.header-right {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: none;
}

.framework-chip {
  padding: 6px 10px;
  border-radius: 999px;
  background: var(--accent-soft);
  color: var(--accent-strong);
  font-size: 10.5px;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  white-space: nowrap;
}

.ghost-button {
  padding: 7px 14px;
  border: 1px solid var(--border);
  border-radius: 999px;
  background: transparent;
  color: var(--text-muted);
  font-size: 13px;
  cursor: pointer;
  transition: color 0.2s, border-color 0.2s, background 0.2s;
}

.ghost-button:hover {
  color: var(--accent-strong);
  border-color: var(--accent);
  background: var(--accent-soft);
}

.chat-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 28px 24px;
  scroll-behavior: smooth;
  background:
    radial-gradient(circle at 82% 0%, var(--glow) 0%, transparent 46%),
    var(--card-bg);
}

.welcome {
  min-height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  gap: 10px;
  padding: 32px 12px;
}

.welcome-mark {
  width: 66px;
  height: 66px;
  border-radius: 22px;
  font-size: 27px;
  font-weight: 600;
  box-shadow: 0 18px 38px color-mix(in srgb, var(--accent) 30%, transparent);
  animation: float 6s ease-in-out infinite;
}

.welcome h2 {
  margin: 8px 0 0;
  font-size: 24px;
  font-weight: 650;
  letter-spacing: 0.01em;
}

.welcome p {
  margin: 0;
  max-width: 440px;
  color: var(--text-muted);
  font-size: 14px;
  line-height: 1.8;
}

.suggestions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
  margin-top: 20px;
}

.suggestion-chip {
  padding: 9px 14px;
  border: 1px solid transparent;
  border-radius: 999px;
  background: var(--accent-soft);
  color: var(--accent-strong);
  font-size: 13px;
  cursor: pointer;
  transition: transform 0.18s, border-color 0.18s, background 0.18s;
}

.suggestion-chip:hover {
  transform: translateY(-1px);
  border-color: var(--accent);
  background: color-mix(in srgb, var(--accent-soft) 70%, var(--card-bg));
}

.message-list {
  display: flex;
  flex-direction: column;
  gap: 22px;
  max-width: 720px;
  margin: 0 auto;
}

.message-row {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  animation: rise 0.28s ease both;
}

.message-row.user {
  justify-content: flex-end;
}

.avatar {
  flex: none;
  width: 34px;
  height: 34px;
  border-radius: 12px;
  font-size: 15px;
  box-shadow: 0 8px 18px color-mix(in srgb, var(--accent) 24%, transparent);
}

.bubble-wrap {
  display: flex;
  flex-direction: column;
  gap: 6px;
  max-width: min(78%, 560px);
  min-width: 0;
}

.message-row.user .bubble-wrap {
  align-items: flex-end;
}

.assistant-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 24px;
  padding-left: 2px;
}

.sentiment-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11.5px;
  font-weight: 600;
  letter-spacing: 0.02em;
}

.sentiment-pill .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  opacity: 0.75;
}

.sentiment-pill.positive {
  background: var(--positive-bg);
  color: var(--positive-fg);
}

.sentiment-pill.negative {
  background: var(--negative-bg);
  color: var(--negative-fg);
}

.sentiment-pill.neutral {
  background: var(--neutral-bg);
  color: var(--neutral-fg);
}

.confidence {
  font-weight: 500;
  opacity: 0.65;
}

.analyzing {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  color: var(--text-muted);
  font-size: 12px;
}

.pulse-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--accent);
  animation: pulse 1.15s ease-in-out infinite;
}

.bubble {
  padding: 13px 16px;
  border-radius: 18px 18px 18px 6px;
  background: var(--assistant-bubble);
  border: 1px solid var(--border);
  box-shadow: var(--bubble-shadow);
}

.message-row.user .bubble {
  padding: 11px 16px;
  border: 0;
  border-radius: 18px 18px 6px 18px;
  background: var(--user-bubble);
  color: var(--user-bubble-text);
  box-shadow: none;
}

.content {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-size: 14.5px;
  line-height: 1.78;
}

.placeholder {
  margin: 0;
  color: var(--text-muted);
  font-size: 13.5px;
  font-style: italic;
  line-height: 1.7;
}

.error-text {
  margin: 8px 0 0;
  color: var(--danger);
  font-size: 13px;
  line-height: 1.6;
}

.caret {
  display: inline-block;
  width: 2px;
  height: 1.05em;
  margin-left: 2px;
  border-radius: 1px;
  background: var(--accent);
  vertical-align: -0.16em;
  animation: blink 0.9s steps(2, start) infinite;
}

.composer {
  padding: 16px 24px 18px;
  border-top: 1px solid var(--border);
  background: var(--composer-bg);
}

.composer-box {
  display: flex;
  align-items: flex-end;
  gap: 10px;
  max-width: 720px;
  margin: 0 auto;
  padding: 8px 8px 8px 16px;
  border: 1px solid var(--border);
  border-radius: 18px;
  background: var(--assistant-bubble);
  transition: border-color 0.2s, box-shadow 0.2s;
}

.composer-box:focus-within {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 16%, transparent);
}

textarea {
  flex: 1;
  min-height: 24px;
  max-height: 160px;
  padding: 8px 0;
  border: 0;
  outline: none;
  resize: none;
  background: transparent;
  color: var(--text);
  font-size: 14.5px;
  line-height: 1.6;
}

textarea::placeholder {
  color: var(--text-muted);
}

textarea:disabled {
  opacity: 0.6;
}

.primary-button {
  flex: none;
  padding: 10px 18px;
  border: 0;
  border-radius: 13px;
  background: var(--accent);
  color: #f7fffb;
  font-size: 13.5px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s, transform 0.15s, opacity 0.2s;
}

.primary-button:hover:not(:disabled) {
  background: var(--accent-strong);
}

.primary-button:active:not(:disabled) {
  transform: scale(0.97);
}

.primary-button:disabled {
  opacity: 0.38;
  cursor: not-allowed;
}

.primary-button.danger {
  background: var(--danger);
}

.composer-hint {
  max-width: 720px;
  margin: 10px auto 0;
  color: var(--text-muted);
  font-size: 11.5px;
  letter-spacing: 0.02em;
  text-align: center;
}

@keyframes float {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-6px);
  }
}

@keyframes pulse {
  0%,
  100% {
    transform: scale(0.8);
    opacity: 0.45;
  }
  50% {
    transform: scale(1.15);
    opacity: 1;
  }
}

@keyframes blink {
  50% {
    opacity: 0;
  }
}

@keyframes rise {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 640px) {
  .app-header {
    padding: 14px 16px;
  }

  .subtitle {
    display: none;
  }

  .framework-chip {
    display: none;
  }

  .chat-scroll {
    padding: 20px 14px;
  }

  .composer {
    padding: 12px 14px 14px;
  }

  .bubble-wrap {
    max-width: 84%;
  }

  .welcome h2 {
    font-size: 21px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .message-row,
  .welcome-mark,
  .pulse-dot,
  .caret {
    animation: none;
  }

  .chat-scroll {
    scroll-behavior: auto;
  }
}
</style>
