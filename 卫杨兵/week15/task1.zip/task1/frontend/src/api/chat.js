/**
 * 前端与后端之间唯一的 SSE 通道。
 *
 * 不用 EventSource：它只支持 GET，无法携带 thread_id / message 这样的 POST body。
 * 这里用 fetch + ReadableStream 手动解析 SSE，并严格按 \n\n 切分事件、
 * 保留不完整的残余 buffer（一个 chunk ≠ 一条 SSE 消息）。
 */

const DEFAULT_API_BASE = 'http://localhost:8001'

function resolveApiBase() {
  // 可选的 import.meta.env 使该模块也能在纯 Node 环境下做冒烟测试。
  const configured = import.meta.env?.VITE_API_BASE
  return (configured || DEFAULT_API_BASE).replace(/\/+$/, '')
}

function parseEventBlock(block) {
  let eventName = 'message'
  const dataLines = []

  for (const line of block.split('\n')) {
    if (!line || line.startsWith(':')) continue

    const colon = line.indexOf(':')
    const field = colon === -1 ? line : line.slice(0, colon)
    let value = colon === -1 ? '' : line.slice(colon + 1)
    if (value.startsWith(' ')) value = value.slice(1)

    if (field === 'event') eventName = value
    else if (field === 'data') dataLines.push(value)
  }

  if (dataLines.length === 0) return null

  try {
    return { event: eventName, data: JSON.parse(dataLines.join('\n')) }
  } catch {
    return null
  }
}

async function describeHttpError(response) {
  const text = await response.text().catch(() => '')
  if (text) {
    try {
      const payload = JSON.parse(text)
      const detail = payload?.detail ?? payload?.error?.message ?? payload?.message
      if (typeof detail === 'string' && detail) return detail
      if (detail) return JSON.stringify(detail)
    } catch {
      /* 非 JSON 错误体，忽略 */
    }
  }
  return text ? `HTTP ${response.status}：${text.slice(0, 200)}` : `HTTP ${response.status}`
}

/**
 * 发起一次对话并消费 SSE 事件流。
 *
 * @param {object} options
 * @param {string} options.threadId
 * @param {string} options.message
 * @param {AbortSignal} [options.signal]
 * @param {(event: string, data: object) => void} options.onEvent
 */
export async function streamChat({ threadId, message, signal, onEvent }) {
  const response = await fetch(`${resolveApiBase()}/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
    },
    body: JSON.stringify({ thread_id: threadId, message }),
    signal,
  })

  if (!response.ok) {
    throw new Error(`请求失败（${await describeHttpError(response)}）`)
  }
  if (!response.body) {
    throw new Error('当前浏览器不支持读取流式响应体。')
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder('utf-8')
  let buffer = ''

  const dispatch = (block) => {
    const parsed = parseEventBlock(block)
    if (parsed) onEvent(parsed.event, parsed.data)
  }

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      buffer = buffer.replace(/\r\n/g, '\n')

      let boundary = buffer.indexOf('\n\n')
      while (boundary !== -1) {
        const block = buffer.slice(0, boundary)
        buffer = buffer.slice(boundary + 2)
        if (block.trim()) dispatch(block)
        boundary = buffer.indexOf('\n\n')
      }
    }

    buffer += decoder.decode()
    buffer = buffer.replace(/\r\n/g, '\n')
    if (buffer.trim()) dispatch(buffer)
  } catch (error) {
    if (error?.name !== 'AbortError') {
      try {
        await reader.cancel()
      } catch {
        /* 连接已经断开 */
      }
    }
    throw error
  } finally {
    reader.releaseLock()
  }
}
