# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目状态

本目录尚无代码，唯一权威依据是 `设计文档.md`（完整需求 + 设计 + 代码片段 + 风险清单）。实现前先通读该文档；文档第 13 节给出了推荐的实现顺序。`.idea/` 是 IntelliJ 配置，可忽略。

项目根目录即本目录，按文档第 4 节创建 `backend_langgraph/`、`backend_agents/`、`frontend/`、`docker-compose.yml`（文档树中的 `emotion-support/` 只是示意）。

## 项目概述

双 Agent 情感支持系统：`sentiment` Agent 三分类（positive / negative / neutral）→ positive 走鼓励 Agent，negative/neutral 走排解 Agent → SSE 流式返回。同一业务逻辑用 LangGraph 与 OpenAI Agents SDK 各实现一个可独立启动的后端，前端只对接一套 SSE 协议，用于对比框架差异。

## 常用命令

依赖安装（各后端目录下）：`pip install -r requirements.txt`

启动后端（必须在各自目录下执行，且必须单 worker）：

```bash
cd backend_langgraph && uvicorn app.main:app --port 8001 --workers 1 --reload
cd backend_agents   && uvicorn app.main:app --port 8002 --workers 1 --reload
```

环境变量 `DEEPSEEK_API_KEY` 通过 `python-dotenv` 从 `.env` 读取。

前端（Vite）：`npm install` → `npm run dev`；在 `.env.development` 用 `VITE_API_BASE` 在 `http://localhost:8001`（LangGraph）与 `http://localhost:8002`（Agents）之间切换，UI 代码不变。

SSE 手动验证（每个后端先跑通再写前端）：

```bash
curl -N -X POST http://localhost:8001/chat \
  -H "Content-Type: application/json" \
  -d '{"thread_id":"t1","message":"今天被领导批评了，好难过"}'
```

Docker：`docker compose up --build`（前端 :3000，后端 :8001 / :8002）。

项目未规定测试框架；验证手段是 `curl -N` 检查 SSE 事件流。

## 核心架构约束

- **统一编排契约**：每个后端的 `orchestrator.py` 暴露 `chat_stream(req: ChatRequest) -> AsyncIterator[str]`，只产出 SSE 文本块；`main.py` 不感知内部是 LangGraph 还是 Agents SDK。两边还都需提供 `startup()` / `shutdown()`（lifespan 中调用）。
- **对称三件套逐字相同**：`main.py`、`sse.py`、`contracts.py` 在两个后端中必须完全一致（复制而非各写各的）。差异只允许出现在 `orchestrator.py` 与 `graph.py`（LangGraph 侧）/ `agents.py` + `conversation_store.py`（Agents 侧）。`diff` 两个 `orchestrator.py` 即为全部编排层差异——这是该项目的核心验收点。
- **SSE 协议**（前端唯一依赖，两边完全一致）：`sentiment` → 若干 `token` → `done`，任何失败发 `error`。data 字段：sentiment 为 `{label, confidence}`，token 为 `{delta}`，done 为 `{framework}`。
- **DeepSeek 接入**：OpenAI 兼容端点 `https://api.deepseek.com/v1`，`model="deepseek-chat"`。LangGraph 用 `ChatOpenAI(base_url=...)`；Agents SDK 必须显式构造 `OpenAIChatCompletionsModel` 并给**每个** Agent 传 `model=model`，否则会拿默认 GPT 模型名请求导致 400。
- **多轮会话**：LangGraph 用 `InMemorySaver` + `thread_id`（checkpointer）；Agents 侧自维护 `ConversationStore`（按 `thread_id` 的模块级字典）。两者都是进程内内存 → **强制 `--workers 1`**，多 worker 会话不共享；第一版不做外部持久化。
- **输入范围对齐**：sentiment 只用当前轮用户消息（`state["messages"][-1]` / `req.message`），不混历史，避免历史标签污染；回复 Agent 使用完整历史。
- **两阶段流式**：情感识别非流式（路由依赖其最终标签），回复阶段流式；前端先显示情感标签再逐字渲染回复。Agents 侧即 `Runner.run` + `Runner.run_streamed` 两阶段。
- **前端 SSE 解析**：`fetch` + `ReadableStream`，不用 `EventSource`（它只支持 GET、无法带 body）。按 `\n\n` 切分并保留残余 buffer（一个 chunk ≠ 一条 SSE 消息）；更新回复时只改最后一条消息对象的 `content` 字段，不要整体替换数组。

## 实现陷阱（设计文档 §6.2 / §12 明确要求）

- 异常必须在 SSE generator 内部捕获并转成 `event: error`：`StreamingResponse` 开始发送后 HTTP 状态码已定，`raise HTTPException` 不再生效。
- 流式循环中检查 `await request.is_disconnected()`，客户端断开时尽快停止向 DeepSeek 的付费请求。
- `async` 路径中禁止同步阻塞调用；必要时应 `await asyncio.to_thread(...)` 包一层。
- SSE 响应头必须带 `X-Accel-Buffering: no`；经 Nginx 反代时对 `/chat` 设 `proxy_buffering off`，否则打字机效果消失。
- `astream_events` 会发出所有节点的 token，必须用 `event["name"]` / 事件顺序区分：sentiment 节点的 `on_chat_model_stream` 不转发，只转发情感结果之后的事件。
- Agents SDK 的 `stream_events()` 事件字段路径随版本变化，须先写最小脚本打印事件对象确认，不能凭记忆硬编码。
- DeepSeek 结构化输出若不稳（`output_type` / `with_structured_output` 依赖 JSON mode / function calling），退化为"只输出一个单词、Python 解析"（§12.2）；`confidence` 波动大时可先置固定值或只输出 `label`。

## 实现顺序（文档 §13）

核心原则：**每个后端先非流式跑通，再加流式**；业务逻辑未验证时不要同时排查路由和 SSE 格式。

1. 两个后端的 `contracts.py`、`sse.py`（内容相同）
2. `backend_agents` 非流式（`Runner.run` + `SentimentResult` 结构化输出、双 Agent 路由）
3. `backend_agents` 流式（`run_streamed`，`curl -N` 验证）
4. `backend_langgraph` 非流式（checkpointer + `thread_id` 多轮）
5. `backend_langgraph` 流式（`astream_events` 过滤 token）
6. Vue 前端（先 `curl -N` 确认 SSE 格式，再写 `ReadableStream` 解析）
7. Docker 化（两个后端 Dockerfile + compose，验证容器内 SSE 不被缓冲）
