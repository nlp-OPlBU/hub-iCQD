"""LangGraph 后端的编排层。

对外只暴露 chat_stream(req) -> AsyncIterator[str]（产出 SSE 文本块），
main.py 不感知内部是 LangGraph。与 backend_agents/app/orchestrator.py
的差异就是本项目的核心对比点。
"""

from __future__ import annotations

import logging
import os
from typing import Any, AsyncIterator

from .contracts import ChatRequest, SentimentResult, coerce_sentiment
from .graph import graph
from .sse import sse_event

logger = logging.getLogger(__name__)


async def startup() -> None:
    if not os.getenv("DEEPSEEK_API_KEY"):
        logger.warning(
            "DEEPSEEK_API_KEY 未设置，/chat 将返回 error 事件；"
            "请在 backend_langgraph/.env 中配置（或使用 scripts/mock_deepseek.py 联调）。"
        )


async def shutdown() -> None:
    return None


def _content_to_text(chunk: Any) -> str:
    content = getattr(chunk, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content if isinstance(block, dict)
        )
    return ""


def _extract_sentiment(event: dict[str, Any]) -> SentimentResult | None:
    data = event.get("data") or {}
    output = data.get("output")
    if isinstance(output, SentimentResult):
        return output

    value: Any = None
    if isinstance(output, dict):
        value = output.get("sentiment")
        if value is None and "label" in output:
            value = output
    elif output is not None:
        value = getattr(output, "sentiment", None)

    if value is None:
        return None
    return coerce_sentiment(value)


async def chat_stream(req: ChatRequest) -> AsyncIterator[str]:
    config = {"configurable": {"thread_id": req.thread_id}}
    input_state = {"messages": [("user", req.message)]}

    sentiment_sent = False

    async for event in graph.astream_events(input_state, config=config, version="v2"):
        kind = event.get("event")
        metadata = event.get("metadata") or {}
        node = metadata.get("langgraph_node")

        if kind == "on_chain_end" and event.get("name") == "sentiment":
            if not sentiment_sent:
                sentiment = _extract_sentiment(event)
                if sentiment is not None:
                    yield sse_event("sentiment", sentiment.model_dump(mode="json"))
                    sentiment_sent = True

        elif kind == "on_chat_model_stream" and node in ("encourage", "soothe"):
            # astream_events 会发出所有节点的 token：
            # 用 langgraph_node 元数据过滤掉情感节点的 token，只转发回应 token。
            delta = _content_to_text(event["data"].get("chunk"))
            if delta:
                yield sse_event("token", {"delta": delta})

    yield sse_event("done", {"framework": "langgraph"})
