"""LangGraph 图定义：情感识别 → 条件路由 → 鼓励 / 排解。

图只在编排层使用；对外契约（contracts / sse / main）与 backend_agents 完全一致。
"""

from __future__ import annotations

import logging
import os
from typing import Annotated, Any, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

from .contracts import SentimentLabel, SentimentResult, coerce_sentiment

load_dotenv()

logger = logging.getLogger(__name__)

SENTIMENT_PROMPT = (
    "你是情感分析器。判断用户最新一条消息的整体情感倾向："
    "label 只能是 positive、negative 或 neutral，"
    "confidence 是 0 到 1 之间的置信度。"
    '请只输出 json 对象，形如 {"label": "negative", "confidence": 0.9}，不要解释。'
)

# DeepSeek 若不支持结构化输出（tool calling / JSON mode），退化为纯文本 JSON。
SENTIMENT_FALLBACK_PROMPT = (
    "你是情感分析器。判断用户消息的情感倾向，只输出一个 json 对象，"
    '格式为 {"label": "positive|negative|neutral", "confidence": 0.0}，'
    "confidence 取 0 到 1 之间的数。不要输出 json 以外的任何内容。"
)

ENCOURAGE_PROMPT = (
    "你是一位温暖、真诚的倾听者。用户刚刚表达了正面情绪。"
    "请用中文回应：先具体地肯定对方此刻的开心或成就感，再给出真诚的鼓励。"
    "语气自然，2 到 4 句话，不要使用列表、标题或说教。"
)

SOOTHE_PROMPT = (
    "你是一位温暖、有耐心的倾听者。用户刚刚表达了负面或中性情绪。"
    "请用中文回应：先准确共情、验证对方的感受，再温和地帮助对方梳理和排解。"
    "不要说教，2 到 4 句话，不要使用列表或标题。"
)


def _build_llm() -> ChatOpenAI:
    return ChatOpenAI(
        model=os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
        # 占位 key 让服务在未配置密钥时也能启动；真正的错误会以 SSE error 返回。
        api_key=os.getenv("DEEPSEEK_API_KEY") or "not-configured",
        base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1"),
        streaming=True,
        temperature=0.7,
        max_retries=2,
    )


llm = _build_llm()
# 显式使用 JSON mode：DeepSeek 对 OpenAI 的 json_schema 支持不稳定，
# 但支持 response_format={"type": "json_object"}（设计文档 §12.2）。
structured_llm = llm.with_structured_output(SentimentResult, method="json_mode")

# 进程级开关：一旦确认结构化输出不可用，后续请求直接走文本兜底，
# 避免每次都先发一次注定失败的请求（设计文档 §12.2）。
_structured_sentiment_ok = True


class EmotionState(TypedDict):
    messages: Annotated[list, add_messages]
    # 存 dict 而不是 Pydantic 对象：checkpoint 只序列化原生类型，
    # 避免 LangGraph 对自定义类的反序列化告警 / 未来版本限制。
    sentiment: dict[str, Any] | None
    reply: str


def _content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            block.get("text", "") for block in content if isinstance(block, dict)
        )
    return str(content or "")


async def _classify(text: str) -> SentimentResult:
    """只用当前轮用户消息做情感识别，不混入历史，避免历史标签污染。"""
    global _structured_sentiment_ok

    if _structured_sentiment_ok:
        try:
            result = await structured_llm.ainvoke(
                [SystemMessage(content=SENTIMENT_PROMPT), HumanMessage(content=text)]
            )
            return coerce_sentiment(result)
        except Exception as exc:
            logger.warning("结构化情感识别失败，后续退化为文本解析：%s", exc)
            _structured_sentiment_ok = False

    raw = await llm.ainvoke(
        [SystemMessage(content=SENTIMENT_FALLBACK_PROMPT), HumanMessage(content=text)]
    )
    return coerce_sentiment(raw.content)


async def sentiment_node(state: EmotionState) -> dict[str, Any]:
    last_user = state["messages"][-1]
    text = _content_to_text(getattr(last_user, "content", last_user))
    sentiment = await _classify(text)
    return {"sentiment": sentiment.model_dump(mode="json")}


async def _reply_node(state: EmotionState, system_prompt: str) -> dict[str, Any]:
    messages = [SystemMessage(content=system_prompt), *state["messages"]]
    response = await llm.ainvoke(messages)
    reply = _content_to_text(response.content)
    # 把助手回复也写回 messages，checkpointer 才能保存完整多轮历史。
    return {"reply": reply, "messages": [AIMessage(content=reply)]}


async def encourage_node(state: EmotionState) -> dict[str, Any]:
    return await _reply_node(state, ENCOURAGE_PROMPT)


async def soothe_node(state: EmotionState) -> dict[str, Any]:
    return await _reply_node(state, SOOTHE_PROMPT)


def route_by_sentiment(state: EmotionState) -> str:
    sentiment = state.get("sentiment") or {}
    if sentiment.get("label") == SentimentLabel.POSITIVE.value:
        return "encourage"
    return "soothe"


def build_graph():
    builder = StateGraph(EmotionState)
    builder.add_node("sentiment", sentiment_node)
    builder.add_node("encourage", encourage_node)
    builder.add_node("soothe", soothe_node)

    builder.add_edge(START, "sentiment")
    builder.add_conditional_edges(
        "sentiment",
        route_by_sentiment,
        {"encourage": "encourage", "soothe": "soothe"},
    )
    builder.add_edge("encourage", END)
    builder.add_edge("soothe", END)

    # 会话状态是进程内的：必须 --workers 1（设计文档 §6.3）。
    return builder.compile(checkpointer=InMemorySaver())


graph = build_graph()
