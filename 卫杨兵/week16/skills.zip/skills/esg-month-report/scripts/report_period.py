#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""计算 ESG 月报的报告期，并生成可直接用于检索的中英文关键词。

默认取"上一个完整自然月"；也支持滚动 30 天和指定自然月。

用法：
    python scripts/report_period.py
    python scripts/report_period.py --date 2026-11-26
    python scripts/report_period.py --month 2026-10
    python scripts/report_period.py --mode rolling30

输出：UTF-8 编码的 JSON，包含报告期、中文标签和检索词。
"""

from __future__ import annotations

import argparse
import calendar
import json
import sys
from datetime import date, datetime, timedelta


def _parse_date(value: str) -> date:
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"无效日期 {value!r}，格式应为 YYYY-MM-DD"
        ) from exc


def _previous_month(ref: date) -> tuple[date, date]:
    first_of_this_month = ref.replace(day=1)
    last_of_previous = first_of_this_month - timedelta(days=1)
    return last_of_previous.replace(day=1), last_of_previous


def _month_range(year: int, month: int) -> tuple[date, date]:
    last_day = calendar.monthrange(year, month)[1]
    return date(year, month, 1), date(year, month, last_day)


def _cn_month(year: int, month: int) -> str:
    return f"{year}年{month}月"


def _en_month(year: int, month: int) -> str:
    return f"{calendar.month_name[month]} {year}"


def _build_terms(start: date, end: date) -> tuple[list[str], list[str]]:
    same_month = start.year == end.year and start.month == end.month

    if same_month:
        cn = _cn_month(start.year, start.month)
        en = _en_month(start.year, start.month)
        quarter = (start.month - 1) // 3 + 1
        terms_cn = [
            cn,
            f"{cn} ESG",
            f"{cn} 可持续发展",
            f"{cn} 双碳",
            f"{cn} 绿色金融",
            f"{start.strftime('%Y-%m')}",
            f"{start.year}年第{quarter}季度 ESG",
        ]
        terms_en = [
            en,
            f"{en} ESG",
            f"{en} sustainability",
            f"{en} climate policy",
            f"{en} ESG regulation",
            f"{start.strftime('%Y-%m')}",
        ]
        return terms_cn, terms_en

    start_cn = _cn_month(start.year, start.month)
    end_cn = _cn_month(end.year, end.month)
    start_en = _en_month(start.year, start.month)
    end_en = _en_month(end.year, end.month)
    terms_cn = [
        start_cn,
        end_cn,
        f"{start_cn}至{end_cn} ESG",
        f"{start_cn} ESG",
        f"{end_cn} ESG",
        f"{start.strftime('%Y-%m-%d')} 至 {end.strftime('%Y-%m-%d')}",
    ]
    terms_en = [
        start_en,
        end_en,
        f"{start_en} ESG",
        f"{end_en} ESG",
        f"{start.strftime('%Y-%m-%d')} to {end.strftime('%Y-%m-%d')}",
    ]
    return terms_cn, terms_en


def main() -> None:
    parser = argparse.ArgumentParser(
        description="计算 ESG 月报报告期并生成检索关键词。"
    )
    parser.add_argument(
        "--date",
        type=_parse_date,
        default=date.today(),
        help="参考日期，格式 YYYY-MM-DD，默认今天。",
    )
    parser.add_argument(
        "--mode",
        choices=("calendar", "rolling30"),
        default="calendar",
        help="calendar=上一个完整自然月（默认）；rolling30=截止昨天的滚动30天。",
    )
    parser.add_argument(
        "--month",
        metavar="YYYY-MM",
        help="指定自然月，优先于 --mode，例如 2026-10。",
    )
    args = parser.parse_args()

    reference: date = args.date

    if args.month:
        parts = args.month.split("-")
        if len(parts) != 2:
            parser.error("--month 格式应为 YYYY-MM，例如 2026-10")
        try:
            year, month = int(parts[0]), int(parts[1])
        except ValueError:
            parser.error("--month 必须由数字组成，例如 2026-10")
        if not 1 <= month <= 12:
            parser.error("--month 的月份应在 01-12 之间")
        if year < 1900 or year > 2200:
            parser.error("--month 的年份应在 1900-2200 之间")
        start, end = _month_range(year, month)
        mode = "specified-month"
    elif args.mode == "rolling30":
        end = reference - timedelta(days=1)
        start = end - timedelta(days=29)
        mode = "rolling30"
    else:
        start, end = _previous_month(reference)
        mode = "previous-calendar-month"

    days = (end - start).days + 1
    terms_cn, terms_en = _build_terms(start, end)

    result = {
        "report_period": {
            "start": start.isoformat(),
            "end": end.isoformat(),
            "days": days,
        },
        "report_label_cn": (
            _cn_month(start.year, start.month)
            if start.year == end.year and start.month == end.month
            else f"{start.isoformat()} 至 {end.isoformat()}"
        ),
        "mode": mode,
        "reference_date": reference.isoformat(),
        "search_terms_cn": terms_cn,
        "search_terms_en": terms_en,
    }

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
