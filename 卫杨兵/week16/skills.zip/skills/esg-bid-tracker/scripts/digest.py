#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""根据本次新增记录生成 ESG 招标日报，可选推送到飞书/钉钉/企业微信。

用法：
  python scripts/digest.py --input added.json
  python scripts/digest.py --input added.json --webhook-type feishu --webhook-url https://...
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request
from datetime import date, timedelta
from pathlib import Path

from esg_common import (
    TYPE_INTENT,
    TYPE_TENDER,
    TYPE_WIN,
    data_dir,
    ensure_data_dirs,
    fmt_amount,
    load_config,
    load_records_file,
    load_state,
    load_store,
    now_iso,
    save_state,
    setup_stdout,
    today_str,
)

TYPE_SHORT = {TYPE_TENDER: "招标", TYPE_WIN: "中标", TYPE_INTENT: "采购意向"}


def md_escape(value) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ").strip()


def amount_label(record: dict) -> str:
    amount = record.get("amount")
    if amount is None:
        return "金额未披露"
    prefix = "预算" if record.get("type") == TYPE_TENDER else "金额"
    return f"{prefix} {fmt_amount(amount)}"


def record_line(record: dict, with_source: bool = True) -> str:
    parts = [f"**{md_escape(record.get('title'))}**"]
    parts.append(f"【{TYPE_SHORT.get(record.get('type'), record.get('type') or '其他')}】")
    if record.get("buyer"):
        parts.append(f"采购人：{md_escape(record['buyer'])}")
    parts.append(amount_label(record))
    if record.get("region"):
        parts.append(md_escape(record["region"]))
    if record.get("publish_date"):
        parts.append(record["publish_date"])
    if with_source:
        url = record.get("url") or ""
        source = md_escape(record.get("source") or "链接")
        if url.startswith(("http://", "https://")):
            parts.append(f"[{source}]({url})")
        elif record.get("source"):
            parts.append(source)
    return "- " + " ｜ ".join(parts)


def sorted_records(records: list[dict]) -> list[dict]:
    by_date = sorted(records, key=lambda r: r.get("publish_date") or "", reverse=True)
    return sorted(
        by_date,
        key=lambda r: (0 if r.get("amount") is not None else 1, -(r.get("amount") or 0)),
    )


def build_digest(records: list[dict], report_date: date, window_start: str, base: Path) -> str:
    counts = {key: 0 for key in (TYPE_TENDER, TYPE_WIN, TYPE_INTENT)}
    known_tender_budget = 0.0
    known_win_amount = 0.0
    for record in records:
        counts[record.get("type")] = counts.get(record.get("type"), 0) + 1
        if isinstance(record.get("amount"), (int, float)):
            if record.get("type") == TYPE_TENDER:
                known_tender_budget += record["amount"]
            elif record.get("type") == TYPE_WIN:
                known_win_amount += record["amount"]

    lines = [
        f"# ESG 招投标日报 · {report_date.isoformat()}",
        "",
        f"> 监控窗口：{window_start} 至 {report_date.isoformat()} ｜ 新增 {len(records)} 条"
        f"（招标 {counts.get(TYPE_TENDER, 0)} / 中标 {counts.get(TYPE_WIN, 0)}"
        + (f" / 采购意向 {counts.get(TYPE_INTENT)}" if counts.get(TYPE_INTENT) else "")
        + "）",
        "",
    ]

    if not records:
        lines.extend(
            [
                "## 今日结论",
                "",
                "在本次检索覆盖的公开渠道中，**未发现符合条件的新增 ESG 招标信息**。",
                "",
                "这不代表市场没有新公告：可能是检索源未覆盖、公告尚未上网，或关键词未命中。"
                "如果连续多日为空，建议扩大重点区域、增加采购人定向检索，或检查来源站点是否可访问。",
                "",
                "## 检索覆盖",
                "",
                f"- 数据目录：`{base}`",
                f"- 检索关键词：见 `assets/esg_keywords.json` 与当日检索计划",
                f"- 已入库记录总数：{len(load_store(base))} 条",
            ]
        )
        return "\n".join(lines) + "\n"

    ordered = sorted_records(records)
    amount_known = [r for r in ordered if r.get("amount") is not None]
    highlights = amount_known[:5] if amount_known else ordered[:5]

    lines.extend(["## 今日重点", ""])
    for index, record in enumerate(highlights, 1):
        lines.append(f"{index}. {record_line(record)[2:]}")
    lines.append("")

    groups: dict[str, list[dict]] = {}
    for record in ordered:
        groups.setdefault(record.get("category") or "其他", []).append(record)

    lines.append("## 按方向")
    lines.append("")
    for category, items in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        lines.append(f"### {md_escape(category)}（{len(items)}）")
        lines.append("")
        for record in items:
            lines.append(record_line(record))
        lines.append("")

    lines.extend(
        [
            "## 数据说明",
            "",
            f"- 新增记录已去重并写入 `{base / 'records.jsonl'}`。",
            f"- 已披露招标预算合计：{fmt_amount(known_tender_budget) if known_tender_budget else '—'}；"
            f"已披露中标金额合计：{fmt_amount(known_win_amount) if known_win_amount else '—'}。",
            "- 金额为公告披露值（万元），未披露金额以“金额未披露”标注，不参与合计。",
            "- 数据来自公开渠道，日报仅提供线索，投标前请核对原始公告。",
            "",
            f"> 由 esg-bid-tracker 生成于 {now_iso()}",
        ]
    )
    return "\n".join(lines) + "\n"


def build_push_text(records: list[dict], report_date: date) -> str:
    counts = {TYPE_TENDER: 0, TYPE_WIN: 0, TYPE_INTENT: 0}
    for record in records:
        counts[record.get("type")] = counts.get(record.get("type"), 0) + 1
    if not records:
        return f"【ESG招标日报】{report_date.isoformat()}\n今日在检索渠道中未发现新增 ESG 招标信息。"
    ordered = sorted_records(records)
    lines = [
        f"【ESG招标日报】{report_date.isoformat()}",
        f"新增 {len(records)} 条（招标 {counts.get(TYPE_TENDER, 0)} / 中标 {counts.get(TYPE_WIN, 0)}"
        + (f" / 采购意向 {counts.get(TYPE_INTENT)}" if counts.get(TYPE_INTENT) else "")
        + "）",
    ]
    for index, record in enumerate(ordered[:5], 1):
        amount = fmt_amount(record.get("amount")) if record.get("amount") is not None else "金额未披露"
        lines.append(f"{index}. {record.get('title')}（{TYPE_SHORT.get(record.get('type'), '其他')}，{amount}）")
        if record.get("url"):
            lines.append(f"   {record['url']}")
    if len(records) > 5:
        lines.append(f"……另有 {len(records) - 5} 条，详见本地日报。")
    return "\n".join(lines)[:3500]


def send_webhook(webhook_type: str, url: str, text: str) -> bool:
    webhook_type = (webhook_type or "feishu").lower()
    if webhook_type == "feishu":
        payload = {"msg_type": "text", "content": {"text": text}}
    elif webhook_type in ("dingtalk", "wecom", "weixin", "企业微信", "钉钉"):
        payload = {"msgtype": "text", "text": {"content": text}}
    else:
        print(f"未知推送类型: {webhook_type}（支持 feishu / dingtalk / wecom）", file=sys.stderr)
        return False

    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read().decode("utf-8", errors="replace")
        print(f"推送响应: {body[:300]}")
        try:
            data = json.loads(body)
            if data.get("errcode", 0) not in (0, None) or data.get("code", 0) not in (0, None):
                print("推送接口返回错误，请检查 webhook 配置", file=sys.stderr)
                return False
        except json.JSONDecodeError:
            pass
        return True
    except (urllib.error.URLError, TimeoutError) as exc:
        print(f"推送失败: {exc}", file=sys.stderr)
        return False


def main() -> int:
    setup_stdout()
    parser = argparse.ArgumentParser(description="生成 ESG 招标日报并可选推送")
    parser.add_argument("--input", required=True, help="本次新增记录 JSON（store.py add --added-out 的输出）")
    parser.add_argument("--data-dir", help="数据目录")
    parser.add_argument("--date", default=today_str(), help="日报日期 YYYY-MM-DD，默认今天")
    parser.add_argument("--outdir", help="日报目录，默认 <data-dir>/digests")
    parser.add_argument("--webhook-type", choices=["feishu", "dingtalk", "wecom"], help="推送渠道")
    parser.add_argument("--webhook-url", help="机器人 webhook 地址")
    parser.add_argument("--no-push", action="store_true", help="只生成日报，不推送")
    args = parser.parse_args()

    base = data_dir(args.data_dir)
    ensure_data_dirs(base)
    report_date = date.fromisoformat(args.date)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"找不到新增记录文件: {input_path}", file=sys.stderr)
        return 2
    loaded_records = load_records_file(input_path)
    records = []
    seen_ids: set[str] = set()
    for record in loaded_records:
        record_id = record.get("id") or ""
        if record_id and record_id in seen_ids:
            continue
        seen_ids.add(record_id)
        records.append(record)

    state = load_state(base)
    window_start = state.get("last_digest_date") or (report_date - timedelta(days=1)).isoformat()
    digest_md = build_digest(records, report_date, window_start, base)

    outdir = Path(args.outdir) if args.outdir else base / "digests"
    outdir.mkdir(parents=True, exist_ok=True)
    digest_path = outdir / f"{report_date.isoformat()}.md"
    digest_path.write_text(digest_md, encoding="utf-8")
    latest_path = outdir / "latest.md"
    latest_path.write_text(digest_md, encoding="utf-8")

    total = len(load_store(base))
    state.update(
        {
            "last_digest_date": report_date.isoformat(),
            "last_digest_count": len(records),
            "last_run_at": now_iso(),
            "total_records": total,
            "last_digest_path": str(digest_path),
        }
    )
    save_state(base, state)

    print(f"日报已生成: {digest_path}")
    print(f"最新日报副本: {latest_path}")
    if records:
        counts = {}
        for record in records:
            counts[record.get("type")] = counts.get(record.get("type"), 0) + 1
        breakdown = "、".join(f"{k} {v}" for k, v in counts.items())
        print(f"新增 {len(records)} 条（{breakdown}）；已入库记录共 {total} 条")
    else:
        print(f"本次无新增记录；已入库记录共 {total} 条")

    config = load_config(base)
    webhook_url = args.webhook_url or (config.get("push") or {}).get("webhook") or ""
    webhook_type = args.webhook_type or (config.get("push") or {}).get("type") or ""
    if not webhook_type and webhook_url:
        lowered = webhook_url.lower()
        if "dingtalk" in lowered:
            webhook_type = "dingtalk"
        elif "weixin" in lowered or "wecom" in lowered:
            webhook_type = "wecom"
        else:
            webhook_type = "feishu"
    if not args.no_push and webhook_url:
        push_text = build_push_text(records, report_date)
        if send_webhook(webhook_type or "feishu", webhook_url, push_text):
            print(f"已推送至 {webhook_type or 'feishu'}")
    elif not args.no_push:
        print("未配置推送 webhook，日报仅保存到本地（可用 --webhook-url 临时推送或在 config.json 中配置）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
