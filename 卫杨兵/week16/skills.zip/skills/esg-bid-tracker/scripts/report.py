#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 analysis.json 渲染成 Markdown 报告和自包含 HTML 报告。

用法：
  python scripts/report.py --analysis ~/esg-bid-data/reports/analysis.json
  python scripts/report.py --insights insights.md --outdir ./reports
"""
from __future__ import annotations

import argparse
import html
import json
import math
import re
from pathlib import Path

from esg_common import (
    data_dir,
    ensure_data_dirs,
    fmt_amount,
    load_taxonomy,
    pct,
    setup_stdout,
    truncate,
)

CONFIDENCE_LABELS = {"high": "高（详情页核实）", "medium": "中（权威来源摘要）", "low": "低（仅聚合站摘要）"}


class Raw(str):
    """标记为已转义/可信 HTML 的字符串。"""


def esc(value) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def fmt_share(fraction: float | None, digits: int = 1) -> str:
    if fraction is None:
        return "—"
    return f"{fraction * 100:.{digits}f}%"


def fmt_num(value, digits: int = 0) -> str:
    if value is None:
        return "—"
    if digits == 0:
        return f"{value:,.0f}"
    return f"{value:,.{digits}f}"


def group_amount(row: dict) -> str:
    """分组金额：没有一条披露金额时显示 —，而不是容易误读的 0 元。"""
    return fmt_amount(row.get("amount_sum")) if row.get("amount_count") else "—"


def group_share(row: dict) -> str:
    return fmt_share(row.get("amount_pct")) if row.get("amount_count") else "—"


def total_amount_text(summary: dict) -> str:
    return fmt_amount(summary.get("total_amount_wan")) if summary.get("amount_count") else "—"


def total_amount_label(types: list[str]) -> str:
    kinds = set(types)
    if kinds == {"中标"}:
        return "中标金额合计"
    if kinds == {"招标"}:
        return "招标预算合计"
    if "中标" in kinds and "招标" in kinds:
        return "披露金额合计（中标+预算）"
    return "披露金额合计"


def safe_url(url: str) -> str:
    url = str(url or "").strip()
    return url if url.startswith(("http://", "https://")) else ""


# ---------------------------------------------------------------------------
# 自动洞察
# ---------------------------------------------------------------------------


def auto_insights(data: dict) -> list[str]:
    summary = data["summary"]
    meta = data["meta"]
    bullets: list[str] = []

    count = summary["count"]
    if not count:
        return [
            "- 本期没有符合条件的样本记录。请检查检索范围、公告类型或日期区间；"
            "如果记录库为空，先执行采集流程。"
        ]

    bullets.append(
        f"- 本期共纳入 **{count}** 条{'、'.join(meta['types'])}记录，"
        f"其中 **{summary['amount_count']}** 条披露金额（覆盖率 {fmt_share(summary['amount_coverage_pct'])}），"
        f"披露金额合计 **{total_amount_text(summary)}**。"
    )

    if summary["median_wan"] is not None:
        mean = summary["mean_wan"] or 0
        median = summary["median_wan"] or 0
        if median and mean / median >= 1.3:
            shape = "均值明显高于中位数，说明金额受少数大额项目拉动，市场呈“头部大单 + 长尾小单”结构"
        else:
            shape = "均值与中位数接近，金额分布相对均衡"
        bullets.append(
            f"- 单项目金额中位数为 **{fmt_amount(median)}**、均值为 **{fmt_amount(mean)}**；{shape}。"
        )

    categories = data.get("by_category") or []
    if categories:
        top = categories[0]
        bullets.append(
            f"- 项目数最多的方向是 **{top['name']}**（{top['count']} 条，占 {fmt_share(top['count_pct'])}，"
            f"披露金额 {group_amount(top)}）。"
        )
        by_amount = max(categories, key=lambda c: c["amount_sum"])
        if by_amount["name"] != top["name"] and by_amount["amount_count"]:
            bullets.append(
                f"- 按金额看，**{by_amount['name']}** 规模最大"
                f"（{group_amount(by_amount)}，占披露金额 {group_share(by_amount)}）。"
            )

    buckets = {b["label"]: b for b in data.get("amount_buckets") or []}
    large_count = sum(buckets.get(k, {}).get("count", 0) for k in ("1000–3000 万", "≥3000 万"))
    large_amount = sum(buckets.get(k, {}).get("amount_sum", 0) for k in ("1000–3000 万", "≥3000 万"))
    if large_count and summary["amount_count"]:
        bullets.append(
            f"- 单笔 ≥1000 万元的项目有 **{large_count}** 个（占 {fmt_share(large_count / summary['amount_count'])}），"
            f"贡献了 {fmt_share(large_amount / summary['total_amount_wan'] if summary['total_amount_wan'] else None)} 的披露金额。"
        )

    regions = [r for r in data.get("by_region") or [] if r["name"] != "未标注"]
    if regions:
        top_region = regions[0]
        bullets.append(
            f"- 区域上，**{top_region['name']}** 项目数最多（{top_region['count']} 条，占 {fmt_share(top_region['count_pct'])}）。"
        )

    suppliers = data.get("top_suppliers") or []
    cr5 = ((data.get("concentration") or {}).get("suppliers") or {}).get("supplier_cr5_amount_pct")
    if suppliers and cr5 is not None:
        bullets.append(
            f"- 披露金额前 5 名供应商合计占 **{fmt_share(cr5)}**（CR5），"
            f"头部供应商为 **{suppliers[0]['name']}**（{suppliers[0]['count']} 个项目）。"
        )

    projects = data.get("top_projects") or []
    if projects:
        top_project = projects[0]
        bullets.append(
            f"- 样本中最大单笔为 **{top_project['title']}**"
            f"（{fmt_amount(top_project['amount'])}，采购人：{top_project['buyer'] or '未披露'}）。"
        )

    return bullets[:7]


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------


def md_cell(value) -> str:
    text = "" if value is None else str(value)
    return text.replace("|", "\\|").replace("\n", " ")


def md_table(headers: list[str], rows: list[list], numeric: set[int] | None = None) -> str:
    numeric = numeric or set()
    align = ["---:" if i in numeric else "---" for i in range(len(headers))]
    lines = ["| " + " | ".join(md_cell(h) for h in headers) + " |"]
    lines.append("| " + " | ".join(align) + " |")
    for row in rows:
        lines.append("| " + " | ".join(md_cell(c) for c in row) + " |")
    return "\n".join(lines)


def build_markdown(data: dict, title: str, insights: str | None) -> str:
    meta = data["meta"]
    summary = data["summary"]
    range_text = f"{meta['from']} 至 {meta['to']}"
    amount_total_name = total_amount_label(meta["types"])
    amount_section_title = "中标金额分布" if set(meta["types"]) == {"中标"} else "金额分布"
    lines: list[str] = [
        f"# {title}",
        "",
        f"> 数据区间：{range_text} ｜ 分析类型：{'、'.join(meta['types'])} ｜ "
        f"样本：{summary['count']} 条 ｜ 生成日期：{meta['generated_at']}",
        "",
        "## 一、核心结论",
        "",
        insights.strip() if insights and insights.strip() else "\n".join(auto_insights(data)),
        "",
        "## 二、数据概览",
        "",
        "| 指标 | 数值 |",
        "| --- | ---: |",
        f"| 数据区间 | {range_text} |",
        f"| 样本记录数 | {summary['count']} 条 |",
        f"| 披露金额记录 | {summary['amount_count']} 条（覆盖率 {fmt_share(summary['amount_coverage_pct'])}） |",
        f"| {amount_total_name} | {total_amount_text(summary)} |",
        f"| 单项目均值 / 中位数 | {fmt_amount(summary['mean_wan'])} / {fmt_amount(summary['median_wan'])} |",
        f"| 金额四分位（P25 / P75） | {fmt_amount(summary['p25_wan'])} / {fmt_amount(summary['p75_wan'])} |",
        f"| 单笔最小 / 最大 | {fmt_amount(summary['min_wan'])} / {fmt_amount(summary['max_wan'])} |",
        f"| 覆盖方向 | {len(data.get('by_category') or [])} 个 |",
        f"| 覆盖地区 | {len([r for r in (data.get('by_region') or []) if r['name'] != '未标注'])} 个 |",
        f"| 数据来源 | {len(meta.get('sources') or {})} 个 |",
        "",
        "> 金额按公告披露值统计（单位：万元），未披露金额的记录不计入金额指标。",
        "",
    ]

    categories = data.get("by_category") or []
    lines.append("## 三、热点招标方向")
    lines.append("")
    if categories:
        rows = [
            [
                i + 1,
                c["name"],
                c["count"],
                fmt_share(c["count_pct"]),
                group_amount(c),
                group_share(c),
                fmt_amount(c["avg_amount"]),
            ]
            for i, c in enumerate(categories)
        ]
        lines.append(md_table(
            ["排名", "方向", "项目数", "数量占比", "披露金额", "金额占比", "平均金额"],
            rows,
            numeric={0, 2, 3, 4, 5, 6},
        ))
        lines.append("")
        amount_top = max(categories, key=lambda c: c["amount_sum"])
        if amount_top["amount_count"]:
            lines.append(
                f"解读：{categories[0]['name']} 是项目数最多的方向；"
                f"金额维度上，{amount_top['name']} 的披露金额最高。"
            )
        else:
            lines.append(f"解读：{categories[0]['name']} 是项目数最多的方向；本期样本的金额披露不足。")
    else:
        lines.append("暂无数据。")
    lines.append("")

    lines.append(f"## 四、{amount_section_title}")
    lines.append("")
    buckets = data.get("amount_buckets") or []
    if summary["amount_count"]:
        rows = [
            [b["label"], b["count"], fmt_share(b["count_pct"]), fmt_amount(b["amount_sum"]), fmt_share(b["amount_pct"])]
            for b in buckets
        ]
        lines.append(md_table(["金额区间", "项目数", "数量占比", "金额合计", "金额占比"], rows, numeric={1, 2, 3, 4}))
        lines.append("")
        lines.append(
            f"金额集中度：单笔 ≥1000 万元的项目 {large_count(data)} 个，"
            f"占披露金额 {fmt_share(large_amount_share(data))}；"
            f"供应商 CR5 为 {fmt_share(supplier_cr5(data))}，CR10 为 {fmt_share(supplier_cr10(data))}。"
        )
        lines.append("")
        if summary["median_wan"]:
            ratio = (summary["mean_wan"] or 0) / summary["median_wan"]
            lines.append(f"均值/中位数 = {ratio:.1f}，"
                         + ("金额分布右偏，大额项目对总额影响显著。" if ratio >= 1.3 else "金额分布相对均衡。"))
            lines.append("")
    else:
        lines.append("样本中没有可用的金额数据，无法统计金额分布。")
        lines.append("")

    lines.append("## 五、时间趋势")
    lines.append("")
    quarters = data.get("by_quarter") or []
    if quarters:
        rows = [[q["name"], q["count"], group_amount(q), fmt_amount(q["avg_amount"])] for q in quarters]
        lines.append(md_table(["季度", "项目数", "披露金额", "平均金额"], rows, numeric={1, 2, 3}))
        lines.append("")
        years = data.get("by_year") or []
        if years:
            year_rows = [[y["name"], y["count"], group_amount(y)] for y in years]
            lines.append(md_table(["年度", "项目数", "披露金额"], year_rows, numeric={1, 2}))
            lines.append("")
        lines.append("> 首尾年份可能是不完整年度，跨年比较时需注意样本窗口。")
    else:
        lines.append("暂无可按日期归档的数据。")
    lines.append("")

    lines.append("## 六、区域分布")
    lines.append("")
    regions = data.get("by_region") or []
    if regions:
        rows = [
            [r["name"], r["count"], fmt_share(r["count_pct"]), group_amount(r), group_share(r)]
            for r in regions
        ]
        lines.append(md_table(["地区", "项目数", "数量占比", "披露金额", "金额占比"], rows, numeric={1, 2, 3, 4}))
    else:
        lines.append("暂无地区信息。")
    lines.append("")

    lines.append("## 七、采购方与供应商格局")
    lines.append("")
    buyers = data.get("top_buyers") or []
    suppliers = data.get("top_suppliers") or []
    lines.append("### 采购方 TOP")
    lines.append("")
    if buyers:
        rows = [[i + 1, b["name"], b["count"], group_amount(b)] for i, b in enumerate(buyers)]
        lines.append(md_table(["排名", "采购方", "中标项目数", "披露金额"], rows, numeric={0, 2, 3}))
    else:
        lines.append("暂无采购方信息。")
    lines.append("")
    lines.append("### 中标供应商 TOP")
    lines.append("")
    if suppliers:
        rows = [[i + 1, s["name"], s["count"], group_amount(s)] for i, s in enumerate(suppliers)]
        lines.append(md_table(["排名", "供应商", "中标项目数", "披露金额"], rows, numeric={0, 2, 3}))
        lines.append("")
        lines.append(
            f"供应商集中度：CR5 = {fmt_share(supplier_cr5(data))}，CR10 = {fmt_share(supplier_cr10(data))}。"
        )
    else:
        lines.append("暂无供应商信息（部分中标公告不披露中标人）。")
    lines.append("")

    lines.append("## 八、重点项目 TOP10")
    lines.append("")
    projects = data.get("top_projects") or []
    if projects:
        rows = []
        for i, p in enumerate(projects):
            title_text = truncate(p["title"], 38)
            if safe_url(p["url"]):
                title_text = f"[{title_text}]({p['url']})"
            rows.append([
                i + 1, title_text, p["buyer"] or "—", p["supplier"] or "—",
                fmt_amount(p["amount"]), p["publish_date"] or "—", p["category"] or "—", p["region"] or "—",
            ])
        lines.append(md_table(
            ["排名", "项目", "采购人", "中标供应商", "金额", "发布日期", "方向", "地区"],
            rows,
            numeric={0, 4},
        ))
    else:
        lines.append("暂无金额明确的项目。")
    lines.append("")

    keywords = data.get("keywords") or []
    lines.append("## 九、关键词热度")
    lines.append("")
    if keywords:
        rows = [[i + 1, k["name"], k["count"]] for i, k in enumerate(keywords[:15])]
        lines.append(md_table(["排名", "关键词", "出现次数"], rows, numeric={0, 2}))
    else:
        lines.append("暂无关键词统计。")
    lines.append("")

    lines.append("## 十、数据来源与口径")
    lines.append("")
    sources = meta.get("sources") or {}
    if sources:
        rows = [[name, count] for name, count in sources.items()]
        lines.append(md_table(["来源", "记录数"], rows, numeric={1}))
        lines.append("")
    confidence = meta.get("confidence") or {}
    if confidence:
        rows = [[CONFIDENCE_LABELS.get(k, k), v] for k, v in confidence.items()]
        lines.append(md_table(["数据置信度", "记录数"], rows, numeric={1}))
        lines.append("")
    lines.extend(
        [
            "**统计口径与局限：**",
            "",
            "- 本报告基于公开渠道检索结果，样本并非全量，适合判断方向、量级与结构，不宜作为市场规模的绝对值。",
            "- 金额为公告披露值（万元）；未披露金额的记录不参与金额统计，区间金额按中值处理。",
            "- 同一项目可能被多个平台转载，已按“公告类型 + 标题 + 采购人 + 发布日期”去重。",
            "- “中标/成交”与“招标/采购意向”分开统计；本报告默认仅分析中标类记录。",
            "- 检索范围聚焦 ESG/双碳相关的咨询、报告、核查、规划、碳资产与认证服务；工程建设与设备采购默认不纳入。",
            "",
            f"> 报告由 esg-bid-tracker 生成于 {meta['generated_at']}。",
            "",
        ]
    )
    return "\n".join(lines)


def large_count(data: dict) -> int:
    return sum(b["count"] for b in data.get("amount_buckets") or [] if b["label"] in ("1000–3000 万", "≥3000 万"))


def large_amount_share(data: dict) -> float | None:
    total = data["summary"]["total_amount_wan"]
    if not total:
        return None
    amount = sum(b["amount_sum"] for b in data.get("amount_buckets") or [] if b["label"] in ("1000–3000 万", "≥3000 万"))
    return amount / total


def supplier_cr5(data: dict) -> float | None:
    return ((data.get("concentration") or {}).get("suppliers") or {}).get("supplier_cr5_amount_pct")


def supplier_cr10(data: dict) -> float | None:
    return ((data.get("concentration") or {}).get("suppliers") or {}).get("supplier_cr10_amount_pct")


# ---------------------------------------------------------------------------
# HTML 组件
# ---------------------------------------------------------------------------


def build_table(headers: list[str], rows: list[list], numeric: set[int] | None = None) -> str:
    numeric = numeric or set()
    head = "".join(
        f'<th class="{"num" if i in numeric else ""}">{esc(h)}</th>' for i, h in enumerate(headers)
    )
    body = []
    for row in rows:
        cells = []
        for i, value in enumerate(row):
            cls = ' class="num"' if i in numeric else ""
            content = str(value) if isinstance(value, Raw) else esc(value)
            cells.append(f"<td{cls}>{content}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return (
        '<div class="table-wrap"><table><thead><tr>'
        + head
        + "</tr></thead><tbody>"
        + "".join(body)
        + "</tbody></table></div>"
    )


def nice_step(raw: float) -> float:
    if raw <= 0:
        return 1
    exponent = math.floor(math.log10(raw))
    for multiple in (1, 2, 5, 10):
        step = multiple * (10 ** exponent)
        if step >= raw:
            return step
    return 10 ** (exponent + 1)


def axis_scale(max_value: float) -> tuple[float, float]:
    if max_value <= 0:
        return 1, 1
    step = max(1.0, nice_step(max_value / 4))
    top = math.ceil(max_value / step) * step
    return step, top


def fmt_tick(value: float) -> str:
    if value >= 10000:
        return f"{value / 10000:g}万"
    if value >= 1000:
        return f"{value:,.0f}"
    if float(value).is_integer():
        return f"{value:.0f}"
    return f"{value:g}"


def rounded_right(x: float, y: float, width: float, height: float, radius: float = 4) -> str:
    r = min(radius, max(0, width / 2), height / 2)
    return (
        f"M {x:.1f} {y:.1f} H {x + width - r:.1f} "
        f"Q {x + width:.1f} {y:.1f} {x + width:.1f} {y + r:.1f} "
        f"V {y + height - r:.1f} Q {x + width:.1f} {y + height:.1f} {x + width - r:.1f} {y + height:.1f} "
        f"H {x:.1f} Z"
    )


def rounded_top(x: float, y: float, width: float, height: float, radius: float = 4) -> str:
    r = min(radius, max(0, width / 2), height / 2)
    return (
        f"M {x:.1f} {y + height:.1f} V {y + r:.1f} "
        f"Q {x:.1f} {y:.1f} {x + r:.1f} {y:.1f} "
        f"H {x + width - r:.1f} Q {x + width:.1f} {y:.1f} {x + width:.1f} {y + r:.1f} "
        f"V {y + height:.1f} Z"
    )


def empty_chart() -> str:
    return '<div class="empty">暂无数据</div>'


def chart_h(items: list[dict], aria: str) -> str:
    """水平条形图。items: [{label, value, tip}]。"""
    if not items:
        return empty_chart()
    width, label_w, value_w = 860, 215, 100
    top, bottom, bar_h, gap = 14, 30, 18, 16
    n = len(items)
    plot_h = n * (bar_h + gap) - gap
    height = top + plot_h + bottom
    plot_w = width - label_w - value_w
    max_value = max(item["value"] for item in items) or 1
    step, top_value = axis_scale(max_value)
    tick_count = int(round(top_value / step))
    parts = [
        f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{esc(aria)}">'
    ]
    for i in range(tick_count + 1):
        tick = step * i
        x = label_w + (tick / top_value) * plot_w
        parts.append(
            f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + plot_h}" class="gridline"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{height - 9}" text-anchor="middle" class="tick">{fmt_tick(tick)}</text>'
        )
    for index, item in enumerate(items):
        y = top + index * (bar_h + gap)
        bar_width = max(2.0, item["value"] / top_value * plot_w)
        label = truncate(str(item["label"]), 14)
        parts.append(
            f'<g class="bar-group" tabindex="0" data-tip="{esc(item["tip"])}">'
            f"<title>{esc(item['tip'])}</title>"
            f'<text x="{label_w - 10}" y="{y + 13.5:.1f}" text-anchor="end" class="catlabel">{esc(label)}</text>'
            f'<path d="{rounded_right(label_w, y, bar_width, bar_h)}" class="bar"/>'
            f'<text x="{label_w + bar_width + 8:.1f}" y="{y + 13.5:.1f}" class="vlabel">{fmt_tick(item["value"])}</text>'
            "</g>"
        )
    parts.append(
        f'<line x1="{label_w}" y1="{top}" x2="{label_w}" y2="{top + plot_h}" class="axisline"/>'
    )
    parts.append("</svg>")
    return "".join(parts)


def chart_v(items: list[dict], aria: str, height: int = 330) -> str:
    """垂直柱状图，适合有序分箱与时间序列。items: [{label, value, tip}]。"""
    if not items:
        return empty_chart()
    width, left, right, top, bottom = 860, 54, 18, 26, 48
    plot_w = width - left - right
    plot_h = height - top - bottom
    n = len(items)
    slot = plot_w / n
    bar_w = min(58.0, slot * 0.58)
    max_value = max(item["value"] for item in items) or 1
    step, top_value = axis_scale(max_value)
    tick_count = int(round(top_value / step))
    parts = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{esc(aria)}">']
    for i in range(tick_count + 1):
        tick = step * i
        y = top + plot_h - (tick / top_value) * plot_h
        parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{left + plot_w}" y2="{y:.1f}" class="gridline"/>')
        parts.append(
            f'<text x="{left - 8}" y="{y + 4:.1f}" text-anchor="end" class="tick">{fmt_tick(tick)}</text>'
        )
    for index, item in enumerate(items):
        x = left + index * slot + (slot - bar_w) / 2
        bar_h = item["value"] / top_value * plot_h
        y = top + plot_h - bar_h
        label = truncate(str(item["label"]), 10)
        bar_path = (
            f'<path d="{rounded_top(x, y, bar_w, bar_h)}" class="bar"/>'
            if bar_h > 0.5
            else ""
        )
        parts.append(
            f'<g class="bar-group" tabindex="0" data-tip="{esc(item["tip"])}">'
            f"<title>{esc(item['tip'])}</title>"
            f"{bar_path}"
            f'<text x="{x + bar_w / 2:.1f}" y="{y - 6:.1f}" text-anchor="middle" class="vlabel">{fmt_tick(item["value"])}</text>'
            f'<text x="{x + bar_w / 2:.1f}" y="{height - 20}" text-anchor="middle" class="tick">{esc(label)}</text>'
            "</g>"
        )
    parts.append(f'<line x1="{left}" y1="{top + plot_h}" x2="{left + plot_w}" y2="{top + plot_h}" class="axisline"/>')
    parts.append("</svg>")
    return "".join(parts)


def md_inline(text: str) -> str:
    text = esc(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(
        r"\[([^\]]+)\]\((https?://[^)\s]+)\)",
        r'<a href="\2" target="_blank" rel="noopener">\1</a>',
        text,
    )
    return text


def md_to_html(markdown_text: str) -> str:
    lines = (markdown_text or "").splitlines()
    output: list[str] = []
    list_type: str | None = None
    paragraph: list[str] = []

    def flush_paragraph() -> None:
        if paragraph:
            output.append("<p>" + md_inline(" ".join(paragraph)) + "</p>")
            paragraph.clear()

    def close_list() -> None:
        nonlocal list_type
        if list_type:
            output.append(f"</{list_type}>")
            list_type = None

    def open_list(kind: str) -> None:
        nonlocal list_type
        if list_type != kind:
            close_list()
            output.append(f"<{kind}>")
            list_type = kind

    for raw_line in lines:
        line = raw_line.rstrip()
        if not line.strip():
            flush_paragraph()
            close_list()
            continue
        if re.match(r"^#{1,4}\s+", line):
            flush_paragraph()
            close_list()
            level = len(line) - len(line.lstrip("#"))
            content = line[level:].strip()
            tag = "h3" if level <= 2 else "h4"
            output.append(f"<{tag}>{md_inline(content)}</{tag}>")
            continue
        match = re.match(r"^[-*]\s+(.*)$", line)
        if match:
            flush_paragraph()
            open_list("ul")
            output.append(f"<li>{md_inline(match.group(1))}</li>")
            continue
        match = re.match(r"^\d+[.、]\s+(.*)$", line)
        if match:
            flush_paragraph()
            open_list("ol")
            output.append(f"<li>{md_inline(match.group(1))}</li>")
            continue
        close_list()
        paragraph.append(line.strip())
    flush_paragraph()
    close_list()
    return "".join(output)


CSS = """
:root {
  color-scheme: light;
  --page: #f9f9f9;
  --surface: #ffffff;
  --text: #191919;
  --text-2: #666666;
  --grid: #e7e7e7;
  --axis: #c2c2c2;
  --series-1: #257de0;
  --border: rgba(11, 11, 11, 0.10);
  --soft: #eef5fe;
  --font: system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", sans-serif;
}
@media (prefers-color-scheme: dark) {
  :root {
    color-scheme: dark;
    --page: #0b0b0b;
    --surface: #191919;
    --text: #efefef;
    --text-2: #9c9c9c;
    --grid: #303030;
    --axis: #474747;
    --series-1: #338ced;
    --border: rgba(255, 255, 255, 0.10);
    --soft: #13263c;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--page);
  color: var(--text);
  font-family: var(--font);
  line-height: 1.65;
  -webkit-font-smoothing: antialiased;
}
.page { max-width: 1080px; margin: 0 auto; padding: 36px 20px 56px; }
.hero { padding: 4px 4px 22px; }
.eyebrow { font-size: 12px; letter-spacing: .14em; color: var(--text-2); text-transform: uppercase; }
h1 { font-size: 30px; line-height: 1.25; margin: 8px 0 10px; font-weight: 700; letter-spacing: -.01em; }
.meta { font-size: 13px; color: var(--text-2); }
.stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 18px; }
.stat { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 16px 18px; }
.stat-label { font-size: 12px; color: var(--text-2); }
.stat-value { font-size: 25px; font-weight: 650; margin-top: 6px; letter-spacing: -.01em; line-height: 1.25; }
.stat-value small { font-size: 13px; font-weight: 500; color: var(--text-2); margin-left: 4px; }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 24px 24px 18px; margin-bottom: 16px; }
.card h2 { font-size: 18px; margin: 0 0 4px; letter-spacing: -.005em; }
.card .sub { font-size: 12.5px; color: var(--text-2); margin: 0 0 14px; }
.card h3 { font-size: 14px; margin: 18px 0 4px; }
.insights ul { margin: 6px 0 2px; padding-left: 18px; }
.insights li { margin: 8px 0; }
.insights p { margin: 8px 0; }
.chart { width: 100%; overflow-x: auto; }
.chart svg { display: block; width: 100%; height: auto; min-width: 620px; }
svg text { font-family: var(--font); }
.gridline { stroke: var(--grid); stroke-width: 1; }
.axisline { stroke: var(--axis); stroke-width: 1; }
.tick { fill: var(--text-2); font-size: 11px; font-variant-numeric: tabular-nums; }
.catlabel { fill: var(--text-2); font-size: 12px; }
.vlabel { fill: var(--text); font-size: 11.5px; font-variant-numeric: tabular-nums; }
.bar { fill: var(--series-1); }
.bar-group { outline: none; }
.bar-group:hover .bar, .bar-group:focus .bar { opacity: .8; }
.bar-group:focus .catlabel { fill: var(--text); }
details { margin-top: 14px; border-top: 1px solid var(--grid); padding-top: 10px; }
summary { cursor: pointer; font-size: 13px; color: var(--text-2); user-select: none; }
summary:hover { color: var(--text); }
.table-wrap { overflow-x: auto; margin-top: 12px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { padding: 8px 10px; border-bottom: 1px solid var(--grid); text-align: left; vertical-align: top; }
th { font-size: 12px; color: var(--text-2); font-weight: 600; white-space: nowrap; }
td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
tbody tr:hover { background: var(--soft); }
tbody tr:last-child td { border-bottom: none; }
a { color: var(--series-1); text-decoration: none; }
a:hover { text-decoration: underline; }
.empty { padding: 28px; text-align: center; color: var(--text-2); border: 1px dashed var(--grid); border-radius: 10px; }
.tooltip {
  position: fixed; z-index: 99; max-width: 320px; pointer-events: none;
  background: var(--surface); color: var(--text); border: 1px solid var(--border);
  border-radius: 8px; box-shadow: 0 8px 24px rgba(0, 0, 0, .18);
  padding: 8px 10px; font-size: 12px; line-height: 1.5;
}
.tooltip[hidden] { display: none; }
footer { font-size: 12px; color: var(--text-2); padding: 6px 4px 0; }
.note { font-size: 12.5px; color: var(--text-2); }
ul.plain { margin: 6px 0; padding-left: 18px; }
@media (max-width: 760px) {
  .stats { grid-template-columns: repeat(2, 1fr); }
  .page { padding: 24px 14px 40px; }
  h1 { font-size: 24px; }
  .card { padding: 18px 16px 14px; }
}
@media print {
  body { background: #fff; }
  .page { max-width: none; padding: 0; }
  .card { break-inside: avoid; box-shadow: none; }
  details { display: none; }
  .chart svg { min-width: 0; }
}
"""

JS = """
(function () {
  var tip = document.getElementById('chart-tip');
  if (!tip) return;
  function show(el, x, y) {
    var text = el.getAttribute('data-tip');
    if (!text) return;
    tip.textContent = text;
    tip.hidden = false;
    var pad = 14;
    var left = x + pad, top = y + pad;
    var rect = tip.getBoundingClientRect();
    if (left + rect.width > window.innerWidth - 8) left = x - rect.width - pad;
    if (top + rect.height > window.innerHeight - 8) top = y - rect.height - pad;
    tip.style.left = Math.max(8, left) + 'px';
    tip.style.top = Math.max(8, top) + 'px';
  }
  document.querySelectorAll('[data-tip]').forEach(function (el) {
    el.addEventListener('mousemove', function (e) { show(el, e.clientX, e.clientY); });
    el.addEventListener('mouseleave', function () { tip.hidden = true; });
    el.addEventListener('focus', function () {
      var rect = el.getBoundingClientRect();
      show(el, rect.right, rect.top);
    });
    el.addEventListener('blur', function () { tip.hidden = true; });
  });
})();
"""


def stat_tile(label: str, value: str, unit: str = "") -> str:
    suffix = f"<small>{esc(unit)}</small>" if unit else ""
    return (
        f'<div class="stat"><div class="stat-label">{esc(label)}</div>'
        f'<div class="stat-value">{esc(value)}{suffix}</div></div>'
    )


def chart_card(title: str, subtitle: str, chart_svg: str, table_html: str) -> str:
    return (
        f'<section class="card"><h2>{esc(title)}</h2><p class="sub">{esc(subtitle)}</p>'
        f'<div class="chart">{chart_svg}</div>'
        f'<details><summary>查看数据表</summary>{table_html}</details></section>'
    )


def table_card(title: str, subtitle: str, table_html: str) -> str:
    return (
        f'<section class="card"><h2>{esc(title)}</h2><p class="sub">{esc(subtitle)}</p>'
        f"{table_html}</section>"
    )


def build_html(data: dict, title: str, insights: str | None) -> str:
    meta = data["meta"]
    summary = data["summary"]
    categories = data.get("by_category") or []
    regions = data.get("by_region") or []
    buckets = data.get("amount_buckets") or []
    quarters = data.get("by_quarter") or []
    projects = data.get("top_projects") or []
    buyers = data.get("top_buyers") or []
    suppliers = data.get("top_suppliers") or []
    keywords = data.get("keywords") or []

    insights_text = insights.strip() if insights and insights.strip() else "\n".join(auto_insights(data))
    insights_html = md_to_html(insights_text)
    amount_section_title = "中标金额分布" if set(meta["types"]) == {"中标"} else "金额分布"

    used_regions = [r for r in regions if r["name"] != "未标注"]
    stats_html = "".join(
        [
            stat_tile("样本记录", fmt_num(summary["count"]), "条"),
            stat_tile("披露金额合计", total_amount_text(summary)),
            stat_tile("单项目金额中位数", fmt_amount(summary["median_wan"])),
            stat_tile("覆盖方向", fmt_num(len(categories)), "个"),
        ]
    )

    # 图表 1：方向
    cat_items = [
        {
            "label": c["name"],
            "value": c["count"],
            "tip": f"{c['name']}：{c['count']} 条 · 金额 {group_amount(c)} · 数量占比 {fmt_share(c['count_pct'])}",
        }
        for c in categories
    ]
    cat_table = build_table(
        ["排名", "方向", "项目数", "数量占比", "披露金额", "金额占比", "平均金额"],
        [
            [i + 1, c["name"], c["count"], fmt_share(c["count_pct"]), group_amount(c),
             group_share(c), fmt_amount(c["avg_amount"])]
            for i, c in enumerate(categories)
        ],
        numeric={0, 2, 3, 4, 5, 6},
    )

    # 图表 2：金额分布
    amount_available = summary["amount_count"] > 0
    bucket_items = [
        {
            "label": b["label"],
            "value": b["count"],
            "tip": f"{b['label']}：{b['count']} 个项目 · 金额 {fmt_amount(b['amount_sum'])} · 数量占比 {fmt_share(b['count_pct'])}",
        }
        for b in buckets
    ] if amount_available else []
    bucket_table = build_table(
        ["金额区间", "项目数", "数量占比", "金额合计", "金额占比"],
        [[b["label"], b["count"], fmt_share(b["count_pct"]), fmt_amount(b["amount_sum"]), fmt_share(b["amount_pct"])] for b in buckets],
        numeric={1, 2, 3, 4},
    ) if amount_available else '<div class="empty">样本中没有可用的金额数据</div>'

    # 图表 3：季度趋势
    quarter_items = [
        {
            "label": q["name"],
            "value": q["count"],
            "tip": f"{q['name']}：{q['count']} 条 · 金额 {group_amount(q)}",
        }
        for q in quarters
    ]
    quarter_table = build_table(
        ["季度", "项目数", "披露金额", "平均金额"],
        [[q["name"], q["count"], group_amount(q), fmt_amount(q["avg_amount"])] for q in quarters],
        numeric={1, 2, 3},
    )

    # 图表 4：区域
    region_items = [
        {
            "label": r["name"],
            "value": r["count"],
            "tip": f"{r['name']}：{r['count']} 条 · 金额 {group_amount(r)} · 数量占比 {fmt_share(r['count_pct'])}",
        }
        for r in sorted(used_regions, key=lambda x: x["count"], reverse=True)[:10]
    ]
    region_table = build_table(
        ["地区", "项目数", "数量占比", "披露金额", "金额占比"],
        [[r["name"], r["count"], fmt_share(r["count_pct"]), group_amount(r), group_share(r)] for r in regions],
        numeric={1, 2, 3, 4},
    )

    # 表格：采购方 / 供应商
    buyer_table = build_table(
        ["排名", "采购方", "中标项目数", "披露金额", "平均金额"],
        [[i + 1, b["name"], b["count"], group_amount(b), fmt_amount(b["avg_amount"])] for i, b in enumerate(buyers)],
        numeric={0, 2, 3, 4},
    ) if buyers else '<div class="empty">暂无采购方信息</div>'
    supplier_table = build_table(
        ["排名", "供应商", "中标项目数", "披露金额", "平均金额"],
        [[i + 1, s["name"], s["count"], group_amount(s), fmt_amount(s["avg_amount"])] for i, s in enumerate(suppliers)],
        numeric={0, 2, 3, 4},
    ) if suppliers else '<div class="empty">暂无供应商信息（部分中标公告不披露中标人）</div>'

    # 重点项目
    project_rows = []
    for i, p in enumerate(projects):
        title_text = truncate(p["title"], 46)
        url = safe_url(p["url"])
        cell = Raw(f'<a href="{esc(url)}" target="_blank" rel="noopener">{esc(title_text)}</a>') if url else title_text
        project_rows.append([
            i + 1, cell, p["buyer"] or "—", p["supplier"] or "—",
            fmt_amount(p["amount"]), p["publish_date"] or "—", p["category"] or "—", p["region"] or "—",
        ])
    project_table = build_table(
        ["排名", "项目", "采购人", "中标供应商", "金额", "发布日期", "方向", "地区"],
        project_rows,
        numeric={0, 4},
    ) if project_rows else '<div class="empty">暂无金额明确的项目</div>'

    # 关键词
    keyword_table = build_table(
        ["排名", "关键词", "出现次数"],
        [[i + 1, k["name"], k["count"]] for i, k in enumerate(keywords[:15])],
        numeric={0, 2},
    ) if keywords else '<div class="empty">暂无关键词统计</div>'

    # 来源 / 置信度
    sources = meta.get("sources") or {}
    source_table = build_table(
        ["来源", "记录数"], [[name, count] for name, count in sources.items()], numeric={1}
    ) if sources else '<div class="empty">暂无来源信息</div>'
    confidence = meta.get("confidence") or {}
    confidence_table = build_table(
        ["数据置信度", "记录数"],
        [[CONFIDENCE_LABELS.get(k, k), v] for k, v in confidence.items()],
        numeric={1},
    ) if confidence else ""

    overview_rows = [
        ["数据区间", f"{meta['from']} 至 {meta['to']}"],
        ["分析公告类型", "、".join(meta["types"])],
        ["样本记录数", f"{summary['count']} 条"],
        ["披露金额记录", f"{summary['amount_count']} 条（覆盖率 {fmt_share(summary['amount_coverage_pct'])}）"],
        [total_amount_label(meta["types"]), total_amount_text(summary)],
        ["单项目均值 / 中位数", f"{fmt_amount(summary['mean_wan'])} / {fmt_amount(summary['median_wan'])}"],
        ["金额四分位（P25 / P75）", f"{fmt_amount(summary['p25_wan'])} / {fmt_amount(summary['p75_wan'])}"],
        ["单笔最小 / 最大", f"{fmt_amount(summary['min_wan'])} / {fmt_amount(summary['max_wan'])}"],
        ["覆盖方向 / 地区", f"{len(categories)} 个 / {len(used_regions)} 个"],
        ["数据来源", f"{len(sources)} 个"],
    ]
    overview_table = build_table(["指标", "数值"], overview_rows)

    concentration_note = (
        f"单笔 ≥1000 万元的项目 {large_count(data)} 个，占披露金额 {fmt_share(large_amount_share(data))}；"
        f"供应商 CR5 = {fmt_share(supplier_cr5(data))}，CR10 = {fmt_share(supplier_cr10(data))}。"
    )
    bucket_subtitle = (
        f"按披露金额分箱 · 单位：个 · {concentration_note}"
        if amount_available
        else "样本中没有可用的金额数据"
    )

    theme_note = "金额按公告披露值统计（单位：万元），未披露金额的记录不计入金额指标。"

    body = f"""
<header class="hero">
  <div class="eyebrow">ESG BID INTELLIGENCE</div>
  <h1>{esc(title)}</h1>
  <div class="meta">数据区间 {esc(meta['from'])} — {esc(meta['to'])} · 样本 {summary['count']} 条 · 生成于 {esc(meta['generated_at'])}</div>
</header>
<div class="stats">{stats_html}</div>
<section class="card"><h2>核心结论</h2><div class="insights">{insights_html}</div></section>
{table_card("数据概览", theme_note, overview_table)}
{chart_card("热点招标方向", "按中标项目数排序 · 单位：个", chart_h(cat_items, "各方向中标项目数"), cat_table)}
{chart_card(amount_section_title, bucket_subtitle, chart_v(bucket_items, "中标金额区间分布"), bucket_table)}
{chart_card("时间趋势", "按季度统计中标项目数 · 单位：个", chart_v(quarter_items, "各季度中标项目数"), quarter_table)}
{chart_card("区域分布", "按项目数展示前 10 个地区 · 单位：个", chart_h(region_items, "各地区中标项目数"), region_table)}
{table_card("采购方格局", "按中标项目数排序", buyer_table)}
{table_card("供应商格局", "按中标项目数排序；CR 指标按金额计算", supplier_table)}
{table_card("重点项目 TOP10", "按披露金额排序", project_table)}
{table_card("关键词热度", "统计中标公告标题与摘要中的 ESG 关键词", keyword_table)}
{table_card("数据来源与置信度", "来源分布与记录可信度", source_table + (confidence_table if confidence_table else ""))}
<section class="card">
  <h2>统计口径与局限</h2>
  <ul class="plain">
    <li>本报告基于公开渠道检索结果，样本并非全量，适合判断方向、量级与结构，不宜作为市场规模的绝对值。</li>
    <li>金额为公告披露值（万元）；未披露金额的记录不参与金额统计，区间金额按中值处理。</li>
    <li>同一项目可能被多个平台转载，已按“公告类型 + 标题 + 采购人 + 发布日期”去重。</li>
    <li>“中标/成交”与“招标/采购意向”分开统计；本报告默认仅分析中标类记录。</li>
    <li>检索范围聚焦 ESG/双碳相关的咨询、报告、核查、规划、碳资产与认证服务；工程建设与设备采购默认不纳入。</li>
  </ul>
</section>
<footer>报告由 esg-bid-tracker 生成于 {esc(meta['generated_at'])} · 数据来自公开渠道，仅供投标决策参考</footer>
"""

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<style>{CSS}</style>
</head>
<body>
<div class="page">
{body}
</div>
<div id="chart-tip" class="tooltip" hidden></div>
<script>{JS}</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_report(data: dict, title: str, insights: str | None, outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    md_path = outdir / "esg-bid-report.md"
    html_path = outdir / "esg-bid-report.html"
    md_path.write_text(build_markdown(data, title, insights), encoding="utf-8")
    html_path.write_text(build_html(data, title, insights), encoding="utf-8")
    return md_path, html_path


def main() -> int:
    setup_stdout()
    parser = argparse.ArgumentParser(description="生成 ESG 招投标分析报告")
    parser.add_argument("--analysis", help="analysis.json 路径，默认 <data-dir>/reports/analysis.json")
    parser.add_argument("--data-dir", help="数据目录")
    parser.add_argument("--insights", help="核心结论 Markdown 文件（可选）")
    parser.add_argument("--outdir", help="报告输出目录，默认 <data-dir>/reports")
    parser.add_argument("--title", default=None)
    args = parser.parse_args()

    base = data_dir(args.data_dir)
    ensure_data_dirs(base)
    analysis_path = Path(args.analysis) if args.analysis else base / "reports" / "analysis.json"
    if not analysis_path.exists():
        print(f"找不到分析文件: {analysis_path}（先运行 analyze.py）")
        return 2

    data = json.loads(analysis_path.read_text(encoding="utf-8"))
    insights = Path(args.insights).read_text(encoding="utf-8") if args.insights else None
    title = args.title or f"ESG 招投标市场分析报告（{data['meta']['from']} — {data['meta']['to']}）"
    outdir = Path(args.outdir) if args.outdir else base / "reports"
    md_path, html_path = build_report(data, title, insights, outdir)
    print(f"Markdown 报告: {md_path}")
    print(f"HTML 报告: {html_path}")
    print(f"说明: 在浏览器打开 HTML 可查看图表；Markdown 适合粘贴到文档或汇报材料。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
