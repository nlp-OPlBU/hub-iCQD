#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""esg-bid-tracker 公共工具：数据模型、解析、分类、去重存储。

所有金额统一为「万元」，日期统一为 YYYY-MM-DD。
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = SKILL_DIR / "assets"
TAXONOMY_PATH = ASSETS_DIR / "esg_keywords.json"
DEFAULT_DATA_DIR = Path(
    os.environ.get("ESG_BID_DATA_DIR", str(Path.home() / "esg-bid-data"))
)

TYPE_WIN = "中标"
TYPE_TENDER = "招标"
TYPE_INTENT = "采购意向"
TYPE_OTHER = "其他"

TYPE_ORDER = [TYPE_TENDER, TYPE_WIN, TYPE_INTENT, TYPE_OTHER]

CONFIDENCE_MAP = {
    "high": "high", "medium": "medium", "low": "low",
    "高": "high", "中": "medium", "低": "low",
    "已核实": "high", "待核实": "low",
}

# ---------------------------------------------------------------------------
# 通用
# ---------------------------------------------------------------------------


def setup_stdout() -> None:
    """Windows 控制台默认 GBK，统一改成 UTF-8，避免中文输出报错。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def today_str() -> str:
    return date.today().isoformat()


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def two_years_ago(d: date | None = None) -> date:
    d = d or date.today()
    try:
        return d.replace(year=d.year - 2)
    except ValueError:  # 2月29日
        return d.replace(year=d.year - 2, month=2, day=28)


def load_taxonomy() -> dict:
    with open(TAXONOMY_PATH, encoding="utf-8") as f:
        return json.load(f)


def data_dir(path: str | os.PathLike | None = None) -> Path:
    return Path(path).expanduser() if path else DEFAULT_DATA_DIR


def ensure_data_dirs(base: Path) -> None:
    for sub in ("", "digests", "reports", "exports"):
        (base / sub).mkdir(parents=True, exist_ok=True)
    config_path = base / "config.json"
    if not config_path.exists():
        config_path.write_text(
            json.dumps(default_config(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def default_config() -> dict:
    return {
        "regions": [],
        "categories": [],
        "min_amount_wan": 0,
        "push": {"type": "", "webhook": ""},
        "daily_time": "09:00",
        "search": {"target_records_collect": 80, "max_queries_collect": 48},
    }


def load_config(base: Path) -> dict:
    path = base / "config.json"
    cfg = default_config()
    if path.exists():
        try:
            user_cfg = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return cfg
        _deep_update(cfg, user_cfg)
    return cfg


def save_config(base: Path, cfg: dict) -> None:
    base.mkdir(parents=True, exist_ok=True)
    (base / "config.json").write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _deep_update(dst: dict, src: dict) -> None:
    for key, value in src.items():
        if isinstance(value, dict) and isinstance(dst.get(key), dict):
            _deep_update(dst[key], value)
        else:
            dst[key] = value


def load_state(base: Path) -> dict:
    path = base / "state.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
    return {}


def save_state(base: Path, state: dict) -> None:
    base.mkdir(parents=True, exist_ok=True)
    (base / "state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# 类型 / 金额 / 日期解析
# ---------------------------------------------------------------------------


def normalize_type(value: str | None) -> str:
    s = str(value or "").strip()
    if not s:
        return TYPE_OTHER
    if any(k in s for k in ("中标", "成交", "中选", "结果公告")):
        return TYPE_WIN
    if "意向" in s:
        return TYPE_INTENT
    if any(k in s for k in ("更正", "变更", "废标", "流标", "终止", "失败")):
        return TYPE_OTHER
    if any(
        k in s
        for k in ("招标", "采购公告", "询价", "竞争性磋商", "竞争性谈判", "磋商", "谈判", "单一来源", "比选")
    ):
        return TYPE_TENDER
    return TYPE_OTHER


_NUM_RE = re.compile(r"(\d+(?:\.\d+)?)")
_RANGE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:-|~|—|–|至|到)\s*(\d+(?:\.\d+)?)")
_EMPTY_AMOUNTS = {"", "-", "—", "/", "无", "暂无", "未披露", "未知", "n/a", "na", "none"}


def parse_amount_wan(raw) -> tuple[float | None, str]:
    """把各种金额写法换算成万元。

    支持：123.45（按万元）、"1,234.56万元"、"1.2亿元"、"980000元"、
    "500-600万元"（取中值）。无法识别时返回 (None, 原文)。
    """
    if raw is None:
        return None, ""
    if isinstance(raw, bool):
        return None, str(raw)
    if isinstance(raw, (int, float)):
        value = float(raw)
        return (round(value, 4) if value >= 0 else None), str(raw)

    original = str(raw).strip()
    s = original.replace(",", "").replace("，", "").replace(" ", "").replace("　", "")
    if s.lower() in _EMPTY_AMOUNTS:
        return None, original

    unit = None
    if "亿" in s:
        unit = 10000.0
    elif "万" in s:
        unit = 1.0
    elif "元" in s:
        unit = 0.0001

    range_match = _RANGE_RE.search(s)
    if range_match:
        value = (float(range_match.group(1)) + float(range_match.group(2))) / 2.0
    else:
        match = _NUM_RE.search(s)
        if not match:
            return None, original
        value = float(match.group(1))

    if unit is None:
        unit = 1.0  # 未写单位时按数据模型约定视为万元
    if value < 0:
        return None, original
    return round(value * unit, 4), original


_DATE_CLEAN_RE = re.compile(r"[年月/\.]")


def parse_date(raw) -> str | None:
    """把常见日期写法归一为 YYYY-MM-DD；只有年月时取当月1日。"""
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw.date().isoformat()
    if isinstance(raw, date):
        return raw.isoformat()

    s = str(raw).strip()
    if not s or s.lower() in {"-", "—", "/", "无", "暂无", "未知", "none", "n/a"}:
        return None
    # 去掉时间与时区部分
    s = re.split(r"[ T]", s, maxsplit=1)[0]
    s = _DATE_CLEAN_RE.sub("-", s)
    s = s.replace("日", "").strip("- ")
    parts = [p for p in re.split(r"-+", s) if p]
    if len(parts) >= 3:
        try:
            return date(int(parts[0]), int(parts[1]), int(parts[2])).isoformat()
        except ValueError:
            pass
    if len(parts) == 2:
        try:
            return date(int(parts[0]), int(parts[1]), 1).isoformat()
        except ValueError:
            pass
    if len(parts) == 1 and len(parts[0]) == 8 and parts[0].isdigit():
        try:
            return date(int(parts[0][:4]), int(parts[0][4:6]), int(parts[0][6:])).isoformat()
        except ValueError:
            pass
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(str(raw).strip(), fmt).date().isoformat()
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# 分类与记录标准化
# ---------------------------------------------------------------------------


def _norm_text(value) -> str:
    return re.sub(r"[\s\W_]+", "", str(value or "").lower(), flags=re.UNICODE)


def classify(title: str, summary: str = "", taxonomy: dict | None = None) -> tuple[str, str, list[str]]:
    """返回 (类别名, 类别id, 命中关键词列表)。

    判定规则：命中关键词数量多者优先；数量相同则最长关键词更长者优先；
    仍相同按类别顺序。这样“碳中和认证”不会输给宽泛的“碳中和”。
    """
    taxonomy = taxonomy or load_taxonomy()
    text = f"{title or ''} {summary or ''}"
    best = None
    best_score = None
    for idx, cat in enumerate(taxonomy.get("categories", [])):
        matched = [kw for kw in cat.get("keywords", []) if kw and kw in text]
        if not matched:
            continue
        max_len = max(len(kw) for kw in matched)
        score = (len(matched), max_len, -idx)
        if best_score is None or score > best_score:
            best = (cat["name"], cat["id"], matched)
            best_score = score
    if best is None:
        return "其他", "other", []
    # “产品碳足迹”命中时不再重复计入“碳足迹”，避免关键词热度虚高
    unique = sorted(set(best[2]), key=lambda k: (-len(k), k))
    filtered = [kw for kw in unique if not any(kw != other and kw in other for other in unique)]
    return best[0], best[1], filtered


FIELD_ALIASES = {
    "title": ["title", "标题", "项目名称", "公告标题", "项目", "标讯标题", "项目名"],
    "type": ["type", "类型", "公告类型", "信息类型", "招采类型"],
    "buyer": ["buyer", "采购人", "招标人", "采购单位", "建设单位", "业主单位", "采购方"],
    "supplier": ["supplier", "中标供应商", "中标人", "成交供应商", "供应商", "中标单位", "成交人"],
    "amount": [
        "amount", "金额", "中标金额", "中标金额（万元）", "中标金额(万元)", "金额（万元）",
        "预算金额", "中标价", "成交金额", "项目金额", "合同金额",
    ],
    "amount_raw": ["amount_raw", "金额原文", "金额说明"],
    "publish_date": ["publish_date", "发布日期", "发布时间", "公告日期", "日期", "公告时间"],
    "region": ["region", "地区", "省份", "区域", "省市", "所在地"],
    "source": ["source", "来源", "网站", "来源网站", "平台"],
    "url": ["url", "链接", "网址", "详情链接", "公告链接"],
    "category": ["category", "类别", "分类", "方向"],
    "summary": ["summary", "摘要", "备注", "内容摘要"],
    "keywords": ["keywords", "关键词", "命中关键词"],
    "confidence": ["confidence", "置信度", "可信度"],
    "id": ["id", "记录id", "编号"],
}


def _norm_header(value) -> str:
    return re.sub(r"\s+", "", str(value or "")).lower()


_FIELD_LOOKUP = {}
for _field, _aliases in FIELD_ALIASES.items():
    for _alias in _aliases:
        _FIELD_LOOKUP[_norm_header(_alias)] = _field


def normalize_record(raw: dict, taxonomy: dict | None = None) -> dict:
    """把任意来源（API 结果 / CSV / 手写 JSON）的记录标准化。"""
    if not isinstance(raw, dict):
        raise ValueError("记录必须是 JSON 对象")

    data: dict = {}
    for key, value in raw.items():
        field = _FIELD_LOOKUP.get(_norm_header(key), str(key).strip())
        if value not in (None, ""):
            data[field] = value

    title = str(data.get("title") or "").strip()
    if not title:
        raise ValueError("缺少项目标题（title / 项目名称）")

    type_raw = str(data.get("type") or "").strip()
    record_type = normalize_type(type_raw)

    amount_raw_input = data.get("amount_raw")
    amount_input = data.get("amount")
    if amount_input is None and amount_raw_input is not None:
        amount_input = amount_raw_input
    amount, amount_raw = parse_amount_wan(amount_input)
    if amount_raw_input:
        amount_raw = str(amount_raw_input)

    publish_date = parse_date(data.get("publish_date"))

    category_name = str(data.get("category") or "").strip()
    matched_keywords: list[str] = []
    category_id = "other"
    if not category_name or category_name in {"其他", "未分类"}:
        category_name, category_id, matched_keywords = classify(
            title, str(data.get("summary") or ""), taxonomy
        )
    else:
        taxonomy = taxonomy or load_taxonomy()
        for cat in taxonomy.get("categories", []):
            if category_name in (cat.get("name"), cat.get("id")):
                category_id = cat["id"]
                category_name = cat["name"]
                break

    provided_keywords = data.get("keywords") or []
    if isinstance(provided_keywords, str):
        provided_keywords = [k.strip() for k in re.split(r"[,，、;；]", provided_keywords) if k.strip()]
    keywords = sorted(set(list(matched_keywords) + list(provided_keywords)), key=lambda k: (-len(k), k))

    confidence = CONFIDENCE_MAP.get(str(data.get("confidence") or "").strip().lower(), "medium")

    record = {
        "id": str(data.get("id") or "").strip(),
        "title": title,
        "type": record_type,
        "type_raw": type_raw or record_type,
        "category": category_name or "其他",
        "category_id": category_id,
        "buyer": str(data.get("buyer") or "").strip(),
        "supplier": str(data.get("supplier") or "").strip(),
        "amount": amount,
        "amount_raw": amount_raw,
        "publish_date": publish_date or "",
        "region": str(data.get("region") or "").strip(),
        "source": str(data.get("source") or "").strip(),
        "url": str(data.get("url") or "").strip(),
        "summary": str(data.get("summary") or "").strip(),
        "keywords": keywords,
        "confidence": confidence,
        "collected_at": now_iso(),
    }
    if not record["id"]:
        record["id"] = make_id(record)
    return record


def make_id(record: dict) -> str:
    key = "|".join(
        [
            str(record.get("type") or ""),
            _norm_text(record.get("title")),
            _norm_text(record.get("buyer")),
            str(record.get("publish_date") or ""),
        ]
    )
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]


def record_fingerprints(record: dict) -> set[str]:
    fps = {"key:" + make_id(record)}
    url = str(record.get("url") or "").strip().rstrip("/").lower()
    if url:
        fps.add("url:" + url)
    return fps


# ---------------------------------------------------------------------------
# 读写
# ---------------------------------------------------------------------------


def load_records_file(path: str | os.PathLike) -> list[dict]:
    """读取 .jsonl / .json / .csv 记录文件，返回标准化后的记录。"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"找不到记录文件: {p}")

    rows: list[dict] = []
    suffix = p.suffix.lower()
    if suffix == ".csv":
        with open(p, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
    elif suffix == ".jsonl":
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    else:
        payload = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            payload = payload.get("records") or payload.get("data") or []
        if not isinstance(payload, list):
            raise ValueError("JSON 文件应为记录数组，或包含 records 字段的对象")
        rows = payload

    taxonomy = load_taxonomy()
    records = []
    for row in rows:
        records.append(normalize_record(row, taxonomy))
    return records


def store_path(base: Path) -> Path:
    return base / "records.jsonl"


def load_store(base: Path) -> list[dict]:
    path = store_path(base)
    if not path.exists():
        return []
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records


def append_store(base: Path, new_records: list[dict]) -> tuple[list[dict], int, list[str]]:
    """追加记录并跨来源去重。返回 (新增记录, 重复数, 错误列表)。"""
    ensure_data_dirs(base)
    existing = load_store(base)
    fingerprints: set[str] = set()
    for rec in existing:
        fingerprints |= record_fingerprints(rec)

    added: list[dict] = []
    duplicates = 0
    errors: list[str] = []
    for item in new_records:
        try:
            rec = item if item.get("id") and item.get("category_id") else normalize_record(item)
        except (ValueError, TypeError) as exc:
            errors.append(str(exc))
            continue
        fps = record_fingerprints(rec)
        if fps & fingerprints:
            duplicates += 1
            continue
        fingerprints |= fps
        added.append(rec)

    if added:
        all_records = existing + added
        _atomic_write_jsonl(store_path(base), all_records)
    return added, duplicates, errors


def _atomic_write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=".records-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for rec in records:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------------------
# 格式化
# ---------------------------------------------------------------------------


def fmt_amount(wan: float | None, dash: str = "—") -> str:
    if wan is None:
        return dash
    if wan >= 10000:
        return f"{wan / 10000:,.2f} 亿元"
    if wan >= 10:
        return f"{wan:,.0f} 万元"
    if wan >= 1:
        return f"{wan:,.1f} 万元"
    return f"{wan * 10000:,.0f} 元"


def fmt_count(value: int | None) -> str:
    return dash_count(value)


def dash_count(value) -> str:
    return "—" if value is None else f"{value:,}"


def pct(part: float, total: float, digits: int = 1) -> str:
    if not total:
        return "—"
    return f"{part / total * 100:.{digits}f}%"


def truncate(text: str, max_len: int, suffix: str = "…") -> str:
    text = str(text or "")
    return text if len(text) <= max_len else text[: max_len - len(suffix)] + suffix


def in_range(record: dict, start: str | None, end: str | None) -> bool:
    d = record.get("publish_date") or ""
    if not d:
        return False
    if start and d < start:
        return False
    if end and d > end:
        return False
    return True
