#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ESG 招投标记录库：初始化、入库去重、查询、导出、配置。

用法：
  python scripts/store.py init
  python scripts/store.py add --input records.json
  python scripts/store.py list --type 中标 --limit 20
  python scripts/store.py export --format csv
  python scripts/store.py stats
  python scripts/store.py config --show
  python scripts/store.py config --set push.type=feishu --set push.webhook=https://...
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

from esg_common import (
    TYPE_ORDER,
    append_store,
    data_dir,
    ensure_data_dirs,
    fmt_amount,
    load_config,
    load_records_file,
    load_store,
    normalize_record,
    save_config,
    setup_stdout,
    today_str,
)

EXPORT_FIELDS = [
    "id", "title", "type", "category", "buyer", "supplier", "amount", "amount_raw",
    "publish_date", "region", "source", "url", "summary", "keywords", "confidence",
    "collected_at",
]


def cmd_init(args) -> int:
    base = data_dir(args.data_dir)
    ensure_data_dirs(base)
    print(f"数据目录已就绪: {base}")
    print(f"  records.jsonl  全部记录")
    print(f"  config.json    监控与推送配置")
    print(f"  digests/       每日日报")
    print(f"  reports/       分析报告与图表")
    print(f"  exports/       导出文件")
    return 0


def cmd_add(args) -> int:
    base = data_dir(args.data_dir)
    ensure_data_dirs(base)
    try:
        records = load_records_file(args.input)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"读取失败: {exc}", file=sys.stderr)
        return 2

    added, duplicates, errors = append_store(base, records)
    total = len(load_store(base))

    if args.added_out:
        # 即使没有新增也写空数组，避免日报误读上一次的“新增记录”
        out = Path(args.added_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(added, ensure_ascii=False, indent=2), encoding="utf-8")

    if args.json:
        print(json.dumps(
            {"added": len(added), "duplicates": duplicates, "errors": errors, "total": total},
            ensure_ascii=False,
        ))
    else:
        print(f"新增 {len(added)} 条，重复跳过 {duplicates} 条，错误 {len(errors)} 条（库内共 {total} 条）")
        if errors:
            for err in errors[:5]:
                print(f"  ! {err}")
        if args.added_out and added:
            print(f"本次新增记录: {args.added_out}")
    return 0


def cmd_list(args) -> int:
    base = data_dir(args.data_dir)
    records = load_store(base)
    if args.type:
        records = [r for r in records if r.get("type") == args.type]
    if args.category:
        records = [r for r in records if args.category in (r.get("category") or "")]
    if args.from_date:
        records = [r for r in records if (r.get("publish_date") or "") >= args.from_date]
    if args.to_date:
        records = [r for r in records if (r.get("publish_date") or "") <= args.to_date]
    records.sort(key=lambda r: (r.get("publish_date") or "", r.get("amount") or 0), reverse=True)
    shown = records[: args.limit]

    print(f"共 {len(records)} 条，显示前 {len(shown)} 条")
    for rec in shown:
        print(
            f"{rec.get('publish_date') or '—'} | {rec.get('type'):<4} | "
            f"{(rec.get('category') or '')[:10]:<10} | {rec.get('title')} | "
            f"采购人: {rec.get('buyer') or '—'} | {fmt_amount(rec.get('amount'))}"
        )
    return 0


def cmd_export(args) -> int:
    base = data_dir(args.data_dir)
    records = load_store(base)
    if not records:
        print("库为空，暂无记录可导出", file=sys.stderr)
        return 1
    fmt = args.format
    out = Path(args.out) if args.out else base / "exports" / f"esg-bid-records-{today_str()}.{fmt}"
    out.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "csv":
        with open(out, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=EXPORT_FIELDS, extrasaction="ignore")
            writer.writeheader()
            for rec in records:
                row = dict(rec)
                row["keywords"] = "；".join(rec.get("keywords") or [])
                writer.writerow(row)
    else:
        with open(out, "w", encoding="utf-8") as f:
            for rec in records:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"已导出 {len(records)} 条记录: {out}")
    return 0


def cmd_stats(args) -> int:
    base = data_dir(args.data_dir)
    records = load_store(base)
    print(f"记录总数: {len(records)}")
    if not records:
        return 0

    for label, key in (("按类型", "type"), ("按类别", "category"), ("按年份", None)):
        print(f"\n{label}:")
        if key:
            counter = Counter(r.get(key) or "未分类" for r in records)
        else:
            counter = Counter((r.get("publish_date") or "")[:4] or "未知" for r in records)
        for name, count in counter.most_common():
            print(f"  {name}: {count}")

    wins = [r for r in records if r.get("type") == "中标"]
    amounts = [r["amount"] for r in wins if isinstance(r.get("amount"), (int, float))]
    print(f"\n中标记录: {len(wins)} 条；披露金额: {len(amounts)} 条")
    if amounts:
        print(f"中标金额合计: {fmt_amount(sum(amounts))}")
    sources = Counter(r.get("source") or "未标注" for r in records)
    print("\n按来源:")
    for name, count in sources.most_common():
        print(f"  {name}: {count}")
    return 0


def cmd_config(args) -> int:
    base = data_dir(args.data_dir)
    cfg = load_config(base)
    if args.set:
        for item in args.set:
            if "=" not in item:
                print(f"格式应为 key=value: {item}", file=sys.stderr)
                return 2
            key, value = item.split("=", 1)
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                parsed = value
            node = cfg
            parts = key.split(".")
            for part in parts[:-1]:
                node = node.setdefault(part, {})
            node[parts[-1]] = parsed
        save_config(base, cfg)
        print("配置已更新")
    print(json.dumps(cfg, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--data-dir", help="数据目录，默认 ~/esg-bid-data 或环境变量 ESG_BID_DATA_DIR")

    parser = argparse.ArgumentParser(description="ESG 招投标记录库")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", parents=[common], help="初始化数据目录与配置")
    p_init.set_defaults(func=cmd_init)

    p_add = sub.add_parser("add", parents=[common], help="导入并去重入库（json/jsonl/csv）")
    p_add.add_argument("--input", required=True, help="记录文件路径")
    p_add.add_argument("--added-out", help="把本次新增记录另存为 JSON（供日报使用）")
    p_add.add_argument("--json", action="store_true", help="输出 JSON 摘要")
    p_add.set_defaults(func=cmd_add)

    p_list = sub.add_parser("list", parents=[common], help="查看记录")
    p_list.add_argument("--type", choices=TYPE_ORDER)
    p_list.add_argument("--category", help="类别名称包含的关键字")
    p_list.add_argument("--from", dest="from_date", help="起始发布日期 YYYY-MM-DD")
    p_list.add_argument("--to", dest="to_date", help="截止发布日期 YYYY-MM-DD")
    p_list.add_argument("--limit", type=int, default=50)
    p_list.set_defaults(func=cmd_list)

    p_export = sub.add_parser("export", parents=[common], help="导出 CSV/JSONL")
    p_export.add_argument("--format", choices=["csv", "jsonl"], default="csv")
    p_export.add_argument("--out", help="输出路径")
    p_export.set_defaults(func=cmd_export)

    p_stats = sub.add_parser("stats", parents=[common], help="库内统计概览")
    p_stats.set_defaults(func=cmd_stats)

    p_cfg = sub.add_parser("config", parents=[common], help="查看或修改配置")
    p_cfg.add_argument("--show", action="store_true", help="显示配置（默认行为）")
    p_cfg.add_argument("--set", action="append", metavar="KEY=VALUE", help="设置配置项，可重复")
    p_cfg.set_defaults(func=cmd_config)

    return parser


def main() -> int:
    setup_stdout()
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
