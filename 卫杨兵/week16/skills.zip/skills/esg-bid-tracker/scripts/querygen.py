#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 ESG 招投标检索计划（供 WebSearch 逐条执行）。

用法：
  python scripts/querygen.py --mode collect --months 24
  python scripts/querygen.py --mode daily --days 1
  python scripts/querygen.py --mode collect --regions 广东,江苏 --format json
"""
from __future__ import annotations

import argparse
import calendar
import json
from datetime import date, timedelta

from esg_common import data_dir, load_config, load_taxonomy, setup_stdout, today_str


def months_ago(d: date, months: int) -> date:
    total = d.year * 12 + (d.month - 1) - months
    year, month0 = divmod(total, 12)
    month = month0 + 1
    day = min(d.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def build_collect_plan(end: date, months: int, regions: list[str], max_queries: int) -> list[dict]:
    start = months_ago(end, months)
    years = list(range(end.year, start.year - 1, -1))
    taxonomy = load_taxonomy()
    groups = taxonomy.get("query_groups", [])

    items: list[dict] = []
    for year_rank, year in enumerate(years):
        priority = f"P{min(year_rank + 1, 3)}"
        for group in groups:
            for keyword in group.get("keywords", []):
                items.append(
                    {
                        "query": f"{keyword} 中标 {year}",
                        "priority": priority,
                        "group": group["name"],
                        "period": str(year),
                        "kind": "category",
                    }
                )
    if regions:
        for year_rank, year in enumerate(years):
            priority = f"P{min(year_rank + 1, 3)}"
            for group in groups:
                keyword = (group.get("keywords") or [""])[0]
                for region in regions:
                    items.append(
                        {
                            "query": f"{keyword} 中标 {region} {year}",
                            "priority": priority,
                            "group": group["name"],
                            "period": str(year),
                            "kind": "region",
                        }
                    )
    order = {"P1": 0, "P2": 1, "P3": 2}
    items.sort(key=lambda x: (order.get(x["priority"], 3), x["period"], x["group"], x["query"]), reverse=False)
    return items[:max_queries], start


def month_labels_between(start: date, end: date) -> list[str]:
    """列出窗口覆盖的所有月份，月初运行时也要查上个月的最后一天。"""
    labels = []
    year, month = start.year, start.month
    while (year, month) <= (end.year, end.month):
        labels.append(f"{year}年{month}月")
        month += 1
        if month > 12:
            month = 1
            year += 1
    return labels


def build_daily_plan(day: date, days: int, regions: list[str], max_queries: int) -> list[dict]:
    taxonomy = load_taxonomy()
    groups = taxonomy.get("query_groups", [])
    start = day - timedelta(days=days)
    month_labels = month_labels_between(start, day)
    items: list[dict] = []

    for month_label in month_labels:
        for group in groups:
            keywords = group.get("keywords", [])
            if not keywords:
                continue
            pairs = [keywords[i : i + 2] for i in range(0, len(keywords), 2)]
            pair = pairs[day.toordinal() % len(pairs)]
            expr = " OR ".join(pair)
            for doc_type in ("招标", "中标"):
                items.append(
                    {
                        "query": f"{expr} {doc_type} {month_label}",
                        "priority": "P1",
                        "group": group["name"],
                        "period": month_label,
                        "kind": doc_type,
                    }
                )
        for region in regions:
            items.append(
                {
                    "query": f"ESG 招标 {region} {month_label}",
                    "priority": "P1",
                    "group": "区域补充",
                    "period": month_label,
                    "kind": "region",
                }
            )
    return items[:max_queries]


def render_markdown(items: list[dict], mode: str, start: date | None, end: date, days: int, max_queries: int) -> str:
    lines = []
    if mode == "collect":
        lines.append("# ESG 招投标检索计划（近两年中标汇总）")
        lines.append("")
        lines.append(f"- 数据窗口：{start} → {end}")
        lines.append(f"- 计划查询数：{len(items)} 条（上限 {max_queries}）")
        lines.append("")
        lines.append("> 用 WebSearch 逐条执行。**P1 优先全部执行**；P2、P3 视样本量决定是否继续。")
        lines.append("> 查询结果要按发布日期过滤到数据窗口内，只收 ESG/双碳相关的中标或成交公告。")
    else:
        lines.append("# ESG 招标监控检索计划（每日）")
        lines.append("")
        lines.append(f"- 监控窗口：{end - timedelta(days=days)} → {end}")
        lines.append(f"- 计划查询数：{len(items)} 条（上限 {max_queries}）")
        lines.append("")
        lines.append("> 用 WebSearch 执行；只保留监控窗口内新发布、且不在记录库中的公告。")
        lines.append("> 同一项目在多个站点重复出现时，以标题+采购人+发布日期去重。")

    lines.append("")
    current_priority = None
    for item in items:
        if item["priority"] != current_priority:
            current_priority = item["priority"]
            lines.append(f"## {current_priority}")
            lines.append("")
        lines.append(f"- [ ] `{item['query']}` — {item['group']}（{item['kind']}）")
    lines.append("")
    lines.append("## 执行提示")
    lines.append("")
    if mode == "collect":
        lines.append("- 如果某条查询返回大量同质结果，先收最新、金额明确、来源权威的记录，再换关键词补足空白季度。")
        lines.append("- 某一季度样本过少时，追加“该季度 + 采购人类型（央企/国企/政府）”查询。")
    else:
        lines.append("- 查询词会按日期轮换关键词组合；连续多日运行即可覆盖全部细分方向。")
        lines.append("- 搜索结果日期不明确时，打开详情页确认发布日期；无法确认的不要计入“新增”。")
    return "\n".join(lines) + "\n"


def main() -> int:
    setup_stdout()
    parser = argparse.ArgumentParser(description="生成 ESG 招投标检索计划")
    parser.add_argument("--mode", choices=["collect", "daily"], default="collect")
    parser.add_argument("--months", type=int, default=24, help="汇总模式回看月数，默认 24")
    parser.add_argument("--days", type=int, default=1, help="每日模式回看天数，默认 1")
    parser.add_argument("--date", default=today_str(), help="基准日期 YYYY-MM-DD，默认今天")
    parser.add_argument("--regions", default="", help="重点区域，逗号分隔，如 广东,江苏")
    parser.add_argument("--max-queries", type=int, default=None)
    parser.add_argument("--format", choices=["md", "json"], default="md")
    parser.add_argument("--data-dir", help="数据目录（读取 config.json 中的 regions）")
    args = parser.parse_args()

    end = date.fromisoformat(args.date)
    regions = [r.strip() for r in args.regions.split(",") if r.strip()]
    if not regions:
        regions = list(load_config(data_dir(args.data_dir)).get("regions") or [])

    if args.mode == "collect":
        max_queries = args.max_queries or 48
        items, start = build_collect_plan(end, args.months, regions, max_queries)
        output = render_markdown(items, args.mode, start, end, 0, max_queries)
    else:
        max_queries = args.max_queries or 24
        items = build_daily_plan(end, args.days, regions, max_queries)
        output = render_markdown(items, args.mode, None, end, args.days, max_queries)

    if args.format == "json":
        print(json.dumps({"mode": args.mode, "date": args.date, "items": items}, ensure_ascii=False, indent=2))
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
