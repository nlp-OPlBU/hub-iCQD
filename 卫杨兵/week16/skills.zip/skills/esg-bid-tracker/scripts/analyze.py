#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分析 ESG 中标记录：热点方向、金额分布、区域与集中度。

用法：
  python scripts/analyze.py
  python scripts/analyze.py --from 2024-11-26 --to 2026-11-26 --types 中标
  python scripts/analyze.py --input records.jsonl --out reports/analysis.json
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter
from datetime import date
from pathlib import Path

from esg_common import (
    TYPE_WIN,
    data_dir,
    ensure_data_dirs,
    fmt_amount,
    in_range,
    load_records_file,
    pct,
    setup_stdout,
    today_str,
    two_years_ago,
)

BUCKETS = [
    ("<50 万", 0, 50),
    ("50–100 万", 50, 100),
    ("100–300 万", 100, 300),
    ("300–500 万", 300, 500),
    ("500–1000 万", 500, 1000),
    ("1000–3000 万", 1000, 3000),
    ("≥3000 万", 3000, None),
]


def percentile(sorted_values: list[float], p: float) -> float | None:
    if not sorted_values:
        return None
    if len(sorted_values) == 1:
        return sorted_values[0]
    k = (len(sorted_values) - 1) * p
    low = math.floor(k)
    high = math.ceil(k)
    if low == high:
        return sorted_values[int(k)]
    return sorted_values[low] * (high - k) + sorted_values[high] * (k - low)


def amount_of(record: dict) -> float | None:
    value = record.get("amount")
    return float(value) if isinstance(value, (int, float)) else None


def aggregate(records: list[dict], name_func, total_amount: float) -> list[dict]:
    groups: dict[str, dict] = {}
    for record in records:
        name = name_func(record) or "未标注"
        item = groups.setdefault(
            name, {"name": name, "count": 0, "amount_count": 0, "amount_sum": 0.0}
        )
        item["count"] += 1
        amount = amount_of(record)
        if amount is not None:
            item["amount_count"] += 1
            item["amount_sum"] += amount

    rows = list(groups.values())
    for row in rows:
        row["amount_sum"] = round(row["amount_sum"], 2)
        row["avg_amount"] = (
            round(row["amount_sum"] / row["amount_count"], 2) if row["amount_count"] else None
        )
        row["count_pct"] = row["count"] / len(records) if records else 0
        row["amount_pct"] = row["amount_sum"] / total_amount if total_amount else 0
    rows.sort(key=lambda r: (r["count"], r["amount_sum"]), reverse=True)
    return rows


def concentration(rows: list[dict], key: str, total_count: int, total_amount: float) -> dict:
    ordered_amount = sorted(rows, key=lambda r: r["amount_sum"], reverse=True)
    ordered_count = sorted(rows, key=lambda r: r["count"], reverse=True)

    def amount_share(n: int) -> float | None:
        if not total_amount:
            return None
        return sum(r["amount_sum"] for r in ordered_amount[:n]) / total_amount

    def count_share(n: int) -> float | None:
        if not total_count:
            return None
        return sum(r["count"] for r in ordered_count[:n]) / total_count

    return {
        f"{key}_cr5_amount_pct": amount_share(5),
        f"{key}_cr10_amount_pct": amount_share(10),
        f"{key}_cr5_count_pct": count_share(5),
        f"{key}_cr10_count_pct": count_share(10),
        f"{key}_unique": len(rows),
    }


def analyze(records: list[dict], start: str, end: str, types: list[str], top_n: int) -> dict:
    loaded = records
    typed = [r for r in loaded if r.get("type") in types]
    undated = [r for r in typed if not r.get("publish_date")]
    in_scope = [r for r in typed if in_range(r, start, end)]
    in_scope.sort(key=lambda r: (r.get("publish_date") or "", r.get("amount") or 0), reverse=True)

    amounts = sorted(a for r in in_scope if (a := amount_of(r)) is not None)
    amount_total = sum(amounts)
    count = len(in_scope)

    summary = {
        "count": count,
        "amount_count": len(amounts),
        "amount_coverage_pct": (len(amounts) / count) if count else 0,
        "total_amount_wan": round(amount_total, 2),
        "mean_wan": round(amount_total / len(amounts), 2) if amounts else None,
        "median_wan": round(percentile(amounts, 0.5), 2) if amounts else None,
        "p25_wan": round(percentile(amounts, 0.25), 2) if amounts else None,
        "p75_wan": round(percentile(amounts, 0.75), 2) if amounts else None,
        "min_wan": round(amounts[0], 2) if amounts else None,
        "max_wan": round(amounts[-1], 2) if amounts else None,
    }

    buckets = []
    for label, low, high in BUCKETS:
        selected = [
            a for a in amounts if a >= low and (high is None or a < high)
        ]
        buckets.append(
            {
                "label": label,
                "min": low,
                "max": high,
                "count": len(selected),
                "amount_count": len(selected),
                "amount_sum": round(sum(selected), 2),
                "count_pct": (len(selected) / len(amounts)) if amounts else 0,
                "amount_pct": (sum(selected) / amount_total) if amount_total else 0,
            }
        )

    by_category = aggregate(in_scope, lambda r: r.get("category") or "其他", amount_total)
    by_region = aggregate(
        in_scope, lambda r: r.get("region") or "未标注", amount_total
    )
    by_year = aggregate(
        in_scope, lambda r: (r.get("publish_date") or "")[:4] or "未知", amount_total
    )
    by_year.sort(key=lambda r: r["name"])
    by_quarter = aggregate(
        in_scope,
        lambda r: _quarter_label(r.get("publish_date") or ""),
        amount_total,
    )
    by_quarter.sort(key=lambda r: r["name"])

    buyers = aggregate(
        in_scope, lambda r: r.get("buyer") or "", amount_total
    )
    buyers = [r for r in buyers if r["name"] != "未标注"]
    suppliers = aggregate(
        in_scope, lambda r: r.get("supplier") or "", amount_total
    )
    suppliers = [r for r in suppliers if r["name"] != "未标注"]

    top_projects = []
    for record in sorted(
        [r for r in in_scope if amount_of(r) is not None],
        key=lambda r: amount_of(r),
        reverse=True,
    ):
        amount = amount_of(record)
        if amount is None:
            continue
        top_projects.append(
            {
                "title": record.get("title") or "",
                "buyer": record.get("buyer") or "",
                "supplier": record.get("supplier") or "",
                "amount": round(amount, 2),
                "publish_date": record.get("publish_date") or "",
                "category": record.get("category") or "",
                "region": record.get("region") or "",
                "source": record.get("source") or "",
                "url": record.get("url") or "",
            }
        )
        if len(top_projects) >= top_n:
            break

    keyword_counter = Counter()
    for record in in_scope:
        for keyword in record.get("keywords") or []:
            keyword_counter[keyword] += 1

    sources = Counter(r.get("source") or "未标注" for r in in_scope)
    confidence = Counter(r.get("confidence") or "medium" for r in in_scope)

    buyer_total_amount = sum(r["amount_sum"] for r in buyers)
    supplier_total_amount = sum(r["amount_sum"] for r in suppliers)
    buyer_named_count = sum(r["count"] for r in buyers)
    supplier_named_count = sum(r["count"] for r in suppliers)

    meta = {
        "generated_at": today_str(),
        "from": start,
        "to": end,
        "types": types,
        "total_loaded": len(loaded),
        "type_matched": len(typed),
        "undated_excluded": len(undated),
        "analyzed": count,
        "amount_missing": count - len(amounts),
        "sources": dict(sources.most_common()),
        "confidence": dict(confidence.most_common()),
    }

    return {
        "meta": meta,
        "summary": summary,
        "amount_buckets": buckets,
        "by_category": by_category,
        "by_region": by_region,
        "by_year": by_year,
        "by_quarter": by_quarter,
        "top_buyers": buyers[:top_n],
        "top_suppliers": suppliers[:top_n],
        "top_projects": top_projects,
        "keywords": [
            {"name": name, "count": cnt} for name, cnt in keyword_counter.most_common(20)
        ],
        "concentration": {
            "buyers": concentration(buyers, "buyer", buyer_named_count, buyer_total_amount),
            "suppliers": concentration(suppliers, "supplier", supplier_named_count, supplier_total_amount),
        },
    }


def _quarter_label(publish_date: str) -> str:
    if len(publish_date) < 7:
        return "未知"
    try:
        month = int(publish_date[5:7])
    except ValueError:
        return "未知"
    quarter = (month - 1) // 3 + 1
    return f"{publish_date[:4]}Q{quarter}"


def print_summary(result: dict, out_path: Path) -> None:
    meta = result["meta"]
    summary = result["summary"]
    print(f"分析完成：{meta['from']} 至 {meta['to']}，类型 {'/'.join(meta['types'])}")
    print(f"  样本记录：{summary['count']} 条（载入 {meta['total_loaded']} 条；类型匹配 {meta['type_matched']} 条）")
    print(f"  披露金额：{summary['amount_count']} 条，覆盖率 {pct(summary['amount_count'], summary['count'])}")
    if summary["amount_count"]:
        print(
            f"  金额合计：{fmt_amount(summary['total_amount_wan'])}；"
            f"中位数 {fmt_amount(summary['median_wan'])}；均值 {fmt_amount(summary['mean_wan'])}"
        )
    if result["by_category"]:
        top_cat = result["by_category"][0]
        print(f"  最热方向：{top_cat['name']}（{top_cat['count']} 条，占 {pct(top_cat['count'], summary['count'])}）")
    print(f"  结果文件：{out_path}")


def main() -> int:
    setup_stdout()
    parser = argparse.ArgumentParser(description="分析 ESG 中标记录")
    parser.add_argument("--input", help="记录文件（json/jsonl/csv），默认 <data-dir>/records.jsonl")
    parser.add_argument("--data-dir", help="数据目录")
    parser.add_argument("--from", dest="start", default=None, help="起始日期 YYYY-MM-DD，默认两年前")
    parser.add_argument("--to", dest="end", default=today_str(), help="截止日期 YYYY-MM-DD")
    parser.add_argument("--types", default=TYPE_WIN, help="分析公告类型，逗号分隔，默认 中标")
    parser.add_argument("--top", type=int, default=10, help="榜单条数，默认 10")
    parser.add_argument("--out", help="分析 JSON 输出路径")
    args = parser.parse_args()

    base = data_dir(args.data_dir)
    input_path = Path(args.input) if args.input else base / "records.jsonl"
    start = args.start or two_years_ago(date.fromisoformat(args.end)).isoformat()
    types = [t.strip() for t in args.types.split(",") if t.strip()]

    if not input_path.exists():
        print(f"找不到记录文件: {input_path}", file=sys.stderr)
        return 2

    records = load_records_file(input_path)
    result = analyze(records, start, args.end, types, args.top)

    if args.out:
        out_path = Path(args.out)
    else:
        ensure_data_dirs(base)
        out_path = base / "reports" / "analysis.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print_summary(result, out_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
