---
name: esg-bid-tracker
description: >-
  ESG、可持续发展与双碳招投标情报技能。模式一：汇总过去两年 ESG 相关中标公告，
  分析热点招标方向、中标金额分布、区域与采购方/供应商格局，生成 Markdown/HTML 报告；
  模式二：每日监控新增 ESG 招标公告，去重入库并生成、推送日报。
  当用户提到 ESG 招投标、双碳中标、碳中和项目商机、可持续发展招标、ESG 招投标市场分析、
  中标金额分布、招标监控、每日招标推送、投标情报，或想看“最近有什么 ESG 的标/哪些 ESG 项目在招标”时使用。
  也适用于 ESG bidding intelligence、tender monitoring、bid tracking 等英文请求。
compatibility: 需要 Python 3.9+（无第三方依赖）；检索依赖当前环境的 WebSearch/WebFetch 工具。
---

# ESG 招投标情报追踪

本技能把公开招标信息变成两类可交付物：

1. **存量分析**：汇总过去 24 个月的 ESG/双碳中标记录，回答“哪些方向热、金额怎么分布、谁在买、谁在赢、哪里机会多”。
2. **增量监控**：每天检索新增 ESG 招标公告，去重入库，生成日报并按需推送。

## 两条铁律

- **不编造**：没有在搜索结果或公告页面看到的信息，不写进记录。金额、日期、采购人、中标人任何一项不确定就留空或降低 `confidence`。绝不根据常识补全。
- **样本意识**：公开检索得到的是样本，不是全量。任何报告都要写明样本量、金额覆盖率和局限；不要把样本合计说成市场规模。

## 何时用哪个模式

| 用户说法 | 模式 |
| --- | --- |
| “汇总/分析过去两年 ESG 中标情况”“ESG 市场怎么样”“中标金额分布”“哪些方向热” | 模式一：汇总分析 |
| “监控新的招标”“每天推送”“日报”“盯着 ESG 的标”“有新的告诉我” | 模式二：每日监控 |
| “先看看市场，再帮我盯着” | 先模式一，再配置模式二 |

用户意图不明确时，用一句话确认：“你是想先做过去两年的中标汇总分析，还是设置每天的新招标监控？”不要问一长串问题。

## 数据目录与初始化

默认数据目录：

- Windows：`C:\Users\<用户名>\esg-bid-data`
- macOS/Linux：`~/esg-bid-data`

可用环境变量 `ESG_BID_DATA_DIR` 或命令参数 `--data-dir` 覆盖。目录结构：

```
esg-bid-data/
├── records.jsonl      # 全部记录（唯一的真相来源）
├── config.json        # 区域、推送、目标样本量
├── state.json         # 上次日报日期、库内总数
├── digests/           # 每日日报 YYYY-MM-DD.md、latest.md
├── reports/           # analysis.json、insights.md、报告 md/html
└── exports/           # 分批采集文件、CSV 导出
```

首次使用先初始化（幂等，不会覆盖已有配置和记录）：

```bash
python scripts/store.py init
```

> 以上命令中的 `scripts/` 相对于**本技能文件所在目录**。执行时使用技能根目录的绝对路径，避免受当前工作目录影响。

## 模式一：过去两年中标汇总分析

### 步骤 1：确认范围并盘点已有数据

默认范围：**今天往前 24 个月**，公告类型为**中标/成交**，口径为 ESG 服务（见 `references/esg-taxonomy.md`）。用户指定了区域、行业或客户类型时，记下来并在检索计划中加权。

先看库里是否已有数据：

```bash
python scripts/store.py stats
python scripts/store.py list --type 中标 --limit 10
```

如果用户提供了 CSV/JSON/JSONL 导出文件，优先导入，不要重复检索（Excel 请先另存为 CSV）：

```bash
python scripts/store.py add --input /path/to/export.csv --json
```

CSV 支持常见中文表头（项目名称、公告类型、采购人、中标供应商、中标金额、发布日期、地区、来源、链接等），也支持标准英文字段。

### 步骤 2：生成检索计划

```bash
python scripts/querygen.py --mode collect --months 24
```

需要重点区域时：

```bash
python scripts/querygen.py --mode collect --months 24 --regions 广东,江苏,北京 --max-queries 60
```

计划按 P1/P2/P3 排序。**先执行 P1**，再根据样本缺口决定是否执行 P2/P3。不要机械跑完所有查询；目标是形成有代表性的样本，不是穷举。

### 步骤 3：检索与采集

用 WebSearch 逐条执行计划中的查询，必要时用 WebFetch 打开公告详情页核对。采集时遵循 `references/sources.md`：

- 只收 ESG/可持续发展/双碳相关的**服务类**公告（咨询、报告、核查、规划、碳资产、绿色金融、认证等）。
- 工程建设、光伏/风电/储能设备采购默认不纳入；用户明确要求全口径时才放宽，并在报告中注明。
- 优先原始公告（政府采购网、公共资源交易平台、央企采购平台）；聚合站只作线索。
- 只读取公开页面；遇到登录、验证码、付费墙直接放弃，改用其他来源或搜索摘要。
- WebFetch 可能被网络策略拦截（尤其是政府/央企站点）。同一域名失败一次就改用搜索摘要，不要反复重试；权威站摘要记 `medium`，聚合站摘要记 `low`。
- 每条记录保留 `source` 和 `url`；无法核实的降低 `confidence`。

记录字段（数组形式，每批 10–15 条）：

```json
[
  {
    "title": "某能源集团2025年度ESG报告编制及鉴证服务项目",
    "type": "中标",
    "buyer": "国家能源集团某电力公司",
    "supplier": "中诚信绿金科技（北京）有限公司",
    "amount": "128万元",
    "publish_date": "2025-06-18",
    "region": "北京",
    "source": "中国政府采购网",
    "url": "https://example.com/notice/1001",
    "summary": "ESG报告编制、数据采集与第三方鉴证",
    "confidence": "high"
  }
]
```

字段规则：

- `type`：写“中标”“招标”“采购意向”或原始公告类型（脚本会归一化）；同一项目的招标与中标是两条记录。
- `amount`：直接写公告原文（`128万元`、`1.2亿元`、`500-600万元`、`980000元`），脚本换算为万元并保留原文；无金额留空。
- `publish_date`：公告发布日期，不是开标日期；支持 `2025-06-18`、`2025年6月18日`、`2025/6/18`。
- `confidence`：`high` 详情页核对；`medium` 权威站摘要；`low` 仅聚合站摘要或字段存疑。

把每批记录保存到 `<data-dir>/exports/batch-001.json`，然后入库：

```bash
python scripts/store.py add --input "<data-dir>/exports/batch-001.json" --json
```

每 10–15 条入库一次，并记录进度（新增数、重复数）。**停止条件**（满足任一即可）：

- 中标记录达到 `config.json` 中的 `target_records_collect`（默认 80）；
- 已执行 40 条以上查询，且最近 10 条查询新增少于 3 条；
- 用户时间有限，但样本至少覆盖 6 个季度、5 个类别、8 个省份。

中途向用户简报一次进度，例如“已入库 42 条中标记录，覆盖 2024Q4–2026Q3，继续补华东和央企项目”。

### 步骤 4：分析

```bash
python scripts/analyze.py --from 2024-11-26 --to 2026-11-26 --types 中标
```

不传 `--from` 时默认两年前，`--to` 默认今天。默认读取 `<data-dir>/records.jsonl`，输出 `<data-dir>/reports/analysis.json`。脚本会打印样本量、金额覆盖率、合计、中位数和最热方向。

如果用户更关心**在招商机**而不是已成交结果，可以改用 `--types 招标` 或 `--types 中标,招标`；报告会按分析类型标注，不要把招标预算与中标金额混为一谈。

打开 `analysis.json` 时重点看：

- `summary`：样本量、金额覆盖、均值/中位数/分位；
- `by_category`：哪些方向项目多、哪些方向金额大；
- `amount_buckets`：金额分布形态；
- `by_quarter` / `by_region`：时间与区域覆盖；
- `top_buyers` / `top_suppliers` / `concentration`：客户与竞争格局；
- `top_projects`：头部大单。

如果样本少于 30 条，先如实告诉用户“样本偏小，结论只作方向参考”，并询问是否继续补采或直接出报告。

### 步骤 5：撰写核心结论

在 `<data-dir>/reports/insights.md` 写 6–10 条中文结论，必须引用 `analysis.json` 中的数字。格式与质量标准见 `references/report-spec.md` 第 1.2 节。

写结论前先读 `analysis.json`，不要凭印象。每条结论回答“数字是什么 + 说明什么 + 对投标意味着什么”。没有金额数据时明确说“金额披露不足”，不要估算。

### 步骤 6：生成报告

```bash
python scripts/report.py --insights "<data-dir>/reports/insights.md"
```

输出：

- `<data-dir>/reports/esg-bid-report.md`
- `<data-dir>/reports/esg-bid-report.html`（4 张内联 SVG 图表：方向、金额分布、季度趋势、区域；每个图表附数据表，支持明暗模式）

如果用户需要放在指定目录，用 `--outdir`：

```bash
python scripts/report.py --insights "<data-dir>/reports/insights.md" --outdir "./esg-reports"
```

### 步骤 7：交付

在对话中给出：

1. 样本量与时间范围（一句话，含局限）；
2. 3–5 条核心发现（最热方向、金额形态、头部区域/客户、竞争集中度）；
3. 报告路径（md + html）；
4. 一句提醒：样本来自公开检索，非全量，投标前核对原始公告。

不要把整份报告粘进对话；把关键数字和文件路径给用户即可。

## 模式二：每日招标监控

### 首次配置

先问清楚三件事（一次问完，不要逐条追问）：

1. 推送渠道：仅本地 / 飞书 / 钉钉 / 企业微信；
2. 每天什么时间推送；
3. 重点区域或方向（可留空表示全国、全方向）。

写入配置：

```bash
python scripts/store.py config \
  --set daily_time=09:00 \
  --set regions='["广东","江苏"]' \
  --set push.type=feishu \
  --set push.webhook=https://open.feishu.cn/open-apis/bot/v2/hook/xxxx
```

- 数组和对象用 JSON 写法；字符串直接写。
- Webhook 是敏感信息，只存本地 `config.json`，不要在报告、聊天或 git 中暴露。
- 没有 webhook 也能用：日报保存在 `<data-dir>/digests/`，在对话里汇报摘要。

### 每日流程

**1. 确定监控窗口**

读取 `<data-dir>/state.json`：

- 有 `last_digest_date`：窗口从该日期到今天的增量（至少覆盖过去 24 小时；间隔超过 7 天时先生成周报式补采）。
- 没有：默认过去 24 小时。

**2. 生成当日检索计划**

```bash
python scripts/querygen.py --mode daily --days 1
```

如果距上次运行 N 天，用 `--days N`。查询会按日期轮换细分关键词组合；连续运行可覆盖全部方向。

**3. 检索并提取新增**

执行计划中的全部 P1 查询，只保留：

- 发布日期在监控窗口内；
- 属于 ESG/双碳服务口径；
- 不在现有库中（脚本会再次去重）。

窗口外但价值很高的公告可以单独告诉用户，不要混入“今日新增”。搜索无结果时如实记录，不要用旧闻凑数。

把新增记录存成 `<data-dir>/exports/added-YYYY-MM-DD.json`，入库：

```bash
python scripts/store.py add \
  --input "<data-dir>/exports/added-YYYY-MM-DD.json" \
  --added-out "<data-dir>/exports/today-added.json" \
  --json
```

注意：`--added-out` 会写本次真正新增的记录（即使为 0 也会写空数组），日报只读这个文件，避免重复推送。

**4. 生成日报并推送**

```bash
python scripts/digest.py --input "<data-dir>/exports/today-added.json"
```

- 自动读取 `config.json` 的推送配置；没有配置时只保存本地。
- 临时推送：`--webhook-type feishu --webhook-url https://...`
- 不推送：`--no-push`（只生成日报）。
- 输出 `<data-dir>/digests/YYYY-MM-DD.md` 和 `latest.md`，并更新 `state.json`。

**5. 对话汇报**

- 有新增：报数量（招标/中标）、3 条重点（金额或采购人最值得看的）、日报路径。
- 无新增：明确说“本次检索未发现新增”，并说明检索覆盖（关键词/来源/窗口），不要写“今天没有招标”。

### 定时执行

只有用户明确要求“每天自动跑”时才设置定时任务，并先确认时间与时区。

如果当前环境有 `CronCreate`（或类似的定时任务工具），创建一个每天 09:00（按用户配置）执行的任务，prompt 使用：

```
使用 esg-bid-tracker 技能执行每日 ESG 招标监控：检索过去 24 小时新增的 ESG/可持续发展/双碳相关招标和中标公告，去重入库，生成日报，并按 ~/esg-bid-data/config.json 的推送配置推送。若没有新增，如实汇报检索覆盖范围。
```

如果环境没有定时任务工具，告诉用户可以：

- 每天手动说“跑一下今天的 ESG 招标监控”；
- 或用操作系统计划任务调用 `claude -p "使用 esg-bid-tracker 技能运行每日监控"`（需要 Claude Code CLI 在 PATH 中，且用户确认）。

不要擅自创建定时任务或向外部 webhook 推送；先获得用户同意。

## 脚本速查

| 命令 | 作用 |
| --- | --- |
| `python scripts/store.py init` | 初始化数据目录与配置 |
| `python scripts/store.py add --input file.json --added-out added.json --json` | 导入、标准化、去重入库 |
| `python scripts/store.py list --type 中标 --limit 20` | 查看记录 |
| `python scripts/store.py export --format csv` | 导出 CSV/JSONL |
| `python scripts/store.py stats` | 库内统计 |
| `python scripts/store.py config --set push.type=feishu --set push.webhook=...` | 修改配置 |
| `python scripts/querygen.py --mode collect --months 24` | 生成两年汇总检索计划 |
| `python scripts/querygen.py --mode daily --days 1` | 生成每日检索计划 |
| `python scripts/analyze.py --types 中标` | 分析并输出 analysis.json |
| `python scripts/report.py --insights insights.md` | 生成 Markdown + HTML 报告 |
| `python scripts/digest.py --input added.json` | 生成日报并推送（如已配置） |

Windows 提示：路径含空格或中文时加引号；控制台中文乱码时用 `python -X utf8 scripts/...` 或设置 `PYTHONIOENCODING=utf-8`。

## 分类与检索口径

采集和分类前读 `references/esg-taxonomy.md`，重点：

- 默认只收 ESG 服务，不收工程/设备；
- 8 个类别与关键词；
- 边界案例（碳中和主题公园、ESG 报告印刷、碳核查设备等）；
- 采购方类型与区域口径。

关键词可自定义：编辑 `assets/esg_keywords.json`，增加本地行业术语后，新入库记录会按新词分类；已入库记录不会自动重分类（如需重跑，导出后重新 `store.py add` 到新数据目录）。

## 报告规范

写 `insights.md`、调整报告结构或推送文案前，读 `references/report-spec.md`。关键点：

- 结论必须有数字、有解释、有行动含义；
- 金额未披露不能当 0；
- 汇总报告固定十节结构；
- 日报只报新增，不重复；
- 推送前确认用户同意。

## 数据采集边界

- 只采集公开可访问的信息；不登录、不绕过验证码、不破解付费墙、不高频批量抓取。
- 不采集个人信息；只记录项目公告中的单位名称与公开联系人信息（如有）。
- 尊重来源站点条款；对外报告保留来源链接。
- 搜索摘要与原始公告冲突时，以原始公告为准；无法核对时标 `low` 并在报告中说明。
- 找不到就报告“未检索到”，不要用相似项目代替。

## 常见问题

**WebSearch 不可用怎么办？**
说明当前环境无法联网检索，请用户提供从剑鱼/千里马/政府采购网导出的 CSV/Excel，或粘贴公告文本；仍可用 `store.py add` + `analyze.py` + `report.py` 完成分析和报告。

**报告里“其他”类别很多怎么办？**
说明分类关键词未覆盖，读 `references/esg-taxonomy.md` 补充关键词到 `assets/esg_keywords.json`；或手工在记录里填 `category` 后重新入库。

**金额覆盖率很低怎么办？**
在报告中明确说明；不要为了金额分析而估算或剔除无金额记录。可以补充检索“中标金额”明确的公告，或改用项目数分析为主。

**同一项目在多个站点出现，金额不一致？**
保留最早/最权威来源，`confidence` 降为 `medium` 或 `low`，`summary` 注明“不同转载金额不一致”，不要自行取平均。

**用户要求包含光伏/风电/环保工程怎么办？**
可以放宽口径，但必须在采集时单独标记（例如 `category` 写“双碳工程（放宽口径）”），报告中单独说明，避免与 ESG 服务市场混在一起。
