# esg-bid-tracker

ESG / 可持续发展 / 双碳招投标情报 Skill（Claude Code Skill）。

它解决两个问题：

1. **过去两年 ESG 中标市场什么样？** 汇总公开中标公告，分析热点方向、金额分布、区域与采购方/供应商格局，输出 Markdown + HTML 报告。
2. **今天有什么新的 ESG 招标？** 每日检索新增公告，去重入库，生成日报并可推送到飞书/钉钉/企业微信。

## 安装

把整个 `esg-bid-tracker` 目录放到 Claude Code 的技能目录：

- Windows：`C:\Users\<用户名>\.claude\skills\esg-bid-tracker\`
- macOS/Linux：`~/.claude/skills/esg-bid-tracker/`

重新启动 Claude Code 后，用“帮我汇总过去两年 ESG 中标情况”或“监控新的 ESG 招标”即可触发。

也可以只在本项目使用：放到项目目录的 `.claude/skills/esg-bid-tracker/`。

## 依赖

- Python 3.9+（仅标准库，无需 `pip install`）
- 检索依赖 Claude Code 的 WebSearch/WebFetch 工具
- 可选：飞书/钉钉/企业微信机器人 webhook

## 快速开始

```bash
cd esg-bid-tracker
python scripts/store.py init
```

然后直接对 Claude 说：

- “帮我汇总过去两年 ESG、双碳相关的中标情况，分析热点方向和金额分布。”
- “从今天开始每天监控 ESG 招标，早上 9 点推送到飞书。”

Claude 会按 `SKILL.md` 的流程检索、入库、分析、生成报告。

## 手动命令

```bash
# 初始化（幂等）
python scripts/store.py init

# 导入记录（json/jsonl/csv，自动去重）
python scripts/store.py add --input records.json --json

# 生成过去两年的检索计划
python scripts/querygen.py --mode collect --months 24

# 分析中标记录
python scripts/analyze.py --types 中标

# 生成报告（可选自定义核心结论）
python scripts/report.py --insights reports/insights.md

# 每日监控计划
python scripts/querygen.py --mode daily --days 1

# 入库并只输出本次新增
python scripts/store.py add --input batch.json --added-out today-added.json --json

# 生成日报（自动读取 config.json 推送配置）
python scripts/digest.py --input today-added.json
```

## 输出

默认数据目录 `~/esg-bid-data/`：

```
records.jsonl                 全部记录
reports/esg-bid-report.md     分析报告（Markdown）
reports/esg-bid-report.html   分析报告（自包含 HTML，含图表）
reports/analysis.json         结构化分析结果
digests/YYYY-MM-DD.md         每日日报
digests/latest.md             最新日报
state.json                    上次运行状态
config.json                   区域、推送、目标样本量
exports/                      分批采集与 CSV 导出
```

## 配置

```bash
python scripts/store.py config \
  --set regions='["广东","江苏"]' \
  --set daily_time=09:00 \
  --set push.type=feishu \
  --set push.webhook=https://open.feishu.cn/open-apis/bot/v2/hook/xxxx
```

支持 `push.type`：`feishu`、`dingtalk`、`wecom`。

## 口径

- 默认只收 ESG/双碳**服务类**项目：报告、咨询、核查、规划、碳资产、绿色金融、认证等。
- 工程建设、光伏/风电/储能设备采购默认不纳入。
- 金额统一为万元；未披露金额不按 0 处理。
- 公开检索是样本，不是全量；报告会标注样本量与覆盖率。

分类与关键词见 `references/esg-taxonomy.md`，数据源与检索技巧见 `references/sources.md`，报告规范见 `references/report-spec.md`。

## 注意

- 只采集公开可访问信息；不登录、不绕过验证码、不破解付费墙。
- 不保证覆盖所有公告；投标前请核对原始公告。
- Webhook 地址属于敏感配置，只保存在本地 `config.json`，不要提交到代码仓库。
