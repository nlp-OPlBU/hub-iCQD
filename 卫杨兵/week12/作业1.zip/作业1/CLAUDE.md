# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概况

第 12 周“多模态大模型和 RAG 应用”作业：对楼道照片做消防安全隐患识别，输出五类风险等级。

仓库已按设计文档 v0.3 完成 `backend/` + `frontend/` 实现：

- `设计文档.md`——权威规格，不要改动其中的既定契约，除非用户明确要求。
- `案例-多模态内容理解.ipynb`——参考案例，展示 YOLO / ChineseCLIP / Qwen2.5-VL 等多模态方案，不是交付物。
- `README.md`——启动与接口说明。
- `.idea/`——PyCharm 配置，Python 3.12。
- 没有自动化测试与 lint 配置；改动后至少执行 `python -m py_compile backend/*.py frontend/*.py`，并手动验证 `/health` 与前端流程。

## 交付架构

```text
Streamlit (frontend/streamlit_app.py)
  -- multipart POST /analyze -->  FastAPI (backend/main.py)
                                    -> analyzer.analyze()
                                       preprocess(): Pillow EXIF 修正 -> RGB -> 长边 1280 -> JPEG q85 -> Base64 Data URL（不落盘）
                                       call_model(): openai-agents Runner.run(Agent, input=[input_text + input_image])
                                       parse_result(): 去 ```json 包裹 -> json.loads -> 枚举/置信度兜底
  <-- JSON (风险等级/置信度/依据/建议) --
```

模块职责（设计文档 §3）：

- `backend/main.py`：`POST /analyze`、`GET /health`（返回 `MODEL_NAME`）、CORS、`latency_ms`；异常统一 HTTP 500 `{"error":"MODEL_ERROR","message":...}`。
- `backend/analyzer.py`：`preprocess` / `call_model` / `parse_result` / `analyze`，Agent 与 `OpenAIChatCompletionsModel` 在此定义。
- `backend/prompt.py`：`SYSTEM_PROMPT`、`USER_PROMPT`；要求只输出 JSON、不输出 Markdown。
- `backend/config.py`：从 `.env` 读取 `MODEL_BASE_URL` / `MODEL_API_KEY` / `MODEL_NAME`（默认 `ds-flash-4.1`）；缺配置时 `/health` 报告未就绪。
- `frontend/streamlit_app.py`：单页、上传/摄像头两个 Tab、`requests.post(BACKEND_URL + "/analyze")`、按风险等级映射 `st.error/warning/info/success`、展示置信度进度条与免责声明。

## 运行

前后端由用户分别启动，均需先将对应目录的 `.env.example` 复制为 `.env`（`.env` 不在仓库中提供）。以下命令来自设计文档 §6。

```bash
# 后端（http://localhost:8000，健康检查 /health）
cd backend
pip install -r requirements.txt
cp .env .env   # 填写 MODEL_BASE_URL / MODEL_API_KEY
uvicorn main:app --reload --port 8000

# 前端（http://localhost:8501）
cd frontend
pip install -r requirements.txt
cp .env .env   # BACKEND_URL 默认 http://localhost:8000
streamlit run streamlit_app.py
```

后端依赖包含 `openai-agents`、`openai`、`fastapi`、`uvicorn[standard]`、`pillow`、`python-multipart`；前端为 `streamlit`、`requests`、`python-dotenv`。

案例 notebook 需本地存在 `model/`、`data/` 目录及 GPU，仓库中并没有这些资源；直接运行会失败。notebook 约 12.5 MB（含内嵌输出图片），查看时按 cell 读取 JSON，不要整文件直接读入上下文。

## 跨文件契约（改动时需同步）

- **风险枚举**（后端解析、Prompt、前端配色三处必须一致）：`high` / `medium` / `low` / `none` / `not_corridor`，中文依次为高风险、中风险、低风险、无风险、非楼道。
- **响应字段**：`is_corridor`、`risk_level`、`confidence`(0~1)、`summary`、`evidence[{type,description,location}]`、`suggestions[]`；可能附带 `needs_review`。
- **兜底规则**（§3.4、§5.5）：`risk_level` 不在枚举内 → `low` 且 `needs_review=true`；`confidence < 0.6` → `needs_review=true`；JSON 解析失败 → `{"error":"MODEL_OUTPUT_INVALID","raw":原文}`；缺 `evidence`/`suggestions` → 空列表。
- **模型接入**：必须用 `OpenAIChatCompletionsModel(model=MODEL_NAME, openai_client=AsyncOpenAI(base_url=..., api_key=...))` 包一层，因为 `ds-flash-4.1` 是 Chat Completions 兼容端点，而 openai-agents 默认走 Responses API；多模态输入用 `input_text` + `input_image`，图片为 Data URL；`ModelSettings(temperature=0.1, max_tokens=800)`，`response_format` 仅在网关支持时通过 `extra_body` 传入。

## 范围约束（设计文档 §1.2，不要自行扩展）

不做部署（Docker/Nginx/HTTPS）、用户体系/鉴权/限流、视频流与检测框标注、多图联合分析、模型训练/微调、复杂重试与 Schema 校验库。前端为中文单页应用，判定要点与提示文案需与设计文档 §5 一致。
