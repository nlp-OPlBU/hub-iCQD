import base64
import io
import json
import logging

from agents import Agent, ModelSettings, OpenAIChatCompletionsModel, Runner
from openai import AsyncOpenAI
from PIL import Image, ImageOps

from config import MODEL_API_KEY, MODEL_BASE_URL, MODEL_NAME
from prompt import SYSTEM_PROMPT, USER_PROMPT

logger = logging.getLogger(__name__)

MAX_LONG_EDGE = 1280
JPEG_QUALITY = 85
RISK_LEVELS = {"high", "medium", "low", "none", "not_corridor"}
DEFAULT_RISK_LEVEL = "low"
REVIEW_CONFIDENCE_THRESHOLD = 0.6

_agent: Agent | None = None


def _get_agent() -> Agent:
    """延迟初始化 Agent，缺少配置时应用仍可启动并由 /health 报告未就绪。"""
    global _agent
    if _agent is None:
        if not MODEL_BASE_URL or not MODEL_API_KEY:
            raise RuntimeError(
                "缺少模型配置：请在 backend/.env 中设置 MODEL_BASE_URL 和 MODEL_API_KEY"
            )

        client = AsyncOpenAI(base_url=MODEL_BASE_URL, api_key=MODEL_API_KEY)
        model = OpenAIChatCompletionsModel(model=MODEL_NAME, openai_client=client)
        _agent = Agent(
            name="楼道消防隐患审核助手",
            instructions=SYSTEM_PROMPT,
            model=model,
            model_settings=ModelSettings(temperature=0.1, max_tokens=800),
        )
    return _agent


def preprocess(image_bytes: bytes) -> str:
    """EXIF 修正、转 RGB、长边缩放到 1280，返回 JPEG 的 Base64 Data URL。"""
    with Image.open(io.BytesIO(image_bytes)) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
        width, height = image.size
        long_edge = max(width, height)
        if long_edge > MAX_LONG_EDGE:
            scale = MAX_LONG_EDGE / long_edge
            image = image.resize(
                (max(1, round(width * scale)), max(1, round(height * scale))),
                Image.Resampling.LANCZOS,
            )

        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=JPEG_QUALITY)

    b64 = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/jpeg;base64,{b64}"


async def call_model(data_url: str) -> str:
    result = await Runner.run(
        _get_agent(),
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": USER_PROMPT},
                    {"type": "input_image", "image_url": data_url},
                ],
            }
        ],
    )
    return str(result.final_output or "")


def _strip_code_fence(text: str) -> str:
    text = (text or "").strip()
    if not text.startswith("```"):
        return text

    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def _coerce_confidence(value) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, confidence))


def _normalize_evidence(value) -> list[dict]:
    if not isinstance(value, list):
        return []
    evidence = []
    for item in value:
        if not isinstance(item, dict):
            continue
        evidence.append(
            {
                "type": str(item.get("type") or "").strip(),
                "description": str(item.get("description") or "").strip(),
                "location": str(item.get("location") or "").strip(),
            }
        )
    return evidence


def _normalize_suggestions(value) -> list[str]:
    if not isinstance(value, list):
        return []
    return [
        str(item).strip()
        for item in value
        if item is not None and str(item).strip()
    ]


def parse_result(text: str) -> dict:
    """解析模型输出，并按设计文档 §3.4/§5.5 做兜底处理。"""
    cleaned = _strip_code_fence(text)
    print(cleaned)
    try:
        data = json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        logger.warning("模型输出不是合法 JSON：%s", text)
        return {"error": "MODEL_OUTPUT_INVALID", "raw": text}

    if not isinstance(data, dict):
        logger.warning("模型输出 JSON 不是对象：%s", text)
        return {"error": "MODEL_OUTPUT_INVALID", "raw": text}

    needs_review = False

    risk_level = str(data.get("risk_level") or "").strip().lower()
    if risk_level not in RISK_LEVELS:
        risk_level = DEFAULT_RISK_LEVEL
        needs_review = True

    confidence = _coerce_confidence(data.get("confidence"))
    if confidence < REVIEW_CONFIDENCE_THRESHOLD:
        needs_review = True

    is_corridor = data.get("is_corridor")
    if not isinstance(is_corridor, bool):
        is_corridor = risk_level != "not_corridor"

    return {
        "is_corridor": is_corridor,
        "risk_level": risk_level,
        "confidence": confidence,
        "summary": str(data.get("summary") or "").strip(),
        "evidence": _normalize_evidence(data.get("evidence")),
        "suggestions": _normalize_suggestions(data.get("suggestions")),
        "needs_review": needs_review,
    }


async def analyze(image_bytes: bytes) -> dict:
    data_url = preprocess(image_bytes)
    raw = await call_model(data_url)
    return parse_result(raw)
