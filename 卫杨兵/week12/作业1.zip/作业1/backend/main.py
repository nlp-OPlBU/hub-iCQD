import logging
import time

from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import analyzer
import config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="楼道消防安全隐患识别服务")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    missing = config.missing_config()
    if missing:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "model": analyzer.MODEL_NAME,
                "missing": missing,
            },
        )
    return {"status": "ok", "model": analyzer.MODEL_NAME}


@app.post("/analyze")
async def analyze_api(image: UploadFile = File(...)):
    started_at = time.time()
    try:
        data = await image.read()
        result = await analyzer.analyze(data)
        result["latency_ms"] = int((time.time() - started_at) * 1000)
        return result
    except Exception as exc:
        logger.exception("分析图片失败")
        return JSONResponse(
            status_code=500,
            content={"error": "MODEL_ERROR", "message": str(exc)},
        )

