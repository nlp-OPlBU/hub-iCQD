import os

from dotenv import load_dotenv

load_dotenv()

MODEL_BASE_URL = os.getenv("MODEL_BASE_URL")
MODEL_API_KEY = os.getenv("MODEL_API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "ds-flash-4.1")


def missing_config() -> list[str]:
    """返回缺失的必填配置项，用于 /health 启动自检。"""
    missing = []
    if not MODEL_BASE_URL:
        missing.append("MODEL_BASE_URL")
    if not MODEL_API_KEY:
        missing.append("MODEL_API_KEY")
    return missing
