# 楼道消防安全隐患识别

基于 Streamlit + FastAPI + openai-agents 的楼道照片风险识别应用。前端上传或拍摄照片，后端调用 `ds-flash-4.1` 多模态模型，输出五类风险等级、置信度、判断依据与处置建议。

## 项目结构

```text
.
├── backend/
│   ├── main.py            # FastAPI 入口：POST /analyze、GET /health
│   ├── analyzer.py        # 图片预处理、模型调用、结果解析
│   ├── prompt.py          # System / User Prompt
│   ├── config.py          # 环境变量读取
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── streamlit_app.py   # Streamlit 单页应用
│   ├── requirements.txt
│   └── .env.example
├── 案例-多模态内容理解.ipynb
└── 设计文档.md
```

## 环境要求

- Python 3.10+（开发环境为 Python 3.12）
- 可访问的 OpenAI Chat Completions 兼容模型网关（默认模型名 `ds-flash-4.1`）

## 启动后端

```bash
cd backend
pip install -r requirements.txt
cp .env .env   # 填写 MODEL_BASE_URL / MODEL_API_KEY
uvicorn main:app --reload --port 8100
```

浏览器访问 `http://localhost:8100/health` 验证。未填写 `MODEL_BASE_URL` / `MODEL_API_KEY` 时返回 `503` 和 `{"status": "not_ready", "missing": [...]}`。

## 启动前端

```bash
cd frontend
pip install -r requirements.txt
cp .env .env   # 默认 BACKEND_URL=http://localhost:8000
streamlit run streamlit_app.py
```

浏览器打开 `http://localhost:8501`，上传或拍照后点击“开始分析”。摄像头 `getUserMedia` 在 `localhost` 下可直接使用；局域网访问时请使用上传功能。

## 接口

### POST /analyze

`multipart/form-data`，字段 `image` 为图片文件。

成功响应（额外包含 `latency_ms`，低置信度或分类异常时包含 `needs_review`）：

```json
{
  "is_corridor": true,
  "risk_level": "high",
  "confidence": 0.86,
  "summary": "楼道内停放电动车并可见充电线，存在起火风险。",
  "evidence": [
    {"type": "electric_vehicle", "description": "电动车停在楼道内", "location": "画面右侧"}
  ],
  "suggestions": ["立即将电动车移出楼道并停止充电", "通知物业或消防管理人员处理"],
  "latency_ms": 2380
}
```

失败响应：`500 {"error": "MODEL_ERROR", "message": "..."}`；模型输出不是合法 JSON 时返回 `{"error": "MODEL_OUTPUT_INVALID", "raw": "..."}`。

### GET /health

```json
{"status": "ok", "model": "ds-flash-4.1"}
```

## 风险等级

| 值 | 中文 | 判定要点 |
|---|---|---|
| `high` | 高风险 | 电动车、电瓶、飞线/接线板充电 |
| `medium` | 中风险 | 大量堆积物严重影响通行，或大量纸箱、木质家具等可燃堵塞物 |
| `low` | 低风险 | 存在堆物但不严重 |
| `none` | 无风险 | 楼道干净、无堆放物 |
| `not_corridor` | 非楼道 | 与楼道无关的图片 |

## 说明

- 前后端由用户分别启动，互不依赖构建/打包。
- 兜底规则：`risk_level` 不在枚举内 → `low` 且 `needs_review=true`；`confidence < 0.6` → `needs_review=true`。
- AI 辅助识别，仅供排查参考，不能替代人工消防检查。
