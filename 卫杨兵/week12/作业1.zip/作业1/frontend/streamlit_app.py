import hashlib
import os

import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8100").rstrip("/")
REQUEST_TIMEOUT = 60

RISK_DISPLAY = {
    "high": ("高风险", st.error),
    "medium": ("中风险", st.warning),
    "low": ("低风险", st.info),
    "none": ("无风险", st.success),
    "not_corridor": ("非楼道", st.info),
}


def _signature(file) -> tuple | None:
    if file is None:
        return None
    data = file.getvalue()
    return (getattr(file, "name", ""), len(data), hashlib.md5(data).hexdigest())


def _pick_image(uploaded, camera):
    """优先使用最近一次提供图片的来源，避免旧图片覆盖新图片。"""
    previous = st.session_state.get("_image_signatures", (None, None))
    current = (_signature(uploaded), _signature(camera))
    source = st.session_state.get("_image_source")

    if current[0] is not None and current[0] != previous[0]:
        source = "upload"
    elif current[1] is not None and current[1] != previous[1]:
        source = "camera"

    st.session_state["_image_signatures"] = current
    st.session_state["_image_source"] = source

    if source == "upload":
        return uploaded or camera
    if source == "camera":
        return camera or uploaded
    return uploaded or camera


def _render_result(result: dict) -> None:
    risk_level = result.get("risk_level", "low")
    label, render = RISK_DISPLAY.get(risk_level, ("未知", st.info))
    render(f"### 风险等级：{label}")

    try:
        confidence = float(result.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))
    st.progress(confidence, text=f"置信度：{confidence:.0%}")

    summary = result.get("summary")
    if summary:
        st.write(summary)

    evidence = result.get("evidence") or []
    if evidence:
        st.markdown("**判断依据**")
        for item in evidence:
            if not isinstance(item, dict):
                continue
            detail = " · ".join(
                str(item.get(key)).strip()
                for key in ("type", "description", "location")
                if item.get(key)
            )
            if detail:
                st.markdown(f"- {detail}")

    suggestions = result.get("suggestions") or []
    if suggestions:
        st.markdown("**处置建议**")
        for suggestion in suggestions:
            st.markdown(f"- {suggestion}")

    if result.get("needs_review"):
        st.warning("识别结果不确定，建议人工复核或重拍。")

    st.caption("AI 辅助识别，仅供排查参考，不能替代人工消防检查。")


def _analyze(image_file) -> None:
    filename = getattr(image_file, "name", None) or "image.jpg"
    mime_type = getattr(image_file, "type", None) or "image/jpeg"
    files = {"image": (filename, image_file.getvalue(), mime_type)}

    with st.spinner("正在识别…"):
        try:
            response = requests.post(
                f"{BACKEND_URL}/analyze", files=files, timeout=REQUEST_TIMEOUT
            )
        except requests.exceptions.Timeout:
            st.error("请求超时，请稍后重试。")
            return
        except requests.exceptions.RequestException:
            st.error("无法连接后端，请确认 uvicorn 已启动")
            return

    if response.status_code != 200:
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        st.error(
            payload.get("message")
            or f"后端返回错误（HTTP {response.status_code}）"
        )
        return

    try:
        result = response.json()
    except ValueError:
        st.error("后端返回内容无法解析。")
        return

    if "error" in result:
        st.error(f"识别失败：{result.get('error')}")
        raw = result.get("raw")
        if raw:
            with st.expander("查看模型原始输出"):
                st.code(raw)
        return

    _render_result(result)


st.set_page_config(page_title="楼道消防安全隐患识别", page_icon="🧯", layout="centered")
st.title("楼道消防安全隐患识别")
st.write("上传或拍摄楼道照片，AI 将判断是否存在消防安全隐患及风险等级。")

tab_upload, tab_camera = st.tabs(["上传图片", "摄像头拍照"])

with tab_upload:
    uploaded_file = st.file_uploader(
        "选择楼道照片", type=["jpg", "jpeg", "png", "webp"]
    )

with tab_camera:
    camera_file = st.camera_input("拍照")

image_file = _pick_image(uploaded_file, camera_file)

if image_file is not None:
    st.image(image_file, caption="待分析图片")

if st.button("开始分析", disabled=image_file is None):
    _analyze(image_file)
